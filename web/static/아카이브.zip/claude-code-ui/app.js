const state = {
  sessionId: null,
  continuation: null,
  lastResultId: null,
  canFollowup: false,
  pendingQuestion: "",
  conversation: [],
  queryMode: "new",
  isBusy: false,
};

const WEBAPP_AGENT_NAME = "manual";
const API_BASE = String(window.TEXT2SQL_API_BASE || (window.location.protocol === "file:" ? "http://127.0.0.1:8080" : "")).replace(/\/$/, "");
const WEBAPP_USER_ID = (() => {
  const configured = String(window.TEXT2SQL_USER_ID || "").trim();
  if (configured) return configured;
  const key = "text2sql:claude-code-ui:user-id";
  let stored = localStorage.getItem(key);
  if (!stored) {
    const randomId = window.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
    stored = `anon_${randomId}`;
    localStorage.setItem(key, stored);
  }
  return stored;
})();
const WEBAPP_QUERY_STREAM_PATH = `/api/v1/agent/${encodeURIComponent(WEBAPP_AGENT_NAME)}/query/stream`;

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));
const apiUrl = (path) => {
  if (/^https?:\/\//i.test(path)) return path;
  return `${API_BASE}${path.startsWith("/") ? path : `/${path}`}`;
};

function currentDateParts() {
  const now = new Date();
  return { year: now.getFullYear(), month: String(now.getMonth() + 1).padStart(2, "0") };
}

function currentYm() {
  const { year, month } = currentDateParts();
  return `${year}${month}`;
}

function currentYear() {
  return String(currentDateParts().year);
}

function currentYmKorean() {
  const { year, month } = currentDateParts();
  return `${year}년 ${Number(month)}월`;
}

const queryPanel = $("#queryPanel");
const questionInput = $("#questionInput");
const submitBtn = $("#submitBtn");
const modeButtons = $$("[data-query-mode]");
const clearBtn = $("#clearBtn");
const newSessionBtn = $("#newSessionBtn");
const sessionList = $("#sessionList");
const paramPanel = $("#paramPanel");
const paramForm = $("#paramForm");
const cancelParamsBtn = $("#cancelParamsBtn");
const resultPanel = $("#resultPanel");
const emptyState = $("#emptyState");
const answerBox = $("#answerBox");
const sqlBox = $("#sqlBox");
const historyBox = $("#historyBox");
const resultTable = $("#resultTable");
const tableMeta = $("#tableMeta");
const sourceLabel = $("#sourceLabel");
const resultBadges = $("#resultBadges");
const downloadList = $("#downloadList");
const excelBox = $("#excelBox");
const toast = $("#toast");
const progressPanel = $("#progressPanel");
const progressTitle = $("#progressTitle");
const progressSteps = $("#progressSteps");
const progressFill = $("#progressFill");
const elapsedTime = $("#elapsedTime");
const errorPanel = $("#errorPanel");
const errorTitle = $("#errorTitle");
const errorMessage = $("#errorMessage");
const resultMeta = $("#resultMeta");
const compactSummary = $("#compactSummary");
const followupBox = $("#followupBox");
const suggestionList = $("#suggestionList");
const followupInput = $("#followupInput");
const followupBtn = $("#followupBtn");

const progressLabels = [
  ["Intent", "질문 의도와 업무 범위를 확인합니다."],
  ["Plan", "사용 경로, 데이터, 조건을 정리합니다."],
  ["Run", "SQL 생성/검증과 DB 조회를 수행합니다."],
  ["Answer", "표, 요약, 다음 분석 질문을 준비합니다."],
];
const followupProgressLabels = [
  ["Context", "직전 결과와 대화 이력을 확인합니다."],
  ["Route", "기존 결과 분석인지 추가 조회인지 판단합니다."],
  ["Run", "필요한 조회 또는 결과 재해석을 수행합니다."],
  ["Answer", "답변과 다음 분석 질문을 준비합니다."],
];
const progressGroupIndex = {
  start: 0,
  search_plan: 1,
  aggregate_review: 2,
  response: 3,
  classify_question: 0,
  route_domain: 0,
  followup_route: 0,
  select_tool: 1,
  check_tool_params: 1,
  match_verified_query: 1,
  extract_and_apply_params: 1,
  analyze_question: 1,
  check_sql_gen_params: 1,
  execute_tool: 2,
  run_tool_query: 2,
  run_matched_query: 2,
  generate_sql: 2,
  validate_sql: 2,
  run_query: 2,
  generate_answer: 3,
  direct_answer: 3,
  reject_answer: 3,
  handle_error: 3,
  complete: 3,
};
const progressPhaseGroupIndex = {
  question_analysis: 0,
  domain_routing: 0,
  followup_route: 0,
  tool_selection: 1,
  capability_selection: 1,
  parameter_check: 1,
  verified_query_matching: 1,
  parameter_extraction: 1,
  table_selection: 1,
  tool_execution: 2,
  sql_generation: 2,
  sql_validation: 2,
  sql_execution: 2,
  answer_generation: 3,
  rejected: 3,
  error: 3,
  processing: 1,
};
let activeProgressLabels = progressLabels;
let progressTimer = null;
let progressAutoTimer = null;
let progressStartedAt = 0;
let progressCurrentIndex = 0;
let progressHideTimer = null;

function showToast(message) {
  toast.textContent = message;
  toast.classList.remove("hidden");
  window.clearTimeout(showToast.timer);
  showToast.timer = window.setTimeout(() => toast.classList.add("hidden"), 6500);
}

function eventErrorMessage(data, fallback) {
  return data?.detail || data?.data?.error || data?.message || fallback;
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatCell(value) {
  if (typeof value === "number") {
    return new Intl.NumberFormat("ko-KR", { maximumFractionDigits: 4 }).format(value);
  }
  return String(value ?? "");
}

async function api(path, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...webappHeaders(),
    ...(options.headers || {}),
  };
  const response = await fetch(apiUrl(path), { ...options, headers });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(body.detail || "요청 처리 중 오류가 발생했습니다.");
  }
  return body;
}

async function streamApi(path, payload, onEvent, options = {}) {
  const response = await fetch(apiUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    body: JSON.stringify(payload),
  });
  if (!response.ok) {
    const body = await response.json().catch(() => ({}));
    throw new Error(body.detail || "요청 처리 중 오류가 발생했습니다.");
  }
  if (!response.body) {
    throw new Error("브라우저가 스트리밍 응답을 지원하지 않습니다.");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const events = buffer.split("\n\n");
    buffer = events.pop() || "";
    for (const rawEvent of events) {
      const lines = rawEvent.split("\n");
      const eventName = lines.find((line) => line.startsWith("event:"))?.slice(6).trim() || "message";
      const dataText = lines
        .filter((line) => line.startsWith("data:"))
        .map((line) => line.slice(5).trim())
        .join("\n");
      if (!dataText) continue;
      onEvent(eventName, JSON.parse(dataText));
    }
  }
}

function webappHeaders() {
  return {
    "X-User-ID": WEBAPP_USER_ID,
    "X-Agent-Name": WEBAPP_AGENT_NAME,
  };
}

function conversationHistory(limit = 10) {
  return state.conversation.slice(-limit).map((message) => ({
    role: message.role,
    content: message.text || "",
  }));
}

function webappQueryPayload(payload = {}) {
  const query = String(payload.query || payload.question || "").trim();
  const body = {
    query,
    agent_name: WEBAPP_AGENT_NAME,
    top_k: payload.top_k || 10,
    session_id: payload.session_id || state.sessionId,
    conversation_history: conversationHistory(),
  };
  if (payload.params) body.params = payload.params;
  if (payload.continuation) body.continuation = payload.continuation;
  if (payload.result_id) body.result_id = payload.result_id;
  return body;
}

function canUseFollowupMode() {
  return Boolean(state.lastResultId && state.canFollowup && !state.continuation);
}

function setQueryMode(mode) {
  state.queryMode = mode === "followup" && canUseFollowupMode() ? "followup" : "new";
  syncQueryModeUi();
}

function syncQueryModeUi() {
  const followupAvailable = canUseFollowupMode();
  if (!followupAvailable && state.queryMode === "followup") {
    state.queryMode = "new";
  }
  modeButtons.forEach((button) => {
    const mode = button.dataset.queryMode;
    button.classList.toggle("active", mode === state.queryMode);
    button.disabled = state.isBusy || (mode === "followup" && !followupAvailable);
  });
  if (state.continuation) {
    submitBtn.textContent = state.isBusy ? "처리 중" : "계속";
    return;
  }
  submitBtn.textContent = state.isBusy ? "처리 중" : state.queryMode === "followup" ? "분석" : "조회";
  questionInput.placeholder =
    state.queryMode === "followup" && followupAvailable
      ? "이전 결과를 바탕으로 이어서 물어보세요."
      : "새로 조회할 질문을 입력하세요.";
}

function setBusy(isBusy) {
  state.isBusy = isBusy;
  submitBtn.disabled = isBusy;
  syncQueryModeUi();
}

function setFollowupBusy(isBusy) {
  followupBtn.disabled = isBusy;
  followupBtn.textContent = isBusy ? "분석 중" : "Ask";
}

function isProgressEvent(eventName) {
  return ["start", "search_plan", "aggregate_review", "response", "progress", "text2sql_progress"].includes(eventName);
}

function normalizeProgressEvent(progress) {
  const data = progress?.data || {};
  return {
    step: progress?.step || progress?.text2sql_step || data.text2sql_step || data.step || "",
    phase: progress?.phase || data.phase || "",
    title: progress?.title || data.title || "",
    message: progress?.message || data.message || "",
  };
}

function progressIndexFor(step, phase = "") {
  const index = progressGroupIndex[step] ?? progressPhaseGroupIndex[phase] ?? 1;
  return Math.max(0, Math.min(index, activeProgressLabels.length - 1));
}

function setProgressStep(index) {
  progressCurrentIndex = Math.max(progressCurrentIndex, index);
  progressSteps.querySelectorAll("li").forEach((item, idx) => {
    item.classList.toggle("done", idx < progressCurrentIndex);
    item.classList.toggle("active", idx === progressCurrentIndex);
  });
  const safeIndex = Math.min(progressCurrentIndex, activeProgressLabels.length - 1);
  progressTitle.textContent = activeProgressLabels[safeIndex][1];
  progressFill.style.width = `${Math.min(95, 12 + safeIndex * 26)}%`;
}

function stopProgressAutoAdvance() {
  window.clearInterval(progressAutoTimer);
  progressAutoTimer = null;
}

function startProgressAutoAdvance() {
  stopProgressAutoAdvance();
  progressAutoTimer = window.setInterval(() => {
    const maxAutoIndex = Math.max(0, activeProgressLabels.length - 2);
    if (progressCurrentIndex < maxAutoIndex) {
      setProgressStep(progressCurrentIndex + 1);
    }
  }, 2500);
}

function appendProgressDetail(item, progress, step) {
  const details = item.querySelector(".progress-detail");
  const list = item.querySelector(".progress-detail-list");
  if (!details || !list) return;
  let detailItem = Array.from(list.querySelectorAll("li")).find((entry) => entry.dataset.step === step);
  if (!detailItem) {
    detailItem = document.createElement("li");
    detailItem.dataset.step = step;
    list.appendChild(detailItem);
  }
  detailItem.innerHTML = `
    <span>${escapeHtml(progress.title || step)}</span>
    <small>${escapeHtml(progress.message || "")}</small>
  `;
  details.classList.remove("hidden");
  details.open = true;
  item.querySelector(".progress-count").textContent = `${list.querySelectorAll("li").length}`;
}

function renderProgressEvent(progress) {
  const normalized = normalizeProgressEvent(progress);
  const step = normalized.step || normalized.phase || normalized.title || "progress";
  const groupIndex = progressIndexFor(normalized.step, normalized.phase);
  const item = progressSteps.querySelector(`[data-progress-index="${groupIndex}"]`);
  setProgressStep(groupIndex);
  if (item) appendProgressDetail(item, normalized, step);
  progressTitle.textContent = normalized.message || normalized.title || "처리 중입니다.";
}

function renderStreamProgress(eventName, data) {
  const webappStep = {
    start: "start",
    search_plan: "search_plan",
    aggregate_review: "aggregate_review",
    response: "response",
  }[eventName];
  if (eventName === "start") {
    renderProgressEvent({
      step: "start",
      title: "요청 접수",
      message: data?.message || "질문을 분석 중입니다...",
    });
    return;
  }
  if (webappStep) {
    const progressData = data?.data || {};
    renderProgressEvent({
      ...data,
      step: progressData.text2sql_step || webappStep,
      phase: progressData.phase || "",
      title: progressData.title || progressData.operation || "",
      message: progressData.progress_message || data?.message || "",
    });
    return;
  }
  renderProgressEvent(data);
}

function startProgress(labels = [], hideCurrentResult = true, fallbackLabels = progressLabels) {
  const seedLabels = Array.isArray(labels) && labels.length ? labels : fallbackLabels;
  activeProgressLabels = seedLabels;
  progressStartedAt = Date.now();
  progressCurrentIndex = 0;
  window.clearTimeout(progressHideTimer);
  progressHideTimer = null;
  elapsedTime.textContent = "0초";
  progressFill.style.width = "12%";
  progressTitle.textContent = activeProgressLabels[0]?.[1] || "처리 중입니다.";
  progressSteps.innerHTML = seedLabels
    .map(
      ([title, desc], index) => `
        <li data-progress-index="${index}">
          <div class="progress-card-title">
            <strong>${escapeHtml(title)}</strong>
            <span class="progress-count">0</span>
          </div>
          <div class="progress-card-desc">${escapeHtml(desc)}</div>
          <details class="progress-detail hidden">
            <summary>처리 상세</summary>
            <ul class="progress-detail-list"></ul>
          </details>
        </li>
      `,
    )
    .join("");
  progressPanel.classList.remove("hidden");
  clearInlineError();
  emptyState.classList.add("hidden");
  if (hideCurrentResult) resultPanel.classList.add("hidden");
  paramPanel.classList.add("hidden");
  setProgressStep(0);
  window.clearInterval(progressTimer);
  progressTimer = window.setInterval(() => {
    const seconds = Math.floor((Date.now() - progressStartedAt) / 1000);
    elapsedTime.textContent = `${seconds}초`;
  }, 1000);
  startProgressAutoAdvance();
}

function finishProgress() {
  stopProgressAutoAdvance();
  window.clearInterval(progressTimer);
  progressTimer = null;
  progressFill.style.width = "100%";
  progressCurrentIndex = activeProgressLabels.length - 1;
  progressSteps.querySelectorAll("li").forEach((item) => {
    item.classList.add("done");
    item.classList.remove("active");
  });
  progressTitle.textContent = "결과를 화면에 표시합니다.";
  const elapsed = Date.now() - progressStartedAt;
  const delay = Math.max(300, 1200 - elapsed);
  window.clearTimeout(progressHideTimer);
  progressHideTimer = window.setTimeout(() => {
    progressPanel.classList.add("hidden");
    progressHideTimer = null;
  }, delay);
}

function stopProgress() {
  stopProgressAutoAdvance();
  window.clearInterval(progressTimer);
  progressTimer = null;
  window.clearTimeout(progressHideTimer);
  progressHideTimer = null;
  progressPanel.classList.add("hidden");
}

function clearInlineError() {
  errorPanel.classList.add("hidden");
  errorTitle.textContent = "요청을 처리하지 못했습니다.";
  errorMessage.textContent = "";
}

function setExportEnabled(enabled) {
  $$("[data-export]").forEach((button) => {
    button.disabled = !enabled;
  });
}

function resetResultPanels() {
  resultPanel.classList.add("hidden");
  emptyState.classList.remove("hidden");
  answerBox.innerHTML = "";
  sqlBox.textContent = "실행 SQL이 없습니다.";
  historyBox.innerHTML = "";
  resultTable.innerHTML = "";
  tableMeta.textContent = "조회 데이터가 없습니다.";
  compactSummary.innerHTML = "";
  compactSummary.classList.add("hidden");
  resultMeta.innerHTML = "";
  resultMeta.classList.add("hidden");
  sourceLabel.textContent = "";
  resultBadges.innerHTML = "";
  excelBox.innerHTML = "";
  excelBox.classList.add("hidden");
  suggestionList.innerHTML = "";
  followupInput.value = "";
  followupBox.classList.add("hidden");
  downloadList.innerHTML = "";
  setExportEnabled(false);
}

function showInlineError(message, title = "요청을 처리하지 못했습니다.", appendMessage = true) {
  const safeMessage = String(message || "알 수 없는 오류가 발생했습니다.");
  errorTitle.textContent = title;
  errorMessage.textContent = safeMessage;
  errorPanel.classList.remove("hidden");
  emptyState.classList.add("hidden");
  resultPanel.classList.remove("hidden");
  sourceLabel.textContent = "오류";
  resultBadges.innerHTML = "";
  renderResultMeta(null);
  renderCompactSummary([], []);
  renderTable([], []);
  sqlBox.textContent = "실행 SQL이 없습니다.";
  setExportEnabled(false);
  if (appendMessage) {
    const pending = state.pendingQuestion || "";
    const last = state.conversation[state.conversation.length - 1];
    if (pending && !(last?.role === "user" && last.text === pending)) {
      state.conversation.push({ role: "user", text: pending });
    }
    state.conversation.push({ role: "assistant", text: `### ${title}\n${safeMessage}`, status: "error" });
    renderConversation();
    renderHistory({ question: pending, original_answer: safeMessage, analysis_history: [] });
  }
}

async function loadHealth() {
  try {
    const data = await api("/health");
    const status = data.llm_status || (data.llm_ready === false ? "unavailable" : "ready");
    const label = status === "ready" ? "ready" : status === "auth_error" ? "auth" : "check";
    $("#serviceStatus").textContent = `${data.model || "model"} · ${label}`;
  } catch {
    $("#serviceStatus").textContent = "service · check";
  }
}

async function loadExamples() {
  const box = $("#examples");
  try {
    const data = await api("/api/examples");
    box.innerHTML = "";
    (data.examples || []).forEach((item) => {
      const button = document.createElement("button");
      button.className = "example";
      button.type = "button";
      button.textContent = item;
      button.addEventListener("click", () => {
        questionInput.value = item;
        questionInput.focus();
      });
      box.appendChild(button);
    });
  } catch {
    box.innerHTML = "";
  }
}

async function createSession() {
  const data = await api("/api/sessions", { method: "POST", body: JSON.stringify({}) });
  state.sessionId = data.session.id;
  state.lastResultId = "";
  state.canFollowup = false;
  state.continuation = null;
  state.pendingQuestion = "";
  state.conversation = [];
  state.queryMode = "new";
  queryPanel.classList.remove("awaiting-param");
  closeParamDialog();
  resetResultPanels();
  syncQueryModeUi();
  await loadSessions();
  return data.session;
}

async function loadSessions() {
  try {
    const data = await api("/api/sessions");
    renderSessions(data.sessions || []);
  } catch {
    sessionList.innerHTML = "";
  }
}

function renderSessions(sessions) {
  sessionList.innerHTML = "";
  if (!sessions.length) {
    sessionList.innerHTML = `<div class="session-empty">아직 세션이 없습니다.</div>`;
    return;
  }
  sessions.forEach((session) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `session-item${session.id === state.sessionId ? " active" : ""}`;
    button.innerHTML = `
      <span>${escapeHtml(session.title || "새 대화")}</span>
      <small>${escapeHtml(String(session.message_count || 0))} messages</small>
    `;
    button.addEventListener("click", () => loadSession(session.id));
    sessionList.appendChild(button);
  });
}

async function loadSession(sessionId) {
  const data = await api(`/api/sessions/${encodeURIComponent(sessionId)}`);
  state.sessionId = data.session.id;
  state.lastResultId = data.session.last_result_id || "";
  state.canFollowup = Boolean(state.lastResultId);
  state.continuation = null;
  state.pendingQuestion = "";
  state.queryMode = "new";
  state.conversation = (data.messages || []).map((message) => ({
    role: message.role,
    text: message.text,
    status: message.status,
    missing_params: message.missing_params,
    continuation: message.continuation,
  }));
  const pendingMessage = [...state.conversation].reverse().find((message) => message.status === "requires_params" && message.continuation);
  if (pendingMessage) {
    state.continuation = pendingMessage.continuation;
    state.pendingQuestion = pendingMessage.continuation?.question || "";
    applyPendingParamPrompt(pendingMessage.missing_params || pendingMessage.continuation?.missing_params || []);
  } else {
    queryPanel.classList.remove("awaiting-param");
    closeParamDialog();
  }

  if (data.last_result) {
    renderResult(data.last_result);
    if (pendingMessage) {
      state.continuation = pendingMessage.continuation;
      state.pendingQuestion = pendingMessage.continuation?.question || "";
      syncQueryModeUi();
      applyPendingParamPrompt(pendingMessage.missing_params || pendingMessage.continuation?.missing_params || []);
    }
    return;
  }
  resetResultPanels();
  renderConversation();
  syncQueryModeUi();
  await loadSessions();
}

function renderMissingParams(data) {
  state.continuation = data.continuation;
  state.queryMode = "new";
  state.pendingQuestion = data.continuation?.question || state.pendingQuestion;
  if (data.session_id) state.sessionId = data.session_id;
  if (data.messages?.length) {
    state.conversation = data.messages.map((message) => ({
      role: message.role,
      text: message.text,
      status: message.status,
      missing_params: message.missing_params,
      continuation: message.continuation,
    }));
  } else {
    state.conversation.push({
      role: "assistant",
      text: "추가 입력이 필요합니다.",
      status: "requires_params",
      missing_params: data.missing_params,
      continuation: data.continuation,
    });
  }
  stopProgress();
  emptyState.classList.add("hidden");
  resultPanel.classList.remove("hidden");
  renderConversation();
  renderHistory({ question: "", original_answer: "", analysis_history: [] });
  syncQueryModeUi();
  applyPendingParamPrompt(data.missing_params || data.continuation?.missing_params || []);
  openParamDialog(data.missing_params || data.continuation?.missing_params || []);
  loadSessions();
}

function applyPendingParamPrompt(params = []) {
  const labels = (params || []).map((param) => param.label || param.name).filter(Boolean).join(", ");
  queryPanel.classList.add("awaiting-param");
  questionInput.placeholder = labels
    ? `${labels} 값을 채팅하듯 입력하세요. 예: ${currentYmKorean()}로 해줘`
    : "필요한 추가 정보를 채팅하듯 입력하세요.";
}

function paramPlaceholder(param) {
  const key = String(param.name || param.label || "").toLowerCase();
  if (key.includes("ym") || key.includes("년월") || key.includes("기준월")) return `예: ${currentYm()}`;
  if (key.includes("year") || key.includes("연도") || key.includes("년도")) return `예: ${currentYear()}`;
  if (key.includes("date") || key.includes("일자") || key.includes("날짜")) return `예: ${currentYear()}-${currentDateParts().month}-01`;
  return "값을 입력하세요";
}

function paramNaturalPlaceholder(params = []) {
  const names = params.map((param) => String(param.name || param.label || "").toLowerCase());
  if (names.some((name) => name.includes("ls")) || names.some((name) => name.includes("is"))) {
    return `예: 한빛테크놀로지 ${currentYmKorean()}, LS=0.3, IS=0.3`;
  }
  if (names.some((name) => name.includes("가맹점") || name.includes("기업"))) {
    return "예: 한빛테크놀로지로 해줘";
  }
  if (names.some((name) => name.includes("년월") || name.includes("기준월") || name.includes("ym"))) {
    return `예: ${currentYmKorean()}로 해줘`;
  }
  return "예: 필요한 값을 문장으로 입력";
}

function openParamDialog(params = []) {
  $("#paramTitle").textContent = params.length ? `필수 값 ${params.length}개 입력` : "추가 정보 입력";
  const fields = params
    .map((param, index) => {
      const name = param.name || param.label || `param_${index + 1}`;
      const label = param.label || param.name || `필수 값 ${index + 1}`;
      const detail = [param.description, param.type ? `형식: ${param.type}` : ""].filter(Boolean).join(" · ");
      return `
        <div class="field">
          <label for="param-${index}">${escapeHtml(label)}</label>
          ${detail ? `<small class="field-hint">${escapeHtml(detail)}</small>` : ""}
          <input id="param-${index}" name="${escapeHtml(name)}" data-param-field autocomplete="off" placeholder="${escapeHtml(paramPlaceholder(param))}" />
        </div>
      `;
    })
    .join("");
  paramForm.innerHTML = `
    <div class="field param-natural">
      <label for="param-natural-input">문장으로 답하기</label>
      <input id="param-natural-input" name="_natural_input" autocomplete="off" placeholder="${escapeHtml(paramNaturalPlaceholder(params))}" />
    </div>
    <div class="param-grid">${fields || ""}</div>
    <div class="param-actions">
      <button type="submit">계속</button>
      <button type="button" data-use-chat-input>질문창에 적기</button>
    </div>
  `;
  paramForm.querySelector("[data-use-chat-input]")?.addEventListener("click", () => {
    closeParamDialog();
    questionInput.focus();
  });
  paramPanel.classList.remove("hidden");
  window.setTimeout(() => paramForm.querySelector("#param-natural-input")?.focus(), 0);
}

function closeParamDialog() {
  paramPanel.classList.add("hidden");
}

function renderBadges(data) {
  const badges = [];
  const dataSources = data.result_meta?.data_sources || data.selected_tables || [];
  if (data.selected_tool) badges.push(`tool: ${data.selected_tool}`);
  if (data.matched_query_name) badges.push(`verified: ${data.matched_query_name}`);
  if (dataSources.length) badges.push(`${dataSources.length} sources`);
  resultBadges.innerHTML = badges.map((b) => `<span class="badge">${escapeHtml(b)}</span>`).join("");
}

function formatConditions(conditions = {}) {
  const entries = Object.entries(conditions).filter(([, value]) => value !== "" && value !== null && value !== undefined);
  if (!entries.length) return "질문에서 추출된 조건 없음";
  return entries
    .map(([key, value]) => {
      const formatted = typeof value === "object" ? JSON.stringify(value) : String(value);
      return `${key}=${formatted}`;
    })
    .join(", ");
}

function renderResultMeta(data) {
  if (!data) {
    resultMeta.classList.add("hidden");
    resultMeta.innerHTML = "";
    return;
  }
  const meta = data.result_meta || {};
  const displayedRows = meta.displayed_rows ?? data.rows?.length ?? 0;
  const rowLimit = meta.display_row_limit || 100;
  const rowText = `${displayedRows.toLocaleString("ko-KR")}건 표시 · 최대 ${rowLimit.toLocaleString("ko-KR")}건`;
  const limitedText = meta.rows_may_be_limited ? "더 많은 결과가 있을 수 있습니다." : "표시 범위 안의 결과입니다.";
  const dataSources = meta.data_sources?.length ? meta.data_sources.join(", ") : data.selected_tables?.join(", ") || "선택 데이터 없음";
  const plannedSources = meta.planned_data_sources?.length ? meta.planned_data_sources.join(", ") : "";
  const sqlSources = meta.sql_data_sources?.length ? meta.sql_data_sources.join(", ") : "";
  const sourceNote = plannedSources && sqlSources && plannedSources !== sqlSources ? `분석 후보: ${plannedSources}` : "";
  const path = meta.execution_path || data.source || "처리 경로 없음";
  const conditions = formatConditions(meta.conditions || {});
  resultMeta.innerHTML = `
    <div class="meta-item"><span>Path</span><strong>${escapeHtml(path)}</strong></div>
    <div class="meta-item"><span>Rows</span><strong>${escapeHtml(rowText)}</strong><small>${escapeHtml(limitedText)}</small></div>
    <div class="meta-item"><span>Sources</span><strong>${escapeHtml(dataSources)}</strong>${sourceNote ? `<small>${escapeHtml(sourceNote)}</small>` : ""}</div>
    <div class="meta-item"><span>Conditions</span><strong>${escapeHtml(conditions)}</strong></div>
  `;
  resultMeta.classList.remove("hidden");
}

function renderTable(columns, rows) {
  if (!columns?.length || !rows?.length) {
    tableMeta.textContent = "조회 데이터가 없습니다.";
    resultTable.innerHTML = "";
    return;
  }
  tableMeta.textContent = `${rows.length.toLocaleString("ko-KR")}건 표시`;
  const thead = `<thead><tr>${columns.map((c) => `<th>${escapeHtml(c)}</th>`).join("")}</tr></thead>`;
  const tbody = rows
    .map((row) => {
      const cells = columns
        .map((_, idx) => {
          const value = row[idx];
          const cls = typeof value === "number" ? ' class="numeric"' : "";
          return `<td${cls}>${escapeHtml(formatCell(value))}</td>`;
        })
        .join("");
      return `<tr>${cells}</tr>`;
    })
    .join("");
  resultTable.innerHTML = `${thead}<tbody>${tbody}</tbody>`;
}

function renderCompactSummary(columns, rows) {
  if (!columns?.length || !rows?.length) {
    compactSummary.classList.add("hidden");
    compactSummary.innerHTML = "";
    return;
  }
  const summaryColumns = columns.slice(0, Math.min(columns.length, 5));
  const summaryRows = rows.slice(0, Math.min(rows.length, 4));
  const header = summaryColumns.map((c) => `<th>${escapeHtml(c)}</th>`).join("");
  const body = summaryRows
    .map((row) => {
      const cells = summaryColumns
        .map((_, idx) => {
          const value = row[idx];
          const cls = typeof value === "number" ? ' class="numeric"' : "";
          return `<td${cls}>${escapeHtml(formatCell(value))}</td>`;
        })
        .join("");
      return `<tr>${cells}</tr>`;
    })
    .join("");
  compactSummary.innerHTML = `
    <div class="compact-summary-title">Preview · ${rows.length.toLocaleString("ko-KR")} rows</div>
    <table><thead><tr>${header}</tr></thead><tbody>${body}</tbody></table>
  `;
  compactSummary.classList.remove("hidden");
}

function renderAnswerHtml(text) {
  const lines = String(text || "").split("\n");
  const chunks = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i].trim();
    if (!line) {
      i += 1;
      continue;
    }
    if (line.startsWith("### ")) {
      chunks.push(`<h3>${escapeHtml(line.replace(/^###\s+/, ""))}</h3>`);
      i += 1;
      continue;
    }
    if (line.startsWith("|") && line.endsWith("|")) {
      const tableLines = [];
      while (i < lines.length && lines[i].trim().startsWith("|") && lines[i].trim().endsWith("|")) {
        tableLines.push(lines[i].trim());
        i += 1;
      }
      const cleaned = tableLines.filter((row) => !/^\|[\s:\-|]+\|$/.test(row));
      const rowsHtml = cleaned
        .map((row, rowIndex) => {
          const cells = row.slice(1, -1).split("|").map((cell) => cell.trim());
          const tag = rowIndex === 0 ? "th" : "td";
          return `<tr>${cells.map((cell) => `<${tag}>${escapeHtml(cell)}</${tag}>`).join("")}</tr>`;
        })
        .join("");
      chunks.push(`<table class="answer-table">${rowsHtml}</table>`);
      continue;
    }
    if (line.startsWith("- ")) {
      const items = [];
      while (i < lines.length && lines[i].trim().startsWith("- ")) {
        items.push(`<li>${escapeHtml(lines[i].trim().slice(2))}</li>`);
        i += 1;
      }
      chunks.push(`<ul>${items.join("")}</ul>`);
      continue;
    }
    chunks.push(`<p>${escapeHtml(line)}</p>`);
    i += 1;
  }

  return chunks.join("");
}

function rebuildConversationFromResult(data) {
  if (data.messages?.length) {
    return data.messages.map((message) => ({
      role: message.role,
      text: message.text,
      status: message.status,
      missing_params: message.missing_params,
      continuation: message.continuation,
    }));
  }
  const messages = [];
  const originalQuestion = data.question || state.pendingQuestion || questionInput.value.trim();
  if (originalQuestion) messages.push({ role: "user", text: originalQuestion });
  if (data.original_answer) messages.push({ role: "assistant", text: data.original_answer });
  (data.analysis_history || []).forEach((item) => {
    if (item.question) messages.push({ role: "user", text: item.question });
    if (item.answer) messages.push({ role: "assistant", text: item.answer });
  });
  if (!messages.length && data.answer) messages.push({ role: "assistant", text: data.answer });
  return messages;
}

function renderConversation() {
  if (!state.conversation.length) {
    answerBox.innerHTML = "";
    return;
  }

  answerBox.innerHTML = state.conversation
    .map((message) => {
      const label = message.role === "user" ? "user" : message.status === "error" ? "error" : "assistant";
      const content =
        message.role === "assistant"
          ? `${renderAnswerHtml(message.text || "응답이 없습니다.")}`
          : `<p>${escapeHtml(message.text || "")}</p>`;
      return `
        <div class="conversation-message ${escapeHtml(message.role)}">
          <div class="message-label">${label}</div>
          <div class="message-body">${content}</div>
        </div>
      `;
    })
    .join("");
  resultPanel.scrollTop = resultPanel.scrollHeight;
}

function renderHistory(data) {
  const entries = [];
  const originalQuestion = data.question || state.pendingQuestion || questionInput.value.trim();
  if (originalQuestion || data.original_answer || data.answer) {
    entries.push({
      mode: "초기 질문",
      question: originalQuestion,
      answer: data.original_answer || data.answer || "",
      sql: data.sql || "",
      row_count: data.rows?.length || 0,
      source: data.source || "",
    });
  }
  (data.analysis_history || []).forEach((item) => {
    entries.push({
      mode: ["query", "rewrite_sql", "new_sql"].includes(item.mode) ? "후속 SQL" : "후속 분석",
      question: item.question || "",
      answer: item.answer || "",
      sql: item.sql || "",
      row_count: item.row_count ?? "",
      source: item.source || "",
    });
  });
  if (!entries.length) {
    historyBox.innerHTML = `<div class="history-empty">아직 대화 이력이 없습니다.</div>`;
    return;
  }
  historyBox.innerHTML = entries
    .map((entry) => {
      const sql = entry.sql ? `<pre>${escapeHtml(entry.sql)}</pre>` : `<span class="muted-text">SQL 없음</span>`;
      return `
        <section class="history-item">
          <div class="history-head"><strong>${escapeHtml(entry.mode)}</strong><span>${escapeHtml(entry.source || "")}</span></div>
          <dl>
            <dt>질문</dt><dd>${escapeHtml(entry.question || "")}</dd>
            <dt>결과</dt><dd>${escapeHtml(String(entry.row_count || 0))}건</dd>
            <dt>답변</dt><dd class="history-answer">${renderAnswerHtml(entry.answer || "응답 없음")}</dd>
            <dt>SQL</dt><dd>${sql}</dd>
          </dl>
        </section>
      `;
    })
    .join("");
}

function normalizeFileUrl(url) {
  if (!url) return "";
  if (/^https?:\/\//i.test(url)) return url;
  return apiUrl(url);
}

function renderDownloads(files) {
  if (!files?.length) return;
  const html = files
    .map((file) => {
      const label = file.kind === "text" ? "TXT" : file.kind?.toUpperCase();
      const href = normalizeFileUrl(file.url);
      return `<a class="download-link" href="${escapeHtml(href)}" download="${escapeHtml(file.filename || "")}">${escapeHtml(
        label ? `${label} · ${file.filename}` : file.filename,
      )}</a>`;
    })
    .join("");
  downloadList.insertAdjacentHTML("afterbegin", html);
}

function triggerDownloads(files) {
  if (!files?.length) return;
  files.forEach((file, index) => {
    window.setTimeout(() => {
      const link = document.createElement("a");
      link.href = normalizeFileUrl(file.url);
      link.download = file.filename || "";
      link.style.display = "none";
      document.body.appendChild(link);
      link.click();
      link.remove();
    }, index * 250);
  });
}

function renderSuggestions(suggestions) {
  suggestionList.innerHTML = "";
  if (!suggestions?.length || !state.lastResultId || !state.canFollowup) {
    followupBox.classList.add("hidden");
    return;
  }
  suggestions.forEach((item) => {
    const button = document.createElement("button");
    button.className = "suggestion";
    button.type = "button";
    button.textContent = item;
    button.addEventListener("click", () => submitFollowup(item));
    suggestionList.appendChild(button);
  });
  followupInput.value = "";
  followupBox.classList.remove("hidden");
}

function renderResult(data, context = {}) {
  state.lastResultId = data.result_id;
  state.canFollowup = Boolean(data.columns?.length && data.rows?.length);
  if (data.session_id) state.sessionId = data.session_id;
  state.continuation = null;
  state.queryMode = "new";
  queryPanel.classList.remove("awaiting-param");
  syncQueryModeUi();
  finishProgress();
  closeParamDialog();
  emptyState.classList.add("hidden");
  resultPanel.classList.remove("hidden");
  setExportEnabled(true);
  if (data.error) {
    showInlineError(data.error, "조회 중 확인 필요", false);
  } else {
    clearInlineError();
  }

  sourceLabel.textContent = data.source || data.question_type || "";
  renderBadges(data);
  if (data.messages?.length) {
    state.conversation = rebuildConversationFromResult(data);
  } else if (data.error) {
    state.conversation.push({ role: "assistant", text: data.error });
  } else if (context.mode === "followup") {
    state.conversation.push({ role: "user", text: context.question });
    state.conversation.push({ role: "assistant", text: data.answer || "응답이 없습니다." });
  } else {
    state.conversation = rebuildConversationFromResult(data);
  }
  renderConversation();
  sqlBox.textContent = data.sql || "실행 SQL이 없습니다.";
  renderHistory(data);
  renderResultMeta(data);
  renderCompactSummary(data.columns, data.rows);
  renderTable(data.columns, data.rows);
  renderSuggestions(data.suggestions);
  loadSessions();

  excelBox.classList.add("hidden");
  excelBox.innerHTML = "";
  if (data.excel_file) {
    excelBox.classList.remove("hidden");
    const href = normalizeFileUrl(data.excel_file.url);
    excelBox.innerHTML = `<a class="download-link" href="${escapeHtml(href)}" target="_blank" rel="noopener">${escapeHtml(
      data.excel_file.filename,
    )}</a>`;
    renderDownloads([{ ...data.excel_file, kind: "excel" }]);
  }
}

async function submitFollowup(question) {
  const followupQuestion = String(question || followupInput.value || "").trim();
  if (!followupQuestion) {
    showToast("후속 질문을 입력해주세요.");
    followupInput.focus();
    return;
  }
  if (!state.lastResultId || !state.canFollowup) {
    showToast("먼저 조회 결과가 있는 질문을 실행해주세요.");
    return;
  }

  state.pendingQuestion = followupQuestion;
  setFollowupBusy(true);
  startProgress([], false, followupProgressLabels);
  let receivedTerminalEvent = false;
  try {
    await streamApi(
      WEBAPP_QUERY_STREAM_PATH,
      webappQueryPayload({
        result_id: state.lastResultId,
        query: followupQuestion,
        session_id: state.sessionId,
      }),
      (eventName, data) => {
        if (isProgressEvent(eventName)) {
          renderStreamProgress(eventName, data);
        } else if (eventName === "result" || eventName === "done") {
          receivedTerminalEvent = true;
          const resultData = eventName === "done" ? data.data || data : data;
          renderResult(resultData, { mode: "followup", question: followupQuestion });
        } else if (eventName === "error") {
          receivedTerminalEvent = true;
          throw new Error(eventErrorMessage(data, "후속 질문 처리 중 오류가 발생했습니다."));
        }
      },
      { headers: webappHeaders() },
    );
    if (!receivedTerminalEvent) {
      throw new Error("후속 질문 응답이 완료되지 않았습니다. 서버 로그를 확인한 뒤 다시 시도해주세요.");
    }
  } catch (error) {
    stopProgress();
    showInlineError(error.message, "후속 질문 처리 오류");
    showToast(error.message);
  } finally {
    setFollowupBusy(false);
  }
}

async function submitQuestion(payload) {
  setBusy(true);
  startProgress();
  let receivedTerminalEvent = false;
  try {
    await streamApi(
      WEBAPP_QUERY_STREAM_PATH,
      webappQueryPayload({ session_id: state.sessionId, ...payload }),
      (eventName, data) => {
        if (isProgressEvent(eventName)) {
          renderStreamProgress(eventName, data);
        } else if (eventName === "result" || eventName === "done") {
          receivedTerminalEvent = true;
          const resultData = eventName === "done" ? data.data || data : data;
          if (resultData.status === "requires_params") {
            renderMissingParams(resultData);
          } else {
            renderResult(resultData, { mode: "query" });
          }
        } else if (eventName === "parameter_required") {
          receivedTerminalEvent = true;
          renderMissingParams(data.data || data);
        } else if (eventName === "error") {
          receivedTerminalEvent = true;
          throw new Error(eventErrorMessage(data, "질문 처리 중 오류가 발생했습니다."));
        }
      },
      { headers: webappHeaders() },
    );
    if (!receivedTerminalEvent) {
      throw new Error("질문 응답이 완료되지 않았습니다. 서버 로그를 확인한 뒤 다시 시도해주세요.");
    }
  } catch (error) {
    stopProgress();
    showInlineError(error.message, "질문 처리 오류");
    showToast(error.message);
  } finally {
    setBusy(false);
  }
}

submitBtn.addEventListener("click", () => {
  const question = questionInput.value.trim();
  if (!question) {
    showToast(state.continuation ? "추가 정보를 입력해주세요." : "질문을 입력해주세요.");
    questionInput.focus();
    return;
  }
  downloadList.innerHTML = "";
  questionInput.value = "";
  if (state.continuation) {
    submitQuestion({
      question: state.continuation.question || state.pendingQuestion || "추가 입력",
      session_id: state.sessionId,
      params: { _natural_input: question },
      continuation: state.continuation,
    });
  } else if (state.queryMode === "followup" && state.lastResultId && state.canFollowup) {
    state.pendingQuestion = question;
    submitFollowup(question);
  } else {
    state.pendingQuestion = question;
    submitQuestion({ question, session_id: state.sessionId });
  }
});

questionInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    submitBtn.click();
  }
});

paramForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const params = {};
  new FormData(paramForm).forEach((value, key) => {
    if (String(value).trim()) params[key] = String(value).trim();
  });
  if (!Object.keys(params).length) {
    showToast("필요한 값을 입력하거나 질문창에 이어서 적어주세요.");
    paramForm.querySelector("input")?.focus();
    return;
  }
  submitQuestion({
    question: state.pendingQuestion || questionInput.value.trim(),
    session_id: state.sessionId,
    params,
    continuation: state.continuation,
  });
});

cancelParamsBtn.addEventListener("click", () => {
  closeParamDialog();
  questionInput.focus();
});

paramPanel.addEventListener("click", (event) => {
  if (event.target === paramPanel) {
    closeParamDialog();
    questionInput.focus();
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !paramPanel.classList.contains("hidden")) {
    closeParamDialog();
    questionInput.focus();
  }
});

followupBtn.addEventListener("click", () => submitFollowup());

followupInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    event.preventDefault();
    submitFollowup();
  }
});

newSessionBtn.addEventListener("click", async () => {
  try {
    await createSession();
    questionInput.value = "";
    stopProgress();
    clearInlineError();
  } catch (error) {
    showToast(error.message);
  }
});

modeButtons.forEach((button) => {
  button.addEventListener("click", () => setQueryMode(button.dataset.queryMode));
});

clearBtn.addEventListener("click", () => {
  newSessionBtn.click();
});

$$(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    $$(".tab").forEach((tab) => tab.classList.remove("active"));
    $$(".tab-page").forEach((page) => page.classList.remove("active"));
    button.classList.add("active");
    $(`#tab-${button.dataset.tab}`).classList.add("active");
  });
});

$$("[data-export]").forEach((button) => {
  button.addEventListener("click", async () => {
    if (!state.lastResultId) return;
    button.disabled = true;
    try {
      const data = await api("/api/export", {
        method: "POST",
        body: JSON.stringify({
          result_id: state.lastResultId,
          format: button.dataset.export,
        }),
      });
      renderDownloads(data.files);
      triggerDownloads(data.files);
      showToast("보고서가 생성되었습니다.");
    } catch (error) {
      showToast(error.message);
    } finally {
      button.disabled = false;
    }
  });
});

loadHealth();
loadExamples();
createSession();
