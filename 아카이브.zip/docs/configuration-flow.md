# Configuration Flow

이 문서는 이 서비스가 `kbcard-agent-common` 방식의 설정을 어떻게 읽고, 어떤 함수가 어떤 값을 만들고, 그 값이 LLM, embedding, PostgreSQL, observability 쪽으로 어떻게 전달되는지 정리합니다.

## 전체 흐름

```mermaid
flowchart TD
    EnvFiles[".env / .env.local"] --> ConfigPy["text2sql_agent/config.py"]
    AgentYaml["config/agent.*.yaml"] --> ConfigPy
    ModelYaml["config/models.*.yaml"] --> ConfigPy
    ConfigPy --> InitPy["text2sql_agent/__init__.py"]
    InitPy --> Web["webservice_v1.py"]
    ConfigPy --> LLM["text2sql_agent/llm.py"]
    ConfigPy --> DB["text2sql_agent/db.py"]
    ConfigPy --> CommonSvc["text2sql_agent/common_services.py"]
    LLM --> CommonLLM["KBCardOpenAI / EmbeddingClient"]
    DB --> Postgres["PostgreSQL"]
    CommonSvc --> Logs["ExecutionLogRecord / ModuleEventLogRecord"]
```

설정의 중심은 `text2sql_agent/config.py`입니다. 이 파일은 import되는 순간 `.env`, `.env.local`, common YAML, 환경 변수를 읽어서 모듈 전역 상수로 확정합니다.

## 설정 파일 역할

### `.env.example`

예시 환경 변수 파일입니다. 실제 운영/로컬에서는 `.env` 또는 `.env.local`을 사용합니다.

주요 값:

- `KBCARD_CONFIG_PATH`: common agent YAML 경로입니다.
- `LLM_API_KEY`: 로컬 vLLM처럼 인증이 없을 때 `EMPTY`로 둡니다.
- `AWS_BEARER_TOKEN_BEDROCK`: Bedrock API key를 쓸 때 shell이나 `.env.local`에만 둡니다. Git에 올리지 않습니다.
- `KBCARD_POSTGRES_DSN`: common 예제 방식의 PostgreSQL DSN secret입니다.
- `KBCARD_LOG_*`: common observability 로그 설정입니다.

### `config/agent.example.yaml`

common의 agent 설정 파일입니다. 서비스 단위 설정을 담습니다.

주요 섹션:

- `agent`: agent 이름, 실행 환경, service name입니다.
- `llm`: model registry 파일 경로, 기본 모델, temperature, max tokens, timeout입니다.
- `embedding`: TEI embedding endpoint, 모델명, timeout입니다.
- `retrieval.store`: PostgreSQL DSN을 어떤 환경 변수에서 읽을지 지정합니다.

### `config/models.example.yaml`

LLM model registry입니다. `agent.example.yaml`의 `llm.default_model`이 여기의 key를 가리킵니다.

예시 모델:

- `local-chat`: 로컬 vLLM 또는 OpenAI-compatible endpoint입니다.
- `openai.gpt-oss-20b-1:0`: Bedrock Runtime의 OpenAI-compatible chat completions endpoint입니다.

secret은 YAML에 직접 쓰지 않고 `api_key_env`로 환경 변수 이름만 연결합니다.

### 로컬 전용 파일

로컬 실행용 파일은 보통 아래처럼 둡니다.

```bash
.env.local
config/agent.local.yaml
config/models.local.yaml
```

이 파일들은 `.gitignore` 대상입니다. 로컬 endpoint, Bedrock bearer token, DB password 같은 값은 여기에 두고 Git에는 올리지 않습니다.

## `text2sql_agent/config.py`

이 파일이 설정의 single entry point입니다.

### 1. dotenv 로드

```python
load_dotenv(BASE_DIR / ".env")
load_dotenv(BASE_DIR / ".env.local", override=True)
```

먼저 `.env`를 읽고, 그 다음 `.env.local`을 `override=True`로 읽습니다. 그래서 로컬에서는 `.env.local` 값이 `.env`보다 우선합니다.

### 2. 환경 변수 helper

```python
def _env(*names: str, default: str) -> str:
```

여러 환경 변수 이름을 순서대로 확인하고, 가장 먼저 비어 있지 않은 값을 반환합니다. 없으면 `default`를 씁니다.

예를 들어 LLM key는 아래 순서로 찾습니다.

```python
LLM_API_KEY = _env(
    "LLM_API_KEY",
    "OPENAI_API_KEY",
    "AWS_BEARER_TOKEN_BEDROCK",
    "BEDROCK_API_KEY",
    "VLLM_API_KEY",
    default=...
)
```

### 3. common YAML 경로 찾기

```python
COMMON_CONFIG_PATH = _path_from_env(
    "KBCARD_CONFIG_PATH",
    "KBCARD_AGENT_CONFIG_PATH",
    "AGENT_CONFIG_PATH",
    default=Path("config/agent.local.yaml"),
)
```

우선순위는 다음과 같습니다.

1. `KBCARD_CONFIG_PATH`
2. `KBCARD_AGENT_CONFIG_PATH`
3. `AGENT_CONFIG_PATH`
4. `config/agent.local.yaml`이 실제로 있으면 기본값으로 사용

상대 경로는 repository root인 `BASE_DIR` 기준으로 절대 경로로 바꿉니다.

### 4. `KBCardConfig` 로드

```python
COMMON_CONFIG = _load_common_config(COMMON_CONFIG_PATH)
```

`kbcard_agent_common.config.KBCardConfig`가 설치되어 있고 YAML 파일이 있으면 `KBCardConfig.from_yaml(path)`로 읽습니다.

common 패키지가 없거나 YAML 경로가 없으면 `COMMON_CONFIG`는 `None`이 됩니다. 이 경우에도 기존 환경 변수 기반 fallback으로 동작합니다.

### 5. common 설정 분해

```python
COMMON_LLM_SETTINGS = _common_llm_settings()
COMMON_LLM_MODEL_CONFIG = _common_llm_model_config()
COMMON_EMBEDDING_SETTINGS = _common_embedding_settings()
COMMON_RETRIEVAL_STORE = _common_retrieval_store()
```

각 helper의 역할은 다음과 같습니다.

- `_common_llm_settings()`: `COMMON_CONFIG.get_llm_settings()`로 `llm` 섹션을 읽습니다.
- `_common_llm_model_config()`: `llm.model_registry_path`의 YAML을 `ModelRegistry.from_yaml(...)`로 읽고 `llm.default_model`에 해당하는 모델 설정을 찾습니다.
- `_common_embedding_settings()`: `embedding` 섹션을 읽습니다.
- `_common_retrieval_store()`: `retrieval.store` 섹션을 읽습니다.

### 6. 최종 LLM 상수 확정

```python
LLM_BASE_URL
LLM_TRANSPORT
LLM_MODEL
LLM_API_KEY
LLM_ENDPOINT_PATH
LLM_PROVIDER
LLM_TEMPERATURE
LLM_MAX_TOKENS
LLM_TIMEOUT
```

대부분의 값은 "환경 변수 override → common YAML/model registry → 코드 기본값" 순서로 정해집니다.

예:

- `LLM_BASE_URL`: `LLM_BASE_URL` 또는 `VLLM_BASE_URL`이 있으면 그 값을 씁니다. 없으면 model registry의 `base_url`을 씁니다.
- `LLM_MODEL`: `LLM_MODEL`, `VLLM_MODEL`, `BEDROCK_MODEL`이 있으면 그 값을 씁니다. 없으면 `llm.default_model`을 씁니다.
- `LLM_ENDPOINT_PATH`: 환경 변수가 있으면 우선하고, 없으면 model registry의 `endpoint_path`를 씁니다.
- `LLM_API_KEY`: 환경 변수에 key가 있으면 우선하고, 없으면 model registry의 `api_key` 또는 `api_key_env`로 연결된 환경 변수를 읽습니다.

`LLM_TRANSPORT`는 기본적으로 `openai_chat`입니다. 단, base URL이 `bedrock-runtime.ap-northeast-2.amazonaws.com`이면 `bedrock_converse`가 기본값입니다. 현재 Bedrock OpenAI-compatible 방식은 서울 리전이 아니라 OpenAI-compatible endpoint가 동작하는 리전을 쓰는 것이 전제입니다.

### 7. 최종 embedding 상수 확정

```python
EMBED_BASE_URL
EMBED_MODEL
EMBED_API_KEY
EMBED_TIMEOUT
```

우선순위는 LLM과 비슷합니다.

- 환경 변수: `EMBED_BASE_URL`, `EMBEDDING_BASE_URL`, `VLLM_EMBED_URL`
- common YAML: `embedding.base_url`, `embedding.model`, `embedding.api_key`, `embedding.timeout`
- fallback: LLM base URL 또는 기본 embedding 모델명

### 8. 최종 DB 상수 확정

```python
DB_DSN_ENV
DB_DSN
DB_HOST
DB_PORT
DB_NAME
DB_USER
DB_PASSWORD
DB_POOL_MAX
```

common 방식에서는 `retrieval.store.dsn_env`가 `KBCARD_POSTGRES_DSN` 같은 환경 변수 이름을 지정합니다.

```yaml
retrieval:
  store:
    provider: postgres
    dsn_env: KBCARD_POSTGRES_DSN
    pool_max_size: 10
```

코드는 `DB_DSN = _env("DATABASE_URL", "DB_DSN", "POSTGRES_DSN", DB_DSN_ENV, default="")` 순서로 DSN을 찾습니다. DSN이 있으면 host/port/dbname/user/password 개별 값보다 DSN이 우선입니다.

### 9. 기존 코드 호환 alias

```python
VLLM_BASE_URL = LLM_BASE_URL
VLLM_MODEL = LLM_MODEL
VLLM_API_KEY = LLM_API_KEY
...
```

기존 코드가 `VLLM_*` 이름을 많이 사용하고 있어서, 새 `LLM_*`, `EMBED_*` 값을 다시 `VLLM_*` alias로 노출합니다. 그래서 기존 import를 크게 바꾸지 않고 common 방식으로 설정만 바꿀 수 있습니다.

## `text2sql_agent/llm.py`

LLM 호출과 embedding 호출을 담당합니다.

### `_get_common_llm_client()`

```python
def _get_common_llm_client():
```

동작 순서:

1. 이미 만든 client가 있으면 cached client를 반환합니다.
2. `VLLM_TRANSPORT == "bedrock_converse"`이면 common OpenAI client를 쓰지 않고 `None`을 반환합니다.
3. `COMMON_CONFIG`에 `llm` 섹션이 있으면 `KBCardOpenAI.from_config(COMMON_CONFIG, default_model=VLLM_MODEL)`를 사용합니다.
4. common YAML이 없으면 `KBCardOpenAI.from_endpoint(...)`로 기존 환경 변수 기반 endpoint를 직접 구성합니다.
5. common 패키지가 없으면 `None`을 반환하고 raw HTTP fallback을 사용합니다.

### `_call_llm(prompt)`

```python
def _call_llm(prompt: str) -> str:
```

실제 chat completion 진입점입니다. workflow, schema, tool 코드가 모두 이 함수를 통해 LLM을 호출합니다.

동작 순서:

1. `VLLM_TRANSPORT == "bedrock_converse"`이면 `_call_bedrock_converse(prompt)`로 Bedrock native Converse API를 호출합니다.
2. 아니면 `_get_common_llm_client()`를 호출합니다.
3. common client가 있으면 `common_client.chat.completions.create(...)`를 사용합니다.
4. common client가 없으면 `requests.post(...)`로 OpenAI-compatible `/chat/completions` endpoint를 직접 호출합니다.
5. 응답은 `_normalize_llm_text(...)`를 거쳐 `<reasoning>...</reasoning>` 블록을 제거합니다.

### `_call_bedrock_converse(prompt)`

서울 리전처럼 Bedrock OpenAI-compatible path를 쓰기 어려운 경우를 위한 native Converse fallback입니다.

URL 형식:

```text
{VLLM_BASE_URL}/model/{model_id}/converse
```

이 경로는 `KBCardOpenAI` 호환 경로가 아니라 Bedrock native API입니다.

### `_get_common_embed_client()`

```python
def _get_common_embed_client():
```

동작 순서:

1. 이미 만든 embedding client가 있으면 cached client를 반환합니다.
2. `COMMON_CONFIG.embedding`이 있으면 `EmbeddingClient.from_config(COMMON_CONFIG)`를 사용합니다.
3. common config가 없으면 `TEIEmbeddingClient(base_url=..., model=...)`를 직접 만듭니다.
4. common 패키지가 없으면 `None`을 반환하고 raw HTTP fallback을 사용합니다.

### `_get_embedding(text)` / `_get_embeddings_batch(texts)`

embedding 호출 진입점입니다.

동작 순서:

1. common embedding client가 있으면 `embed_text(...)` 또는 `embed_texts(...)`를 사용합니다.
2. 없으면 `{VLLM_EMBED_URL}/v1/embeddings`에 OpenAI-compatible embedding request를 직접 보냅니다.

## `text2sql_agent/db.py`

PostgreSQL 연결과 SQL 실행을 담당합니다.

### `_get_pool()`

```python
def _get_pool() -> psycopg2.pool.ThreadedConnectionPool:
```

동작 순서:

1. connection pool이 이미 있으면 재사용합니다.
2. `DB_DSN`이 있으면 `ThreadedConnectionPool(1, DB_POOL_MAX, DB_DSN)`로 연결합니다.
3. `DB_DSN`이 없으면 `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` 개별 값으로 연결합니다.

즉 회사 환경에서는 `KBCARD_POSTGRES_DSN` 하나만 잡아도 되고, 로컬에서는 `DB_HOST` 등 개별 변수로도 실행할 수 있습니다.

### `execute_sql(sql)`

실제 SQL 실행 함수입니다.

주요 동작:

- `SELECT` 또는 `WITH`만 허용합니다.
- `INSERT`, `UPDATE`, `DELETE`, `DROP` 같은 위험 명령은 차단합니다.
- PostgreSQL session을 read-only로 설정합니다.
- 결과는 최대 500건만 가져옵니다.
- 성공/실패 모두 `_log_db_query(...)`를 통해 module event를 남깁니다.

## `text2sql_agent/common_services.py`

`kbcard-agent-common`의 observability와 error helper를 감싸는 adapter입니다.

### `get_common_logger()`

```python
KBCardLogger.configure(level=os.getenv("KBCARD_LOG_LEVEL", "INFO"))
```

common logger를 한 번 만들고 cache합니다.

### `create_trace_context(...)`

요청 단위 trace context를 만듭니다. `webservice_v1.py`의 query 처리에서 session/message id와 연결됩니다.

### `observability_context(...)`

common의 `observability_context`를 여는 함수입니다.

`AGENT_ENVIRONMENT`, `AGENT_SERVICE_NAME`은 `config.py`에서 확정된 값을 가져옵니다. 즉 YAML의 `agent.environment`, `agent.service_name`이 여기까지 전달됩니다.

### `emit_execution_log(...)`

요청 전체 결과를 `ExecutionLogRecord`로 남깁니다.

### `emit_module_event(...)`

LLM, embedding, DB 같은 모듈 단위 이벤트를 남깁니다. 현재 context 안에서 실행 중이면 common의 현재 context를 사용하고, context 밖이면 넘겨받은 context로 직접 기록합니다.

## `webservice_v1.py`

FastAPI entrypoint입니다.

### import 구조

`webservice_v1.py`는 보통 아래처럼 package를 import합니다.

```python
import text2sql_agent as agent
```

이때 `text2sql_agent/__init__.py`가 `config.py`의 `VLLM_*`, `BAD_DEBT_OUTPUT_DIR` 등을 다시 export합니다. 그래서 `webservice_v1.py`는 `agent.VLLM_MODEL`, `agent.VLLM_BASE_URL`처럼 접근합니다.

### `_run_query(...)`

동기 query 처리 흐름입니다.

1. `agent.create_trace_context(...)`로 trace context 생성
2. `with agent.observability_context(...)` 안에서 graph 실행
3. graph 내부에서 workflow가 `_call_llm(...)`, `_get_embedding(...)`, `execute_sql(...)` 등을 호출
4. graph 실행이 끝나면 `agent.emit_execution_log(...)`로 전체 실행 로그 기록

### `_stream_graph(...)`

SSE streaming query 처리 흐름입니다.

이 함수는 update 하나를 가져올 때만 `observability_context`를 열고 닫습니다. SSE yield 전체를 context 안에 두지 않는 이유는 Python `ContextVar` token이 다른 async context에서 reset되면서 아래 오류가 날 수 있기 때문입니다.

```text
Token was created in a different Context
```

즉 common observability context는 "graph 작업 한 단위"에만 걸고, client로 SSE chunk를 내보내는 구간에는 걸지 않습니다.

### `/api/health`

health endpoint는 현재 config가 만든 LLM 값을 사용합니다.

반환 예:

```json
{
  "ok": true,
  "model": "openai.gpt-oss-20b-1:0",
  "vllm_base_url": "https://bedrock-runtime.us-east-1.amazonaws.com",
  "llm_ready": true,
  "llm_probe": "chat"
}
```

`_llm_health()`는 먼저 models endpoint를 probe하고, 실패하면 chat completion probe로 fallback합니다.

## 환경별 설정 방법

### 로컬 vLLM + TEI embedding + PostgreSQL

`.env.local`:

```bash
KBCARD_CONFIG_PATH=config/agent.local.yaml
LLM_API_KEY=EMPTY
KBCARD_POSTGRES_DSN="host=127.0.0.1 port=5432 dbname=postgres user=postgres password=your-password"
```

`config/agent.local.yaml`:

```yaml
agent:
  name: text2sql-v4
  environment: local
  service_name: text2sql-v4-local

llm:
  model_registry_path: models.local.yaml
  default_model: local-chat
  temperature: 0
  max_tokens: 4096
  timeout: 120

embedding:
  provider: tei
  base_url: http://127.0.0.1:8001
  model: bge-m3
  api_key: null
  timeout: 60

retrieval:
  store:
    provider: postgres
    dsn_env: KBCARD_POSTGRES_DSN
    pool_max_size: 10
```

`config/models.local.yaml`:

```yaml
models:
  local-chat:
    provider: vllm
    base_url: http://127.0.0.1:8000
    endpoint_path: /v1/chat/completions
    api_key_env: LLM_API_KEY
    timeout: 120
```

### Bedrock OpenAI-compatible LLM + local embedding

`.env.local`:

```bash
KBCARD_CONFIG_PATH=config/agent.local.yaml
AWS_BEARER_TOKEN_BEDROCK=...
KBCARD_POSTGRES_DSN="host=127.0.0.1 port=5432 dbname=postgres user=postgres password=your-password"
```

`config/agent.local.yaml`의 `llm.default_model`:

```yaml
llm:
  model_registry_path: models.local.yaml
  default_model: openai.gpt-oss-20b-1:0
```

`config/models.local.yaml`:

```yaml
models:
  "openai.gpt-oss-20b-1:0":
    provider: bedrock
    base_url: https://bedrock-runtime.us-east-1.amazonaws.com
    endpoint_path: /openai/v1/chat/completions
    api_key_env: AWS_BEARER_TOKEN_BEDROCK
    timeout: 120
```

## 우선순위 요약

값이 정해지는 우선순위는 다음과 같습니다.

1. `.env.local`
2. 실제 process 환경 변수
3. `.env`
4. `KBCARD_CONFIG_PATH`가 가리키는 common YAML과 model registry YAML
5. 코드 기본값

이 순서가 되는 이유는 `.env`는 기본 옵션으로 로드되어 이미 shell에 export된 값을 덮지 않고, `.env.local`은 `override=True`로 로드되어 같은 key가 있으면 shell export와 `.env` 값을 덮기 때문입니다. shell export 값을 반드시 우선하고 싶으면 `.env.local`에 같은 key를 두지 않아야 합니다.

## 디버깅 명령

현재 어떤 config가 잡혔는지 확인:

```bash
uv run python -c "from text2sql_agent.config import COMMON_CONFIG_PATH, COMMON_CONFIG, LLM_MODEL, LLM_BASE_URL, LLM_ENDPOINT_PATH, EMBED_MODEL, EMBED_BASE_URL, DB_DSN_ENV; print(COMMON_CONFIG_PATH); print(COMMON_CONFIG is not None); print(LLM_MODEL); print(LLM_BASE_URL); print(LLM_ENDPOINT_PATH); print(EMBED_MODEL); print(EMBED_BASE_URL); print(DB_DSN_ENV)"
```

LLM 호출 확인:

```bash
uv run python -c "from text2sql_agent.llm import _call_llm; print(_call_llm('Reply exactly OK'))"
```

embedding 호출 확인:

```bash
uv run python -c "from text2sql_agent.llm import _get_embedding; emb = _get_embedding('법인카드 매출 분석'); print(len(emb))"
```

서버 health 확인:

```bash
uv run uvicorn webservice_v1:app --host 0.0.0.0 --port 8080
```

다른 터미널에서:

```bash
curl http://127.0.0.1:8080/api/health
```
