"""Data ingestion contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class ParsedDocument:
    """Document loaded from a source before chunking."""

    id: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str | None = None


@dataclass(frozen=True)
class TextChunk:
    """Chunk generated from a parsed document."""

    id: str
    document_id: str
    content: str
    chunk_index: int
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str | None = None


@dataclass(frozen=True)
class EmbeddedChunk:
    """Chunk with a dense embedding ready for vector-store ingestion."""

    id: str
    document_id: str
    content: str
    embedding: list[float]
    chunk_index: int
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str | None = None
