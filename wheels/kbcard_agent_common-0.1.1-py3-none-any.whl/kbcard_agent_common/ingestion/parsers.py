"""Document parsers that load a source file into the intermediate format.

Each parser implements the ``DocumentParser`` protocol (``parse(path) ->
ParsedDocument``). Lightweight parsers handle text/Markdown/XML directly; richer
formats are handled by adapters whose heavy dependencies are lazily imported and
gated behind optional extras:

- ``DoclingFileParser`` (PDF/DOCX/PPTX/XLSX/HTML) -> ``[docling]`` extra
- ``HwpFileParser`` (HWP/HWPX) -> ``[hwp]`` extra

Domain-structured parsing (e.g. a statute XML schema that yields article-level
chunks) is intentionally out of scope: register such a parser per extension on
an :class:`~kbcard_agent_common.ingestion.registry.ExtensionParserRegistry` to
override the generic default.
"""

from __future__ import annotations

import io
import re
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

from kbcard_agent_common.ingestion.types import ParsedDocument


def _read_document(path: str | Path, content: str) -> ParsedDocument:
    document_path = Path(path)
    return ParsedDocument(
        id=document_path.stem,
        content=content,
        metadata={"filename": document_path.name},
        source=str(document_path),
    )


def _local_name(tag: str) -> str:
    """Strip an XML namespace, e.g. ``{ns}t`` -> ``t``."""

    return tag.rsplit("}", 1)[-1]


class TextFileParser:
    """Load a plain-text file verbatim."""

    def __init__(self, *, encoding: str = "utf-8") -> None:
        self.encoding = encoding

    def parse(self, path: str | Path) -> ParsedDocument:
        return _read_document(path, Path(path).read_text(encoding=self.encoding))


class MarkdownFileParser:
    """Load a Markdown file as the canonical intermediate document format."""

    def __init__(self, *, encoding: str = "utf-8") -> None:
        self.encoding = encoding

    def parse(self, path: str | Path) -> ParsedDocument:
        return _read_document(path, Path(path).read_text(encoding=self.encoding))


class XmlFileParser:
    """Flatten arbitrary XML into text by concatenating element text.

    Generic and domain-neutral: it drops tags and keeps text content. For
    structured XML where the tag hierarchy carries meaning (statutes, etc.),
    register a schema-aware parser instead of relying on this default.
    """

    def __init__(self, *, encoding: str = "utf-8") -> None:
        self.encoding = encoding

    def parse(self, path: str | Path) -> ParsedDocument:
        root = ET.fromstring(Path(path).read_text(encoding=self.encoding))
        lines = [text.strip() for text in root.itertext() if text and text.strip()]
        return _read_document(path, "\n".join(lines))


class DoclingFileParser:
    """Convert rich document formats to Markdown text via ``docling``.

    Requires the optional ``[docling]`` extra. The (heavy) ``docling`` import
    and converter are deferred to the first :meth:`parse` call. OCR is disabled
    by default to avoid model downloads in restricted environments; enable it
    explicitly for scanned PDFs.
    """

    SUPPORTED_EXTENSIONS = (".pdf", ".docx", ".pptx", ".xlsx", ".html", ".htm")

    def __init__(self, *, do_ocr: bool = False) -> None:
        self.do_ocr = do_ocr
        self._converter = None

    def parse(self, path: str | Path) -> ParsedDocument:
        converter = self._ensure_converter()
        result = converter.convert(str(Path(path)))
        return _read_document(path, result.document.export_to_markdown())

    def _ensure_converter(self):  # noqa: ANN202 - external type
        if self._converter is None:
            try:
                from docling.datamodel.base_models import (  # type: ignore[reportMissingImports]
                    InputFormat,
                )
                from docling.datamodel.pipeline_options import (  # type: ignore[reportMissingImports]
                    PdfPipelineOptions,
                )
                from docling.document_converter import (  # type: ignore[reportMissingImports]
                    DocumentConverter,
                    PdfFormatOption,
                )
            except ImportError as exc:  # pragma: no cover - depends on optional extra
                raise ImportError(
                    "DoclingFileParser requires the optional 'docling' extra: "
                    "pip install 'kbcard-agent-common[docling]'"
                ) from exc
            pdf_options = PdfPipelineOptions(do_ocr=self.do_ocr)
            self._converter = DocumentConverter(
                format_options={
                    InputFormat.PDF: PdfFormatOption(pipeline_options=pdf_options),
                }
            )
        return self._converter


class HwpFileParser:
    """Extract text from HWP / HWPX documents.

    HWPX (a zip container) is read with the standard library. Legacy binary HWP
    uses ``hwpkit`` with an ``olefile`` preview-text fallback, both provided by
    the optional ``[hwp]`` extra.
    """

    SUPPORTED_EXTENSIONS = (".hwp", ".hwpx")

    def parse(self, path: str | Path) -> ParsedDocument:
        data = Path(path).read_bytes()
        if data[:4] == b"PK\x03\x04":  # HWPX is a zip archive
            content = self._extract_hwpx(data)
        else:
            content = self._extract_hwp(data, Path(path))
        return _read_document(path, content)

    def _extract_hwpx(self, data: bytes) -> str:
        parts: list[str] = []
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            sections = sorted(
                name
                for name in archive.namelist()
                if name.startswith("Contents/section") and name.endswith(".xml")
            )
            for name in sections:
                root = ET.fromstring(archive.read(name))
                for element in root.iter():
                    if _local_name(element.tag) == "t":
                        text = "".join(element.itertext()).strip()
                        if text:
                            parts.append(text)
        return "\n".join(parts).strip()

    def _extract_hwp(self, data: bytes, path: Path) -> str:
        text = ""
        try:
            text = _extract_with_hwpkit(path)
        except Exception:
            text = ""
        if not text:
            text = self._extract_olefile_preview(data)
        return text

    def _extract_olefile_preview(self, data: bytes) -> str:
        try:
            import olefile  # type: ignore[reportMissingImports]
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ImportError(
                "HwpFileParser requires the optional 'hwp' extra: "
                "pip install 'kbcard-agent-common[hwp]'"
            ) from exc
        ole = olefile.OleFileIO(io.BytesIO(data))
        try:
            raw = ole.openstream("PrvText").read()
        finally:
            ole.close()
        text = raw.decode("utf-16-le", errors="replace")
        return re.sub(r"[\x00-\x08\x0b-\x1f]", " ", text).strip()


def _extract_with_hwpkit(path: str | Path, timeout: int = 120) -> str:
    """Run ``hwpkit`` in a subprocess so a native crash cannot take us down."""

    import subprocess
    import sys

    script = (
        "import sys, hwpkit; "
        "sys.stdout.write(hwpkit.extract_text_from_hwp(sys.argv[1]) or '')"
    )
    result = subprocess.run(
        [sys.executable, "-c", script, str(path)],
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or f"hwpkit exit code {result.returncode}")
    return result.stdout.strip()
