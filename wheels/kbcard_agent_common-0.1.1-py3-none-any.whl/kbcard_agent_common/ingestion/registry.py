"""Extension-based parser dispatch.

:class:`ExtensionParserRegistry` itself satisfies the ``DocumentParser``
protocol, so it drops straight into ``IngestionPipeline(parser=registry, ...)``
and routes each file to the parser registered for its extension.
"""

from __future__ import annotations

import importlib.util
from pathlib import Path
from typing import TYPE_CHECKING

from kbcard_agent_common.errors import UnsupportedExtensionError
from kbcard_agent_common.ingestion.parsers import (
    DoclingFileParser,
    HwpFileParser,
    MarkdownFileParser,
    TextFileParser,
    XmlFileParser,
)
from kbcard_agent_common.ingestion.types import ParsedDocument

if TYPE_CHECKING:
    from kbcard_agent_common.ingestion.pipeline import DocumentParser


def _normalize_extension(extension: str) -> str:
    extension = extension.lower()
    return extension if extension.startswith(".") else f".{extension}"


class ExtensionParserRegistry:
    """Route a file to a parser based on its extension."""

    def __init__(self) -> None:
        self._parsers: dict[str, DocumentParser] = {}

    def register(self, extension: str, parser: DocumentParser) -> ExtensionParserRegistry:
        """Register ``parser`` for ``extension`` (overriding any existing one)."""

        self._parsers[_normalize_extension(extension)] = parser
        return self

    def register_many(
        self, extensions: tuple[str, ...], parser: DocumentParser
    ) -> ExtensionParserRegistry:
        for extension in extensions:
            self.register(extension, parser)
        return self

    def unregister(self, extension: str) -> None:
        self._parsers.pop(_normalize_extension(extension), None)

    @property
    def extensions(self) -> list[str]:
        return sorted(self._parsers)

    def supports(self, extension: str) -> bool:
        return _normalize_extension(extension) in self._parsers

    def parse(self, path: str | Path) -> ParsedDocument:
        extension = _normalize_extension(Path(path).suffix)
        parser = self._parsers.get(extension)
        if parser is None:
            supported = ", ".join(self.extensions) or "(none)"
            raise UnsupportedExtensionError(
                f"No parser registered for '{extension or Path(path).name}'. "
                f"Registered extensions: {supported}"
            )
        return parser.parse(path)


def default_parser_registry() -> ExtensionParserRegistry:
    """Build a registry with text/Markdown/XML built in and optional adapters.

    The ``docling`` and ``hwp`` adapters are registered only when their optional
    dependencies are importable, so the result reflects what the environment can
    actually parse. Callers can ``register`` additional or overriding parsers.
    """

    registry = ExtensionParserRegistry()
    registry.register(".txt", TextFileParser())
    registry.register_many((".md", ".markdown"), MarkdownFileParser())
    registry.register(".xml", XmlFileParser())

    if importlib.util.find_spec("docling") is not None:
        registry.register_many(DoclingFileParser.SUPPORTED_EXTENSIONS, DoclingFileParser())

    has_hwp_deps = (
        importlib.util.find_spec("hwpkit") is not None
        or importlib.util.find_spec("olefile") is not None
    )
    if has_hwp_deps:
        registry.register_many(HwpFileParser.SUPPORTED_EXTENSIONS, HwpFileParser())

    return registry
