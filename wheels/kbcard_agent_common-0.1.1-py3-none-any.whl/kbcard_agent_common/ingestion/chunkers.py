"""Chunking strategies for Markdown-centric ingestion."""

from __future__ import annotations

import re
from collections.abc import Sequence

from kbcard_agent_common.ingestion.tables import contains_box_table, split_box_tables
from kbcard_agent_common.ingestion.tokenization import TokenCounter, default_token_counter
from kbcard_agent_common.ingestion.types import ParsedDocument, TextChunk

#: General-purpose split boundaries, ordered coarse to fine. Each is zero-width or
#: whitespace-only so concatenating the resulting pieces reconstructs the source
#: text. Domain-specific boundaries (e.g. legal article markers) can be prepended
#: by passing a custom ``separators`` list to :class:`RecursiveTokenChunker`.
DEFAULT_SEPARATORS: tuple[str, ...] = (
    r"(?=\n#{1,6}\s)",  # before a Markdown heading line
    r"(?=\n\s*\n)",  # before a blank line (paragraph boundary)
    r"(?<=[.!?。])\s+",  # after sentence-ending punctuation (Latin + CJK)
)

LEGAL_SEPARATORS: tuple[str, ...] = (
    r"(?=\n?\s*제\d+(?:-\d+)?조(?:의\d+)?\s*\()",
    r"(?=\n?\s*제\d+(?:-\d+)?조(?:의\d+)?\s)",
    r"(?=\n?\s*부칙\s*)",
    r"(?=\n?\s*별표\s*\d*)",
)


class FixedSizeChunker:
    """Simple character-count chunker with optional overlap.

    Direct construction defaults to ``chunk_size=1200`` and
    ``chunk_overlap=150``. Config-based factories use ``ChunkerSettings``
    defaults: ``chunk_size=800`` and ``chunk_overlap=80``.
    """

    def __init__(self, *, chunk_size: int = 1200, chunk_overlap: int = 150) -> None:
        if chunk_size <= 0:
            raise ValueError("chunk_size must be positive")
        if chunk_overlap < 0:
            raise ValueError("chunk_overlap must be non-negative")
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def split(self, document: ParsedDocument) -> list[TextChunk]:
        content = document.content.strip()
        if not content:
            return []

        chunks: list[TextChunk] = []
        start = 0
        while start < len(content):
            end = min(start + self.chunk_size, len(content))
            chunk_text = _normalize_chunk(content[start:end])
            if chunk_text:
                chunk_index = len(chunks)
                chunks.append(
                    TextChunk(
                        id=f"{document.id}:{chunk_index}",
                        document_id=document.id,
                        content=chunk_text,
                        chunk_index=chunk_index,
                        metadata=dict(document.metadata),
                        source=document.source,
                    )
                )
            if end >= len(content):
                break
            start = end - self.chunk_overlap

        return chunks


class NoChunker:
    """Keep the full document as one chunk."""

    def split(self, document: ParsedDocument) -> list[TextChunk]:
        content = document.content.strip()
        if not content:
            return []
        return [
            TextChunk(
                id=f"{document.id}:0",
                document_id=document.id,
                content=content,
                chunk_index=0,
                metadata=dict(document.metadata),
                source=document.source,
            )
        ]


class AutoChunker:
    """Choose a practical chunking strategy from the parsed document text.

    Short documents are kept whole. Longer documents use
    :class:`RecursiveTokenChunker`; legal/terms-like article markers prepend
    article-aware separators so callers do not need to inspect each document
    manually before chunking.
    """

    def __init__(
        self,
        *,
        max_tokens: int = 600,
        min_tokens: int = 150,
        no_chunk_max_tokens: int = 300,
        token_counter: TokenCounter | None = None,
        preserve_tables: bool = True,
    ) -> None:
        if max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        if min_tokens < 0:
            raise ValueError("min_tokens must be non-negative")
        if min_tokens >= max_tokens:
            raise ValueError("min_tokens must be smaller than max_tokens")
        if no_chunk_max_tokens < 0:
            raise ValueError("no_chunk_max_tokens must be non-negative")
        self.max_tokens = max_tokens
        self.min_tokens = min_tokens
        self.no_chunk_max_tokens = no_chunk_max_tokens
        self.token_counter = token_counter or default_token_counter()
        self.preserve_tables = preserve_tables

    def split(self, document: ParsedDocument) -> list[TextChunk]:
        content = document.content.strip()
        if not content:
            return []
        if self.token_counter.count(content) <= self.no_chunk_max_tokens:
            return NoChunker().split(document)
        return self._chunker_for(content).split(document)

    def _chunker_for(self, content: str) -> RecursiveTokenChunker:
        separators = self._separators_for(content)
        return RecursiveTokenChunker(
            max_tokens=self.max_tokens,
            min_tokens=self.min_tokens,
            separators=separators,
            token_counter=self.token_counter,
            preserve_tables=self.preserve_tables,
        )

    def _separators_for(self, content: str) -> tuple[str, ...]:
        if _looks_like_legal_or_terms(content):
            return (*LEGAL_SEPARATORS, *DEFAULT_SEPARATORS)
        return DEFAULT_SEPARATORS


class RecursiveTokenChunker:
    """Token-bounded, structure-aware chunker.

    Splits text at the coarsest separator that keeps pieces within ``max_tokens``,
    recursing to finer separators only for pieces that are still too large, then
    merges undersized trailing pieces back into their predecessor so single short
    fragments do not degrade embedding quality. Box-drawing tables are kept intact
    (and header-split when oversized) when ``preserve_tables`` is enabled.

    The defaults are domain-neutral. Domain-specific structure can be injected by
    prepending patterns to ``separators`` (e.g. ``[r"(?=\\n제\\d+조)", *DEFAULT_SEPARATORS]``
    for Korean legal articles) without changing this class.
    """

    def __init__(
        self,
        *,
        max_tokens: int = 600,
        min_tokens: int = 150,
        separators: Sequence[str] | None = None,
        token_counter: TokenCounter | None = None,
        preserve_tables: bool = True,
    ) -> None:
        if max_tokens <= 0:
            raise ValueError("max_tokens must be positive")
        if min_tokens < 0:
            raise ValueError("min_tokens must be non-negative")
        if min_tokens >= max_tokens:
            raise ValueError("min_tokens must be smaller than max_tokens")
        self.max_tokens = max_tokens
        self.min_tokens = min_tokens
        self.separators = tuple(separators) if separators is not None else DEFAULT_SEPARATORS
        self.token_counter = token_counter or default_token_counter()
        self.preserve_tables = preserve_tables

    def split(self, document: ParsedDocument) -> list[TextChunk]:
        chunks: list[TextChunk] = []
        for content in self.split_text(document.content):
            chunk_index = len(chunks)
            chunks.append(
                TextChunk(
                    id=f"{document.id}:{chunk_index}",
                    document_id=document.id,
                    content=content,
                    chunk_index=chunk_index,
                    metadata=dict(document.metadata),
                    source=document.source,
                )
            )
        return chunks

    def split_text(self, text: str) -> list[str]:
        """Split raw text into normalized, token-bounded string pieces."""

        content = text.strip()
        if not content:
            return []
        pieces = self._merge_small(self._split(content, self.separators))
        return [normalized for normalized in map(_normalize_chunk, pieces) if normalized]

    def _count(self, text: str) -> int:
        return self.token_counter.count(text)

    def _split(self, text: str, separators: Sequence[str]) -> list[str]:
        if self._count(text) <= self.max_tokens:
            return [text]

        # Keep box-drawing tables atomic; recurse only into non-table overflow.
        if self.preserve_tables and contains_box_table(text):
            result: list[str] = []
            for segment in split_box_tables(text, max_tokens=self.max_tokens, count=self._count):
                if self._count(segment) > self.max_tokens and not contains_box_table(segment):
                    result.extend(self._split(segment, separators))
                else:
                    result.append(segment)
            return result

        if not separators:
            return self._hard_split(text)

        separator, rest = separators[0], separators[1:]
        pieces = _split_keep(text, separator)
        if len(pieces) <= 1:
            return self._split(text, rest)

        result = []
        buffer = ""
        for piece in pieces:
            if self._count(buffer + piece) <= self.max_tokens:
                buffer += piece
                continue
            if buffer:
                result.append(buffer)
            if self._count(piece) > self.max_tokens:
                result.extend(self._split(piece, rest))
                buffer = ""
            else:
                buffer = piece
        if buffer:
            result.append(buffer)
        return result

    def _hard_split(self, text: str) -> list[str]:
        """Last-resort character slice for text with no usable separators."""

        tokens = self._count(text)
        if tokens <= self.max_tokens:
            return [text]
        approx_chars = max(1, len(text) * self.max_tokens // tokens)
        return [text[start : start + approx_chars] for start in range(0, len(text), approx_chars)]

    def _merge_small(self, pieces: list[str]) -> list[str]:
        if len(pieces) <= 1:
            return pieces
        merged = [pieces[0]]
        for piece in pieces[1:]:
            if self._count(piece) < self.min_tokens:
                candidate = merged[-1] + "\n" + piece
                if self._count(candidate) <= self.max_tokens:
                    merged[-1] = candidate
                    continue
            merged.append(piece)
        return merged


def _split_keep(text: str, pattern: str) -> list[str]:
    """Split ``text`` at ``pattern`` while preserving every character.

    Each separator is reattached to the preceding piece, so ``"".join(pieces)``
    reconstructs the original ``text`` regardless of whether ``pattern`` is
    zero-width (lookaround) or whitespace-consuming.
    """

    tokens = re.split(f"({pattern})", text)
    pieces: list[str] = []
    for index in range(0, len(tokens), 2):
        body = tokens[index]
        separator = tokens[index + 1] if index + 1 < len(tokens) else ""
        combined = body + separator
        if combined:
            pieces.append(combined)
    return pieces


def _normalize_chunk(text: str) -> str:
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _looks_like_legal_or_terms(text: str) -> bool:
    article_count = len(re.findall(r"(?:^|\n)\s*제\d+(?:-\d+)?조(?:의\d+)?(?:\s|\()", text))
    if article_count >= 2:
        return True
    appendix_count = len(re.findall(r"(?:^|\n)\s*(?:부칙|별표\s*\d*)", text))
    return article_count >= 1 and appendix_count >= 1
