"""Composable ingestion pipeline."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Protocol

from kbcard_agent_common.embedding import EmbeddingService
from kbcard_agent_common.ingestion.types import EmbeddedChunk, ParsedDocument, TextChunk


class DocumentParser(Protocol):
    """Load one source into a parsed document."""

    def parse(self, path: str | Path) -> ParsedDocument: ...


class Chunker(Protocol):
    """Split a parsed document into chunks."""

    def split(self, document: ParsedDocument) -> list[TextChunk]: ...


class IngestionStore(Protocol):
    """Storage contract required by ingestion."""

    def ensure_collection(self) -> None: ...

    def upsert(self, chunks: list[EmbeddedChunk]) -> None: ...


class IngestionLogSink(Protocol):
    """Logger surface used by ingestion without forcing one implementation."""

    def info(self, message: str, **metadata: Any) -> Any: ...

    def error(self, message: str, **metadata: Any) -> Any: ...


class IngestionPipeline:
    """Parser -> chunker -> embedder -> vector store orchestration."""

    def __init__(
        self,
        *,
        parser: DocumentParser,
        chunker: Chunker,
        embedder: EmbeddingService,
        store: IngestionStore,
        logger: IngestionLogSink | logging.Logger | None = None,
    ) -> None:
        self.parser = parser
        self.chunker = chunker
        self.embedder = embedder
        self.store = store
        self.logger = logger or logging.getLogger(__name__)

    def ingest_file(self, path: str | Path) -> list[EmbeddedChunk]:
        """Ingest one local file and return the stored chunks."""

        source_path = Path(path)
        self._log_info("ingestion file started", path=str(source_path))
        try:
            document = self.parser.parse(source_path)
        except Exception as exc:
            self._log_error(
                "ingestion parse failed",
                path=str(source_path),
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        self._log_info(
            "ingestion file parsed",
            path=str(source_path),
            document_id=document.id,
            content_chars=len(document.content),
        )
        try:
            chunks = self.chunker.split(document)
        except Exception as exc:
            self._log_error(
                "ingestion chunking failed",
                path=str(source_path),
                document_id=document.id,
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        self._log_info(
            "ingestion document chunked",
            document_id=document.id,
            chunk_count=len(chunks),
        )
        return self.ingest_chunks(chunks)

    def ingest_chunks(self, chunks: list[TextChunk]) -> list[EmbeddedChunk]:
        """Embed and upsert already prepared chunks."""

        if not chunks:
            self._log_info("ingestion skipped empty chunks", chunk_count=0)
            return []

        try:
            embeddings = self.embedder.embed_texts([chunk.content for chunk in chunks])
        except Exception as exc:
            self._log_error(
                "ingestion embedding failed",
                chunk_count=len(chunks),
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        self._log_info(
            "ingestion chunks embedded",
            chunk_count=len(chunks),
            embedding_count=len(embeddings),
        )
        try:
            embedded = [
                EmbeddedChunk(
                    id=chunk.id,
                    document_id=chunk.document_id,
                    content=chunk.content,
                    embedding=embedding,
                    chunk_index=chunk.chunk_index,
                    metadata=dict(chunk.metadata),
                    source=chunk.source,
                )
                for chunk, embedding in zip(chunks, embeddings, strict=True)
            ]
        except Exception as exc:
            self._log_error(
                "ingestion embedding normalization failed",
                chunk_count=len(chunks),
                embedding_count=len(embeddings),
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise
        try:
            self.store.ensure_collection()
            self.store.upsert(embedded)
        except Exception as exc:
            self._log_error(
                "ingestion upsert failed",
                chunk_count=len(embedded),
                error_type=type(exc).__name__,
                error=str(exc),
            )
            raise

        self._log_info("ingestion chunks upserted", chunk_count=len(embedded))
        return embedded

    def _log_info(self, message: str, **metadata: Any) -> None:
        self._log(logging.INFO, message, metadata)

    def _log_error(self, message: str, **metadata: Any) -> None:
        self._log(logging.ERROR, message, metadata)

    def _log(self, level: int, message: str, metadata: dict[str, Any]) -> None:
        if isinstance(self.logger, logging.Logger):
            self.logger.log(level, message, extra={"kbcard_metadata": metadata})
            return

        if level >= logging.ERROR:
            self.logger.error(message, **metadata)
        else:
            self.logger.info(message, **metadata)
