"""Pluggable token counting for chunking.

Chunkers reason about token budgets rather than character counts so that chunk
sizes line up with embedding/LLM context limits regardless of language (CJK text
packs far more tokens per character than Latin text).

The default counter prefers :class:`TiktokenCounter` when the optional ``tokenize``
extra is installed and otherwise falls back to a dependency-free heuristic, so the
core package stays lightweight.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class TokenCounter(Protocol):
    """Count the number of tokens in a piece of text."""

    def count(self, text: str) -> int: ...


class HeuristicTokenCounter:
    """Estimate tokens from character count without any external dependency.

    A rough ``len(text) / chars_per_token`` approximation. Good enough to keep
    chunk sizes in the right ballpark when ``tiktoken`` is unavailable.
    """

    def __init__(self, *, chars_per_token: int = 4) -> None:
        if chars_per_token <= 0:
            raise ValueError("chars_per_token must be positive")
        self.chars_per_token = chars_per_token

    def count(self, text: str) -> int:
        return max(1, len(text) // self.chars_per_token)


class TiktokenCounter:
    """Token counter backed by ``tiktoken`` (install the ``tokenize`` extra)."""

    def __init__(self, encoding: str = "cl100k_base") -> None:
        try:
            import tiktoken  # type: ignore[reportMissingImports]
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ImportError(
                "TiktokenCounter requires the optional 'tokenize' extra: "
                "pip install 'kbcard-agent-common[tokenize]'"
            ) from exc
        self._encoding = tiktoken.get_encoding(encoding)

    def count(self, text: str) -> int:
        return len(self._encoding.encode(text))


def default_token_counter() -> TokenCounter:
    """Return a :class:`TiktokenCounter` when available, else the heuristic one."""

    try:
        return TiktokenCounter()
    except ImportError:
        return HeuristicTokenCounter()
