"""Box-drawing table-aware splitting helpers.

Keeps box-drawing tables (``┌ ┐ └ ┘ ├ ┤``) intact while splitting oversized
content, and splits a single oversized table row-group-wise while repeating its
header so every piece keeps its column context.

These helpers are format-agnostic: they trigger purely on the box-drawing
characters present in the text (e.g. produced by Markdown or PDF table
exporters), never on any document domain.
"""

from __future__ import annotations

import re
from collections.abc import Callable

#: Top-left corner that marks the start of a box-drawing table block.
BOX_TABLE_CHAR = "┌"

_TABLE_BLOCK_RE = re.compile(r"(┌[^┌]*?┘)", re.DOTALL)


def contains_box_table(text: str) -> bool:
    """Return whether ``text`` contains at least one box-drawing table block."""

    return BOX_TABLE_CHAR in text


def split_box_tables(
    text: str,
    *,
    max_tokens: int,
    count: Callable[[str], int],
) -> list[str]:
    """Split ``text`` at table boundaries, keeping each table block atomic.

    Surrounding prose is packed together with adjacent tables up to ``max_tokens``.
    A single table block that exceeds ``max_tokens`` is delegated to
    :func:`split_box_table_with_header` for header-preserving row splitting.
    """

    segments = _TABLE_BLOCK_RE.split(text)

    result: list[str] = []
    buffer = ""

    for segment in segments:
        stripped = segment.strip()
        if not stripped:
            buffer += segment
            continue

        is_table = stripped.startswith(BOX_TABLE_CHAR)

        if is_table and count(stripped) > max_tokens:
            if buffer.strip():
                result.append(buffer.strip())
                buffer = ""
            result.extend(
                split_box_table_with_header(stripped, max_tokens=max_tokens, count=count)
            )
            continue

        candidate = (buffer + "\n" + segment).strip() if buffer.strip() else stripped
        if count(candidate) > max_tokens and buffer.strip():
            result.append(buffer.strip())
            buffer = segment
        else:
            buffer = (buffer + "\n" + segment) if buffer else segment

    if buffer.strip():
        result.append(buffer.strip())

    return result or [text]


def split_box_table_with_header(
    table_text: str,
    *,
    max_tokens: int,
    count: Callable[[str], int],
) -> list[str]:
    """Split one box-drawing table into row-group chunks, repeating the header.

    Preserves meaning by:
      - copying the header rows (everything before the first outer separator) onto
        every chunk so each piece keeps its column labels,
      - treating outer separators (``├…┤`` / ``├…┘``) as logical row boundaries,
      - keeping a single logical row intact even if it exceeds ``max_tokens``.
    """

    lines = [line for line in table_text.split("\n") if line.strip()]
    if not lines:
        return [table_text]

    top_line = lines[0]

    first_sep_idx: int | None = None
    for index, line in enumerate(lines[1:], 1):
        if line.strip().startswith("├"):
            first_sep_idx = index
            break

    if first_sep_idx is None:
        return [table_text]

    header_rows = lines[1:first_sep_idx]
    header_sep = lines[first_sep_idx]
    bottom_line = lines[-1]
    data_lines = lines[first_sep_idx + 1 : -1]

    header_block = "\n".join([top_line, *header_rows, header_sep])

    groups: list[list[str]] = []
    current: list[str] = []
    for line in data_lines:
        stripped = line.strip()
        is_outer_sep = stripped.startswith("├") and (
            stripped.endswith("┤") or stripped.endswith("┘")
        )
        if is_outer_sep:
            if current:
                groups.append(current)
            current = [line]
        else:
            current.append(line)
    if current:
        groups.append(current)

    if not groups:
        return [table_text]

    result: list[str] = []
    current_rows: list[str] = []

    for group in groups:
        candidate_rows = current_rows + group
        candidate = header_block + "\n" + "\n".join(candidate_rows) + "\n" + bottom_line
        if count(candidate) > max_tokens and current_rows:
            chunk = header_block + "\n" + "\n".join(current_rows) + "\n" + bottom_line
            result.append(chunk)
            current_rows = group
        else:
            current_rows = candidate_rows

    if current_rows:
        result.append(header_block + "\n" + "\n".join(current_rows) + "\n" + bottom_line)

    return result if len(result) > 1 else [table_text]
