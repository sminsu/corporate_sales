"""Document ingestion contracts."""

from kbcard_agent_common.ingestion.chunkers import (
    DEFAULT_SEPARATORS,
    LEGAL_SEPARATORS,
    AutoChunker,
    FixedSizeChunker,
    NoChunker,
    RecursiveTokenChunker,
)
from kbcard_agent_common.ingestion.parsers import (
    DoclingFileParser,
    HwpFileParser,
    MarkdownFileParser,
    TextFileParser,
    XmlFileParser,
)
from kbcard_agent_common.ingestion.pipeline import IngestionPipeline
from kbcard_agent_common.ingestion.registry import (
    ExtensionParserRegistry,
    default_parser_registry,
)
from kbcard_agent_common.ingestion.tables import (
    contains_box_table,
    split_box_table_with_header,
    split_box_tables,
)
from kbcard_agent_common.ingestion.tokenization import (
    HeuristicTokenCounter,
    TiktokenCounter,
    TokenCounter,
    default_token_counter,
)
from kbcard_agent_common.ingestion.types import EmbeddedChunk, ParsedDocument, TextChunk

__all__ = [
    "DEFAULT_SEPARATORS",
    "DoclingFileParser",
    "EmbeddedChunk",
    "ExtensionParserRegistry",
    "AutoChunker",
    "FixedSizeChunker",
    "HeuristicTokenCounter",
    "HwpFileParser",
    "IngestionPipeline",
    "MarkdownFileParser",
    "NoChunker",
    "ParsedDocument",
    "RecursiveTokenChunker",
    "LEGAL_SEPARATORS",
    "TextChunk",
    "TextFileParser",
    "TiktokenCounter",
    "TokenCounter",
    "XmlFileParser",
    "contains_box_table",
    "default_parser_registry",
    "default_token_counter",
    "split_box_table_with_header",
    "split_box_tables",
]
