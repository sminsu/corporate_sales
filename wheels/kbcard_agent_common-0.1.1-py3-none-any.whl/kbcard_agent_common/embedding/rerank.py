"""Reranker contracts and TEI provider."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

import httpx

from kbcard_agent_common.errors import ProviderError, RetryableProviderError

if TYPE_CHECKING:
    from kbcard_agent_common.config import KBCardConfig, RerankerSettings


@dataclass(frozen=True)
class RerankResult:
    """One reranked document result."""

    index: int
    score: float
    text: str | None = None
    raw: dict[str, Any] | None = None


class RerankingService(Protocol):
    """Minimal reranking contract."""

    def rerank(
        self, query: str, documents: list[str], *, top_k: int | None = None
    ) -> list[RerankResult]:
        """Rerank document texts for a query."""
        ...


class RerankerClient:
    """공통 SDK 설정으로 결과 재정렬(Rerank)을 수행하는 클라이언트입니다."""

    def __init__(
        self,
        settings: RerankerSettings,
        *,
        http_client: httpx.Client | None = None,
    ) -> None:
        """TEI 리랭커 프로바이더 설정을 기반으로 통신 클라이언트를 생성합니다."""
        if settings.provider != "tei":
            raise ProviderError(f"unsupported reranker provider: {settings.provider}")
        self._client = TEIRerankerClient(
            base_url=settings.base_url,
            model=settings.model,
            endpoint_path=settings.endpoint_path,
            api_key=settings.api_key,
            timeout=settings.timeout,
            batch_size=settings.batch_size,
            extra_headers=settings.extra_headers,
            http_client=http_client,
        )

    @classmethod
    def from_config(
        cls,
        config: KBCardConfig,
        *,
        http_client: httpx.Client | None = None,
    ) -> RerankerClient:
        """이미 로드된 agent config 객체의 reranker 설정으로 client를 생성한다."""
        return cls(config.require_reranker(), http_client=http_client)

    def rerank(
        self, query: str, documents: list[str], *, top_k: int | None = None
    ) -> list[RerankResult]:
        """쿼리 문장과 일차 후보 문서 목록을 입력받아 의미론적 유사도 기반 재정렬을 수행합니다."""
        return self._client.rerank(query, documents, top_k=top_k)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> RerankerClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class TEIRerankerClient:
    """Synchronous TEI reranker client.

    Hugging Face TEI deployments commonly expose reranking through either
    `/rerank` or `/v1/rerank`. The endpoint path is configurable because
    internal gateways may normalize it differently.
    """

    def __init__(
        self,
        base_url: str,
        *,
        model: str | None = None,
        endpoint_path: str = "/rerank",
        api_key: str | None = None,
        timeout: float | httpx.Timeout | None = 30.0,
        batch_size: int | None = None,
        extra_headers: dict[str, str] | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        if batch_size is not None and batch_size < 1:
            raise ProviderError("TEI reranker batch_size must be greater than 0")
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.endpoint_path = "/" + endpoint_path.strip("/")
        self.batch_size = batch_size
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(timeout=timeout)
        self._headers = dict(extra_headers or {})
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

    def rerank(
        self, query: str, documents: list[str], *, top_k: int | None = None
    ) -> list[RerankResult]:
        if not documents:
            return []

        return self._rerank_in_batches(query, documents, top_k=top_k)

    def _rerank_in_batches(
        self,
        query: str,
        documents: list[str],
        *,
        top_k: int | None,
    ) -> list[RerankResult]:
        if top_k == 0:
            return []
        if self.batch_size is None or len(documents) <= self.batch_size:
            return self._request_rerank(query, documents, top_k=top_k)

        results: list[RerankResult] = []
        for offset in range(0, len(documents), self.batch_size):
            batch = documents[offset : offset + self.batch_size]
            batch_top_k = None if top_k is None else min(top_k, len(batch))
            batch_results = self._request_rerank(query, batch, top_k=batch_top_k)
            results.extend(
                RerankResult(
                    index=result.index + offset,
                    score=result.score,
                    text=result.text,
                    raw=result.raw,
                )
                for result in batch_results
            )

        ordered = sorted(results, key=lambda result: result.score, reverse=True)
        if top_k is None:
            return ordered
        return ordered[:top_k]

    def _request_rerank(
        self,
        query: str,
        documents: list[str],
        *,
        top_k: int | None,
    ) -> list[RerankResult]:
        payload: dict[str, Any] = {
            "query": query,
            "texts": documents,
        }
        if self.model:
            payload["model"] = self.model
        if top_k is not None:
            payload["top_n"] = top_k

        try:
            response = self._client.post(
                f"{self.base_url}{self.endpoint_path}",
                json=payload,
                headers=self._headers,
            )
        except httpx.TimeoutException as exc:
            raise RetryableProviderError("TEI rerank request timed out") from exc
        except httpx.TransportError as exc:
            raise RetryableProviderError("TEI rerank request failed") from exc

        if response.status_code in {408, 429, 500, 502, 503, 504}:
            raise RetryableProviderError(
                f"TEI rerank request failed with status {response.status_code}"
            )
        if response.status_code >= 400:
            raise ProviderError(f"TEI rerank request failed with status {response.status_code}")

        try:
            body = response.json()
        except ValueError as exc:
            raise ProviderError("TEI rerank response is not valid JSON") from exc

        return _parse_rerank_results(body, documents=documents)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> TEIRerankerClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _parse_rerank_results(body: Any, *, documents: list[str]) -> list[RerankResult]:
    if isinstance(body, dict) and isinstance(body.get("results"), list):
        rows = body["results"]
    elif isinstance(body, list):
        rows = body
    else:
        raise ProviderError("TEI rerank response does not contain results")

    results = []
    for row in rows:
        if not isinstance(row, dict):
            raise ProviderError("TEI rerank result must be an object")
        index = _coerce_int(row.get("index"))
        score = _coerce_float(row.get("score", row.get("relevance_score")))
        text = row.get("text")
        results.append(
            RerankResult(
                index=index,
                score=score,
                text=text if isinstance(text, str) else documents[index],
                raw=row,
            )
        )
    return results


def _coerce_int(value: Any) -> int:
    if not isinstance(value, int):
        raise ProviderError("TEI rerank result index must be an integer")
    return value


def _coerce_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ProviderError("TEI rerank result score must be numeric") from exc

