"""Embedding service protocol."""

from typing import Protocol


class EmbeddingService(Protocol):
    """Minimal text embedding contract used by ingestion and retrieval."""

    def embed_text(self, text: str) -> list[float]:
        """Embed one text value."""
        ...

    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple text values preserving input order."""
        ...
