"""Embedding client contracts and providers."""

from kbcard_agent_common.embedding.base import EmbeddingService
from kbcard_agent_common.embedding.rerank import (
    RerankerClient,
    RerankingService,
    RerankResult,
    TEIRerankerClient,
)
from kbcard_agent_common.embedding.tei import EmbeddingClient, TEIEmbeddingClient

__all__ = [
    "EmbeddingClient",
    "EmbeddingService",
    "RerankerClient",
    "RerankingService",
    "RerankResult",
    "TEIEmbeddingClient",
    "TEIRerankerClient",
]
