"""TEI embedding client.

The current KB Card embedding service is served through Hugging Face Text
Embeddings Inference. This client targets the OpenAI-compatible
``/v1/embeddings`` endpoint exposed by TEI.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import httpx

from kbcard_agent_common.errors import ProviderError, RetryableProviderError

if TYPE_CHECKING:
    from kbcard_agent_common.config import EmbeddingSettings, KBCardConfig


class EmbeddingClient:
    """공통 SDK 설정을 입력받아 기본 TEI 엔진과 연결을 주도하는 구체 임베딩 클라이언트입니다."""

    def __init__(
        self,
        settings: EmbeddingSettings,
        *,
        http_client: httpx.Client | None = None,
    ) -> None:
        """TEI 프로바이더에 적합한 구체 설정을 로드하고 HTTP 통신 클라이언트를 생성합니다."""
        if settings.provider != "tei":
            raise ProviderError(f"unsupported embedding provider: {settings.provider}")
        self._client = TEIEmbeddingClient(
            base_url=settings.base_url,
            model=settings.model,
            api_key=settings.api_key,
            timeout=settings.timeout,
            extra_headers=settings.extra_headers,
            http_client=http_client,
        )

    @classmethod
    def from_config(
        cls,
        config: KBCardConfig,
        *,
        http_client: httpx.Client | None = None,
    ) -> EmbeddingClient:
        """이미 로드된 agent config 객체의 embedding 설정으로 client를 생성한다."""
        return cls(config.require_embedding(), http_client=http_client)

    def embed_text(self, text: str) -> list[float]:
        """단일 텍스트 문장에 대한 벡터 임베딩을 생성합니다."""
        return self._client.embed_text(text)

    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """복수 개의 텍스트 문장들에 대한 벡터 임베딩들을 대량(Batch) 생성합니다."""
        return self._client.embed_texts(texts)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> EmbeddingClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


class TEIEmbeddingClient:
    """Synchronous TEI embedding client."""

    def __init__(
        self,
        base_url: str,
        *,
        model: str | None = None,
        api_key: str | None = None,
        timeout: float | httpx.Timeout | None = 30.0,
        extra_headers: dict[str, str] | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self._owns_client = http_client is None
        self._client = http_client or httpx.Client(timeout=timeout)
        self._headers = dict(extra_headers or {})
        if api_key:
            self._headers["Authorization"] = f"Bearer {api_key}"

    def embed_text(self, text: str) -> list[float]:
        """Embed one text value."""

        return self.embed_texts([text])[0]

    def embed_texts(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts preserving input order."""

        if not texts:
            return []

        payload: dict[str, Any] = {"input": texts}
        if self.model:
            payload["model"] = self.model

        try:
            response = self._client.post(
                f"{self.base_url}/v1/embeddings",
                json=payload,
                headers=self._headers,
            )
        except httpx.TimeoutException as exc:
            raise RetryableProviderError("TEI embedding request timed out") from exc
        except httpx.TransportError as exc:
            raise RetryableProviderError("TEI embedding request failed") from exc

        if response.status_code in {408, 429, 500, 502, 503, 504}:
            raise RetryableProviderError(
                f"TEI embedding request failed with status {response.status_code}"
            )
        if response.status_code >= 400:
            raise ProviderError(f"TEI embedding request failed with status {response.status_code}")

        try:
            body = response.json()
        except ValueError as exc:
            raise ProviderError("TEI embedding response is not valid JSON") from exc

        return _parse_embeddings(body, expected_count=len(texts))

    def close(self) -> None:
        """Close the underlying HTTP client when this instance owns it."""

        if self._owns_client:
            self._client.close()

    def __enter__(self) -> TEIEmbeddingClient:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _parse_embeddings(body: Any, *, expected_count: int) -> list[list[float]]:
    if isinstance(body, list):
        embeddings = [_coerce_embedding(item) for item in body]
    elif isinstance(body, dict) and isinstance(body.get("data"), list):
        data = body["data"]
        indexed = sorted(
            enumerate(data),
            key=lambda pair: pair[1].get("index", pair[0])
            if isinstance(pair[1], dict)
            else pair[0],
        )
        embeddings = [
            _coerce_embedding(item["embedding"])
            for _, item in indexed
            if isinstance(item, dict) and "embedding" in item
        ]
    elif isinstance(body, dict) and isinstance(body.get("embeddings"), list):
        embeddings = [_coerce_embedding(item) for item in body["embeddings"]]
    else:
        raise ProviderError("TEI embedding response does not contain embeddings")

    if len(embeddings) != expected_count:
        raise ProviderError(
            "TEI embedding response count mismatch: "
            f"expected {expected_count}, got {len(embeddings)}"
        )
    return embeddings


def _coerce_embedding(value: Any) -> list[float]:
    if not isinstance(value, list):
        raise ProviderError("TEI embedding value must be a list")
    try:
        return [float(item) for item in value]
    except (TypeError, ValueError) as exc:
        raise ProviderError("TEI embedding value must contain numbers") from exc

