"""Common configuration models and YAML loader."""

from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, ConfigDict, Field, PrivateAttr, model_validator

from kbcard_agent_common.config.secrets import (
    SecretManagerSettings,
    SecretResolver,
    resolve_secret_refs,
)
from kbcard_agent_common.errors import ConfigurationError


class AgentSettings(BaseModel):
    """Agent identity and environment settings."""

    model_config = ConfigDict(extra="ignore")

    name: str
    environment: str = "local"
    service_name: str | None = None


class TracingSettings(BaseModel):
    """OpenTelemetry tracing settings."""

    model_config = ConfigDict(extra="ignore")

    enabled: bool = True
    exporter: Literal["console", "otlp", "none"] = "console"
    endpoint: str | None = None
    sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    batch: bool = True


class ObservabilitySettings(BaseModel):
    """Logging and tracing settings."""

    model_config = ConfigDict(extra="ignore")

    tracing: TracingSettings = Field(default_factory=TracingSettings)


class LLMSettings(BaseModel):
    """LLM defaults used by examples and client factories."""

    model_config = ConfigDict(extra="ignore")

    model_registry_path: Path
    default_model: str
    api_key: str | None = None
    temperature: float | None = 0.2
    max_tokens: int | None = None
    timeout: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    extra_body: dict[str, Any] = Field(default_factory=dict)
    extra_headers: dict[str, str] = Field(default_factory=dict)


class EmbeddingSettings(BaseModel):
    """Embedding endpoint settings."""

    model_config = ConfigDict(extra="ignore")

    provider: Literal["tei"] = "tei"
    base_url: str
    model: str | None = None
    api_key: str | None = None
    timeout: float | None = 30.0
    extra_headers: dict[str, str] = Field(default_factory=dict)


class RerankerSettings(BaseModel):
    """Reranker endpoint settings."""

    model_config = ConfigDict(extra="ignore")

    provider: Literal["tei"] = "tei"
    base_url: str
    model: str | None = None
    endpoint_path: str = "/rerank"
    api_key: str | None = None
    timeout: float | None = 30.0
    batch_size: int | None = Field(
        default=None,
        ge=1,
        description="Maximum number of documents sent to the reranker in one request.",
    )
    extra_headers: dict[str, str] = Field(default_factory=dict)


class ChunkerSettings(BaseModel):
    """Chunking strategy settings.

    Defaults intentionally use fixed-length character chunking:
    ``strategy=fixed_size``, ``chunk_size=800``, and ``chunk_overlap=80``.
    Token-aware strategies can opt into ``max_tokens=600`` and
    ``min_tokens=150`` without changing callers that rely on the baseline.
    """

    model_config = ConfigDict(extra="ignore")

    strategy: Literal["fixed_size", "no_chunk", "recursive_token", "auto"] = "fixed_size"
    chunk_size: int = Field(default=800, ge=1)
    chunk_overlap: int = Field(default=80, ge=0)
    max_tokens: int = Field(default=600, ge=1)
    min_tokens: int = Field(default=150, ge=0)
    no_chunk_max_tokens: int = Field(default=300, ge=0)
    preserve_tables: bool = True
    separator_profile: Literal["default", "legal"] = "default"
    separators: list[str] | None = None

    @model_validator(mode="after")
    def _validate_chunker_bounds(self) -> "ChunkerSettings":
        if self.chunk_overlap >= self.chunk_size:
            raise ValueError("chunk_overlap must be smaller than chunk_size")
        if self.min_tokens >= self.max_tokens:
            raise ValueError("min_tokens must be smaller than max_tokens")
        return self


class IngestionSettings(BaseModel):
    """Data ingestion settings."""

    model_config = ConfigDict(extra="ignore")

    parser: Literal["markdown", "text", "xml", "auto"] = "markdown"
    chunker: ChunkerSettings = Field(default_factory=ChunkerSettings)


class CustomChunkQuerySettings(BaseModel):
    """Named Postgres chunk query template for controlled escape hatches."""

    model_config = ConfigDict(extra="forbid")

    sql: str
    allowed_params: list[str] = Field(default_factory=list)
    default_limit: int = Field(default=5, ge=1)
    max_limit: int = Field(default=50, ge=1)

    @model_validator(mode="after")
    def _validate_limits(self) -> "CustomChunkQuerySettings":
        if self.default_limit > self.max_limit:
            raise ValueError("default_limit must be less than or equal to max_limit")
        reserved = {"limit"}
        if reserved.intersection(self.allowed_params):
            raise ValueError("custom query allowed_params cannot include reserved keys")
        for key in self.allowed_params:
            if key.startswith("filter_") or key == "collection_name":
                raise ValueError("custom query allowed_params cannot include reserved keys")
        return self


class CustomQuerySettings(BaseModel):
    """Named Postgres row query template for controlled escape hatches."""

    model_config = ConfigDict(extra="forbid")

    sql: str
    allowed_params: list[str] = Field(default_factory=list)
    default_limit: int = Field(default=50, ge=1)
    max_limit: int = Field(default=200, ge=1)

    @model_validator(mode="after")
    def _validate_limits(self) -> "CustomQuerySettings":
        if self.default_limit > self.max_limit:
            raise ValueError("default_limit must be less than or equal to max_limit")
        reserved = {"limit"}
        if reserved.intersection(self.allowed_params):
            raise ValueError("custom query allowed_params cannot include reserved keys")
        for key in self.allowed_params:
            if key.startswith("filter_") or key == "collection_name":
                raise ValueError("custom query allowed_params cannot include reserved keys")
        return self


class QueryTableSettings(BaseModel):
    """Registered Postgres table reference for named query templates."""

    model_config = ConfigDict(extra="forbid")

    table_name: str
    schema_name: str | None = None


class RetrievalStoreSettings(BaseModel):
    """Vector store settings."""

    model_config = ConfigDict(extra="forbid")

    provider: Literal["lancedb", "postgres"] = "lancedb"
    uri: str = ".kbcard-example/lancedb"
    dsn: str | None = Field(default=None, repr=False)
    dsn_env: str = "KBCARD_POSTGRES_DSN"
    schema_name: str | None = None
    table_name: str = "kbcard_chunks"
    vector_column: str = "vector"
    id_column: str = "id"
    chunk_id_column: str | None = None
    document_id_column: str | None = "document_id"
    document_id_metadata_key: str = "doc_id"
    parent_document_id_metadata_key: str = "parent_doc_id"
    chunk_index_column: str | None = "chunk_index"
    chunk_index_metadata_key: str = "chunk_index"
    content_column: str = "content"
    embedding_column: str = "embedding"
    metadata_column: str = "metadata"
    source_column: str | None = "source"
    source_metadata_key: str = "source_uri"
    collection_name: str | None = None
    collection_column: str | None = "collection_name"
    keyword_tsvector_column: str | None = "search_text"
    allowed_filter_keys: list[str] = Field(default_factory=list)
    custom_chunk_queries: dict[str, CustomChunkQuerySettings] = Field(default_factory=dict)
    custom_queries: dict[str, CustomQuerySettings] = Field(default_factory=dict)
    query_tables: dict[str, QueryTableSettings] = Field(default_factory=dict)
    pool_min_size: int = Field(default=1, ge=0)
    pool_max_size: int = Field(default=10, ge=1)
    pool_timeout: float = Field(default=5.0, gt=0.0)
    pool_max_lifetime: float = Field(default=1800.0, gt=0.0)
    pool_max_idle: float = Field(default=300.0, gt=0.0)
    pool_reconnect_timeout: float = Field(default=30.0, gt=0.0)
    autocommit: bool = True
    keepalives: bool = True
    keepalives_idle: int = Field(default=30, ge=1)
    keepalives_interval: int = Field(default=10, ge=1)
    keepalives_count: int = Field(default=3, ge=1)
    health_check_interval: float | None = Field(default=30.0, gt=0.0)
    retry_on_connection_error: bool = True

    @model_validator(mode="after")
    def _validate_pool_sizes(self) -> "RetrievalStoreSettings":
        if self.provider == "postgres" and self.pool_min_size > self.pool_max_size:
            raise ValueError("pool_min_size must be less than or equal to pool_max_size")
        return self


class RetrievalAdvancedSettings(BaseModel):
    """Low-level retrieval tuning knobs with safe defaults."""

    model_config = ConfigDict(extra="forbid")

    fetch_k: int = Field(
        default=50,
        ge=1,
        description="Number of candidate chunks fetched before final filtering or reranking.",
    )
    rerank_top_k: int = Field(
        default=10,
        ge=0,
        description="Number of candidates sent to the reranker. Set to 0 to disable reranking.",
    )
    hybrid_top_k: int = Field(
        default=10,
        ge=1,
        description="Candidate count requested from each side of hybrid vector/keyword search.",
    )
    ef_search: int = Field(
        default=800,
        ge=1,
        description=(
            "pgvector HNSW search width. Higher values can improve recall with more latency."
        ),
    )
    candidate_pool_size: int = Field(
        default=1000,
        ge=1,
        description="Maximum candidate pool size before scoring, merging, or reranking.",
    )
    length_weight: float = Field(
        default=0.0,
        ge=0.0,
        description="Optional length-based score adjustment weight for short chunk recall tuning.",
    )
    diversity_penalty_weight: float = Field(
        default=0.0,
        ge=0.0,
        description="Optional score penalty weight to reduce near-duplicate result concentration.",
    )
    diversity_metadata_key: str = Field(
        default="source",
        description="Metadata key used to group candidates for diversity penalty.",
    )


class RetrievalSettings(BaseModel):
    """Retrieval defaults and backing store settings."""

    model_config = ConfigDict(extra="forbid")

    store: RetrievalStoreSettings = Field(default_factory=RetrievalStoreSettings)
    top_k: int = Field(
        default=5,
        ge=1,
        description="Number of documents returned to the caller.",
    )
    search_type: Literal["vector", "keyword", "hybrid", "weighted_vector"] = Field(
        default="hybrid",
        description="Retrieval strategy. LanceDB examples currently use vector search only.",
    )
    score_threshold: float = Field(
        default=0.0,
        ge=0.0,
        description="Minimum final score required for a document to be returned.",
    )
    advanced: RetrievalAdvancedSettings = Field(
        default_factory=RetrievalAdvancedSettings,
        description="Low-level tuning settings. Most agents should use the defaults.",
    )


class LoggerSettings(BaseModel):
    """KBCardLogger.from_config에서 사용할 기본 로그 설정."""

    model_config = ConfigDict(extra="ignore")

    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "INFO"
    formatter: Literal["jsonl", "pretty"] = "pretty"
    output: Literal["stdout", "file", "both"] = "stdout"
    file_path: Path = Path("logs/kbcard-agent.jsonl")
    path_base: Literal["config_dir", "cwd"] = "config_dir"
    max_bytes: int = Field(default=10 * 1024 * 1024, ge=1)
    backup_count: int = Field(default=5, ge=0)


class KBCardConfig(BaseModel):
    """Top-level agent configuration."""

    model_config = ConfigDict(extra="ignore")

    _secret_resolver: SecretResolver | None = PrivateAttr(default=None)

    logger: LoggerSettings = Field(default_factory=LoggerSettings)
    agent: AgentSettings
    secrets: SecretManagerSettings = Field(default_factory=SecretManagerSettings)
    llm: LLMSettings | None = None
    embedding: EmbeddingSettings | None = None
    reranker: RerankerSettings | None = None
    ingestion: IngestionSettings = Field(default_factory=IngestionSettings)
    retrieval: RetrievalSettings = Field(default_factory=RetrievalSettings)
    observability: ObservabilitySettings = Field(default_factory=ObservabilitySettings)

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        *,
        secret_resolver: SecretResolver | None = None,
    ) -> "KBCardConfig":
        config_path = Path(path)
        with config_path.open(encoding="utf-8") as file:
            data = yaml.safe_load(file) or {}
        if not isinstance(data, dict):
            raise ConfigurationError("config yaml must contain a mapping")

        settings = SecretManagerSettings.model_validate(data.get("secrets") or {})
        data = resolve_secret_refs(data, secret_resolver=secret_resolver, settings=settings)
        config = cls.model_validate(data)
        config = config._resolve_paths(config_path.parent)
        config._secret_resolver = secret_resolver
        return config

    load = from_yaml

    def get_llm_settings(self) -> LLMSettings:
        """Return configured LLM settings or fail with a clear config error."""

        if self.llm is None:
            raise ConfigurationError("config must contain an 'llm' section")
        return self.llm

    def require_embedding(self) -> EmbeddingSettings:
        """Return embedding settings or fail with a clear config error."""

        if self.embedding is None:
            raise ConfigurationError("config must contain an 'embedding' section")
        return self.embedding

    def require_reranker(self) -> RerankerSettings:
        """Return reranker settings or fail with a clear config error."""

        if self.reranker is None:
            raise ConfigurationError("config must contain a 'reranker' section")
        return self.reranker

    @property
    def secret_resolver(self) -> SecretResolver | None:
        """Return an explicitly attached resolver, if config was loaded with one."""

        return self._secret_resolver

    def _resolve_paths(self, base_dir: Path) -> "KBCardConfig":
        updates: dict[str, Any] = {}

        if self.llm is not None:
            registry_path = self.llm.model_registry_path
            if not registry_path.is_absolute():
                updates["llm"] = self.llm.model_copy(
                    update={"model_registry_path": (base_dir / registry_path).resolve()}
                )

        if self.retrieval.store.provider == "lancedb":
            uri_path = Path(self.retrieval.store.uri)
            if not uri_path.is_absolute():
                updates["retrieval"] = self.retrieval.model_copy(
                    update={
                        "store": self.retrieval.store.model_copy(
                            update={"uri": str((base_dir / uri_path).resolve())}
                        )
                    }
                )

        log_file_path = self.logger.file_path
        if not log_file_path.is_absolute():
            log_base_dir = Path.cwd() if self.logger.path_base == "cwd" else base_dir
            updates["logger"] = self.logger.model_copy(
                update={"file_path": (log_base_dir / log_file_path).resolve()}
            )

        if not updates:
            return self
        return self.model_copy(update=updates)
