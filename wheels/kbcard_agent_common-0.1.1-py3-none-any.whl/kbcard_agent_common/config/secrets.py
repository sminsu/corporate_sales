"""Secret reference resolution for configuration loaders."""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any, Literal, Protocol

from pydantic import BaseModel, ConfigDict, Field

from kbcard_agent_common.errors import ConfigurationError


class SecretRef(BaseModel):
    """Reference to a value stored in an external secret backend."""

    model_config = ConfigDict(extra="forbid")

    secret_id: str
    key: str | None = None
    version_id: str | None = None
    version_stage: str | None = None


class SecretManagerSettings(BaseModel):
    """Settings used to create a secret resolver from config."""

    model_config = ConfigDict(extra="ignore")

    provider: Literal["aws_secrets_manager"] = "aws_secrets_manager"
    secret_id: str | None = None
    region_name: str | None = None
    profile_name: str | None = None
    endpoint_url: str | None = None
    cache_ttl_seconds: float = Field(default=300.0, ge=0.0)


class SecretResolver(Protocol):
    """Minimal contract for resolving secret references."""

    def resolve(self, ref: SecretRef) -> Any:
        """Return the concrete value for a secret reference."""
        ...


@dataclass
class _CachedSecret:
    value: str
    expires_at: float


class AwsSecretsManagerResolver:
    """AWS Secrets Manager-backed secret resolver."""

    def __init__(self, settings: SecretManagerSettings | None = None) -> None:
        self.settings = settings or SecretManagerSettings()
        self._client: Any | None = None
        self._cache: dict[tuple[str, str | None, str | None], _CachedSecret] = {}

    def resolve(self, ref: SecretRef) -> Any:
        secret_string = self._get_secret_string(ref)
        if ref.key is None:
            return secret_string

        try:
            secret_json = json.loads(secret_string)
        except json.JSONDecodeError as exc:
            raise ConfigurationError(
                f"secret {ref.secret_id!r} must contain JSON when key is specified"
            ) from exc
        if not isinstance(secret_json, dict):
            raise ConfigurationError(
                f"secret {ref.secret_id!r} must contain a JSON object when key is specified"
            )
        if ref.key not in secret_json:
            raise ConfigurationError(f"secret {ref.secret_id!r} does not contain key {ref.key!r}")
        return secret_json[ref.key]

    def _get_secret_string(self, ref: SecretRef) -> str:
        cache_key = (ref.secret_id, ref.version_id, ref.version_stage)
        now = time.monotonic()
        cached = self._cache.get(cache_key)
        if cached is not None and cached.expires_at >= now:
            return cached.value

        request: dict[str, Any] = {"SecretId": ref.secret_id}
        if ref.version_id is not None:
            request["VersionId"] = ref.version_id
        if ref.version_stage is not None:
            request["VersionStage"] = ref.version_stage
        response = self._get_client().get_secret_value(**request)

        if "SecretString" in response:
            secret_string = response["SecretString"]
        elif "SecretBinary" in response:
            secret_binary = response["SecretBinary"]
            if isinstance(secret_binary, str):
                secret_string = secret_binary
            else:
                secret_string = bytes(secret_binary).decode("utf-8")
        else:
            raise ConfigurationError(f"secret {ref.secret_id!r} did not contain a value")

        ttl = self.settings.cache_ttl_seconds
        if ttl > 0:
            self._cache[cache_key] = _CachedSecret(secret_string, now + ttl)
        return secret_string

    def _get_client(self) -> Any:
        if self._client is not None:
            return self._client

        try:
            import boto3  # type: ignore[reportMissingImports]
        except ImportError as exc:
            raise ConfigurationError(
                "boto3 is required to resolve AWS Secrets Manager references; "
                "install kbcard-agent-common[secrets]"
            ) from exc

        session_kwargs: dict[str, Any] = {}
        if self.settings.profile_name is not None:
            session_kwargs["profile_name"] = self.settings.profile_name
        if self.settings.region_name is not None:
            session_kwargs["region_name"] = self.settings.region_name

        session = boto3.Session(**session_kwargs)
        client_kwargs: dict[str, Any] = {}
        if self.settings.endpoint_url is not None:
            client_kwargs["endpoint_url"] = self.settings.endpoint_url
        self._client = session.client("secretsmanager", **client_kwargs)
        return self._client


def create_secret_resolver(settings: SecretManagerSettings | None = None) -> SecretResolver:
    """Create the resolver configured by `secrets` settings."""

    resolved_settings = settings or SecretManagerSettings()
    if resolved_settings.provider == "aws_secrets_manager":
        return AwsSecretsManagerResolver(resolved_settings)
    raise ConfigurationError(f"unsupported secret provider: {resolved_settings.provider}")


def resolve_secret_refs(
    data: Any,
    *,
    secret_resolver: SecretResolver | None = None,
    settings: SecretManagerSettings | None = None,
) -> Any:
    """Recursively replace value resolver mappings with concrete values."""

    if not contains_value_reference(data):
        return data
    resolved_settings = settings or SecretManagerSettings()
    return _resolve_config_values(data, resolver=secret_resolver, settings=resolved_settings)


def contains_secret_ref(data: Any) -> bool:
    """Return true when a nested value contains a secret reference."""

    if isinstance(data, dict):
        if "secret_ref" in data:
            return True
        return any(contains_secret_ref(value) for value in data.values())
    if isinstance(data, list):
        return any(contains_secret_ref(item) for item in data)
    return False


def contains_value_reference(data: Any) -> bool:
    """Return true when a nested value contains a value resolver mapping."""

    if isinstance(data, dict):
        if _is_value_reference_mapping(data) or "secret_ref" in data:
            return True
        return any(contains_value_reference(value) for value in data.values())
    if isinstance(data, list):
        return any(contains_value_reference(item) for item in data)
    return False


_VALUE_REFERENCE_KEYS = {"value", "env", "secret_ref", "default"}


def _resolve_config_values(
    data: Any,
    *,
    resolver: SecretResolver | None,
    settings: SecretManagerSettings,
) -> Any:
    if isinstance(data, dict):
        if _is_value_reference_mapping(data):
            return _resolve_value_reference(data, resolver=resolver, settings=settings)
        if "secret_ref" in data:
            raise ConfigurationError(
                "secret_ref can only be combined with value/env/default in a value mapping"
            )
        return {
            key: _resolve_config_values(value, resolver=resolver, settings=settings)
            for key, value in data.items()
        }
    if isinstance(data, list):
        return [_resolve_config_values(item, resolver=resolver, settings=settings) for item in data]
    return data


def _is_value_reference_mapping(data: dict[Any, Any]) -> bool:
    keys = set(data)
    return bool(keys.intersection(_VALUE_REFERENCE_KEYS)) and keys <= _VALUE_REFERENCE_KEYS


def _resolve_value_reference(
    data: dict[Any, Any],
    *,
    resolver: SecretResolver | None,
    settings: SecretManagerSettings,
) -> Any:
    if "value" in data:
        return data["value"]

    if "env" in data:
        env_name = data["env"]
        if not isinstance(env_name, str):
            raise ConfigurationError("env config reference must be a string")
        env_value = os.getenv(env_name)
        if env_value:
            return env_value

    if "secret_ref" in data:
        resolved_ref = _coerce_secret_ref(data["secret_ref"], settings=settings)
        resolved_resolver = resolver or create_secret_resolver(settings)
        return resolved_resolver.resolve(resolved_ref)

    if "default" in data:
        return data["default"]

    raise ConfigurationError(
        "config value reference must contain value, env, secret_ref, or default"
    )


def _coerce_secret_ref(raw_ref: Any, *, settings: SecretManagerSettings) -> SecretRef:
    if isinstance(raw_ref, str):
        if settings.secret_id is None:
            raise ConfigurationError(
                "secrets.secret_id is required when secret_ref is a string key"
            )
        return SecretRef(secret_id=settings.secret_id, key=raw_ref)

    if isinstance(raw_ref, dict):
        ref_data = dict(raw_ref)
        if "secret_id" not in ref_data and settings.secret_id is not None:
            ref_data["secret_id"] = settings.secret_id
        return SecretRef.model_validate(ref_data)

    raise ConfigurationError("secret_ref must be a string key or mapping")
