"""httpx로 OpenAI 호환 Chat Completions endpoint를 직접 호출한다."""

import json
import os
import re
from collections.abc import AsyncIterator, Iterator
from typing import Any

import httpx

from kbcard_agent_common.errors import ProviderError, RetryableProviderError
from kbcard_agent_common.llm.chat.models import (
    ChatCompletionChunk,
    ChatCompletionRequest,
    ChatCompletionResponse,
)
from kbcard_agent_common.llm.model_config.model_endpoints import ModelConfig


def create_openai_chat_completion(
    client: httpx.Client,
    request: ChatCompletionRequest,
    model_config: ModelConfig,
) -> ChatCompletionResponse | Iterator[ChatCompletionChunk]:
    """동기 httpx client를 공유해 OpenAI 호환 chat completion을 호출한다."""
    if request.stream:
        return _stream_chat_completion(client, request, model_config)

    try:
        response = client.post(
            model_config.endpoint_url,
            headers=_build_headers(model_config, request.extra_headers),
            params=request.extra_query or None,
            json=_build_openai_chat_completion_payload(request),
            timeout=request.timeout or model_config.timeout,
        )
        _raise_for_status(response, model_config.provider)
        raw = response.json()
    except httpx.TimeoutException as exc:
        raise RetryableProviderError(f"{model_config.provider} request timed out") from exc
    except httpx.TransportError as exc:
        raise RetryableProviderError(f"{model_config.provider} request failed") from exc
    except json.JSONDecodeError as exc:
        raise ProviderError(f"{model_config.provider} response must be valid JSON") from exc

    return _to_chat_completion_response(raw, provider=model_config.provider)


async def async_create_openai_chat_completion(
    client: httpx.AsyncClient,
    request: ChatCompletionRequest,
    model_config: ModelConfig,
) -> ChatCompletionResponse | AsyncIterator[ChatCompletionChunk]:
    """비동기 httpx client를 공유해 OpenAI 호환 chat completion을 호출한다."""
    if request.stream:
        return _async_stream_chat_completion(client, request, model_config)

    try:
        response = await client.post(
            model_config.endpoint_url,
            headers=_build_headers(model_config, request.extra_headers),
            params=request.extra_query or None,
            json=_build_openai_chat_completion_payload(request),
            timeout=request.timeout or model_config.timeout,
        )
        _raise_for_status(response, model_config.provider)
        raw = response.json()
    except httpx.TimeoutException as exc:
        raise RetryableProviderError(f"{model_config.provider} request timed out") from exc
    except httpx.TransportError as exc:
        raise RetryableProviderError(f"{model_config.provider} request failed") from exc
    except json.JSONDecodeError as exc:
        raise ProviderError(f"{model_config.provider} response must be valid JSON") from exc

    return _to_chat_completion_response(raw, provider=model_config.provider)


def _stream_chat_completion(
    client: httpx.Client,
    request: ChatCompletionRequest,
    model_config: ModelConfig,
) -> Iterator[ChatCompletionChunk]:
    """동기 SSE 응답을 ChatCompletionChunk iterator로 변환한다."""
    try:
        with client.stream(
            "POST",
            model_config.endpoint_url,
            headers=_build_headers(model_config, request.extra_headers),
            params=request.extra_query or None,
            json=_build_openai_chat_completion_payload(request),
            timeout=request.timeout or model_config.timeout,
        ) as response:
            _raise_for_status(response, model_config.provider)
            for line in response.iter_lines():
                chunk = _parse_sse_line(line, provider=model_config.provider)
                if chunk is not None:
                    yield chunk
    except httpx.TimeoutException as exc:
        raise RetryableProviderError(f"{model_config.provider} request timed out") from exc
    except httpx.TransportError as exc:
        raise RetryableProviderError(f"{model_config.provider} request failed") from exc


async def _async_stream_chat_completion(
    client: httpx.AsyncClient,
    request: ChatCompletionRequest,
    model_config: ModelConfig,
) -> AsyncIterator[ChatCompletionChunk]:
    """비동기 SSE 응답을 ChatCompletionChunk async iterator로 변환한다."""
    try:
        async with client.stream(
            "POST",
            model_config.endpoint_url,
            headers=_build_headers(model_config, request.extra_headers),
            params=request.extra_query or None,
            json=_build_openai_chat_completion_payload(request),
            timeout=request.timeout or model_config.timeout,
        ) as response:
            _raise_for_status(response, model_config.provider)
            async for line in response.aiter_lines():
                chunk = _parse_sse_line(line, provider=model_config.provider)
                if chunk is not None:
                    yield chunk
    except httpx.TimeoutException as exc:
        raise RetryableProviderError(f"{model_config.provider} request timed out") from exc
    except httpx.TransportError as exc:
        raise RetryableProviderError(f"{model_config.provider} request failed") from exc


def _build_openai_chat_completion_payload(request: ChatCompletionRequest) -> dict[str, Any]:
    """내부 요청 모델을 OpenAI 호환 JSON body로 변환한다."""
    payload: dict[str, Any] = {
        "model": request.model,
        "messages": [message.to_dict() for message in request.messages],
        "stream": request.stream,
    }
    if request.temperature is not None:
        payload["temperature"] = request.temperature
    if request.max_tokens is not None:
        payload["max_tokens"] = request.max_tokens
    if request.top_p is not None:
        payload["top_p"] = request.top_p
    if request.top_k is not None:
        payload["top_k"] = request.top_k
    payload.update(request.extra_body)
    return payload


def _build_headers(model_config: ModelConfig, extra_headers: dict[str, str]) -> dict[str, str]:
    """API key와 요청 단위 header를 합쳐 최종 HTTP header를 만든다."""
    headers = {"Content-Type": "application/json", **extra_headers}
    api_key = model_config.get_api_key()
    if api_key is not None and "Authorization" not in headers:
        headers["Authorization"] = f"Bearer {api_key}"
    return headers


def _parse_sse_line(line: str, *, provider: str) -> ChatCompletionChunk | None:
    """OpenAI 호환 SSE data line을 ChatCompletionChunk로 변환한다."""
    if not line or not line.startswith("data:"):
        return None
    data = line.removeprefix("data:").strip()
    if data == "[DONE]":
        return None
    try:
        raw = json.loads(data)
    except json.JSONDecodeError as exc:
        raise ProviderError(f"{provider} stream chunk must be valid JSON") from exc
    if not isinstance(raw, dict):
        raise ProviderError(f"{provider} stream chunk must be a JSON object")
    return ChatCompletionChunk(raw=raw)


def _to_chat_completion_response(response: Any, *, provider: str) -> ChatCompletionResponse:
    """dict 응답을 공통 ChatCompletionResponse로 변환한다."""
    if not isinstance(response, dict):
        raise ProviderError(f"{provider} response must be a JSON object")
    return ChatCompletionResponse(raw=response, provider=provider)


def _raise_for_status(response: httpx.Response, provider: str) -> None:
    """HTTP status code를 공통 provider 예외로 매핑한다."""
    status_code = response.status_code
    if status_code < 400:
        return
    response_body = _response_error_body(response)
    request_id = _response_request_id(response)
    message = _provider_error_message(
        provider=provider,
        status_code=status_code,
        response_body=response_body,
        request_id=request_id,
    )
    if status_code in {408, 429} or status_code >= 500:
        raise RetryableProviderError(
            message,
            provider=provider,
            status_code=status_code,
            response_body=response_body,
            request_id=request_id,
        )
    raise ProviderError(
        message,
        provider=provider,
        status_code=status_code,
        response_body=response_body,
        request_id=request_id,
    )


def _provider_error_message(
    *,
    provider: str,
    status_code: int,
    response_body: str | None,
    request_id: str | None,
) -> str:
    message = f"{provider} HTTP error: {status_code}"
    if request_id:
        message = f"{message} request_id={request_id}"
    if response_body:
        message = f"{message} body={response_body}"
    return message


def _response_request_id(response: httpx.Response) -> str | None:
    for header in (
        "x-request-id",
        "x-correlation-id",
        "x-amzn-requestid",
        "x-amz-request-id",
        "cf-ray",
    ):
        value = response.headers.get(header)
        if value:
            return value
    return None


def _response_error_body(response: httpx.Response) -> str | None:
    if os.getenv("KBCARD_PROVIDER_ERROR_INCLUDE_BODY", "true").lower() in {
        "0",
        "false",
        "no",
        "off",
    }:
        return None
    body = response.text.strip()
    if not body:
        return None
    return _truncate(_redact_sensitive_text(body), _provider_error_body_max_chars())


def _provider_error_body_max_chars() -> int:
    raw_value = os.getenv("KBCARD_PROVIDER_ERROR_BODY_MAX_CHARS")
    if raw_value is None:
        return 2048
    try:
        return max(0, int(raw_value))
    except ValueError:
        return 2048


def _redact_sensitive_text(value: str) -> str:
    value = re.sub(
        r'("?(?:api[_-]?key|authorization|secret|password|token)"?\s*[:=]\s*)"[^"]*"',
        r'\1"[REDACTED]"',
        value,
        flags=re.IGNORECASE,
    )
    value = re.sub(
        r"\b(api[_-]?key|authorization|secret|password|token)\s*[:=]\s*\S+",
        r"\1=[REDACTED]",
        value,
        flags=re.IGNORECASE,
    )
    return re.sub(
        r"\bBearer\s+[A-Za-z0-9._~+/=-]+",
        "Bearer [REDACTED]",
        value,
        flags=re.IGNORECASE,
    )


def _truncate(value: str, max_chars: int) -> str:
    if max_chars <= 0:
        return ""
    if len(value) <= max_chars:
        return value
    return f"{value[:max_chars]}...[truncated]"
