"""OpenAI 호환 endpoint 호출을 담당하는 내부 HTTP 연동 패키지."""
