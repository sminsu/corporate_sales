"""LLM 요청과 응답에서 공통으로 사용하는 데이터 타입."""

import json
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from typing import Any, Literal

ChatRole = Literal["system", "user", "assistant", "tool"]


@dataclass(frozen=True)
class ChatMessage:
    """OpenAI Chat Completions 요청에 들어가는 단일 메시지."""

    role: ChatRole | str
    content: Any = ""
    extra: dict[str, Any] = field(default_factory=dict, repr=False)
    include_content: bool = field(default=True, repr=False)

    @classmethod
    def from_dict(cls, message: Mapping[str, Any]) -> "ChatMessage":
        """OpenAI 호환 메시지 dict를 손실 없이 보존한다."""

        raw_message = getattr(message, "raw", message)
        role = raw_message.get("role")
        if not isinstance(role, str):
            raise ValueError("message must contain a string role")
        content = raw_message.get("content")
        extra = {
            key: value
            for key, value in raw_message.items()
            if key not in {"role", "content"}
        }
        return cls(
            role=role,
            content=content,
            extra=extra,
            include_content="content" in raw_message,
        )

    def to_dict(self) -> dict[str, Any]:
        """OpenAI 호환 JSON body에 넣을 수 있는 dict 형태로 메시지를 변환한다."""
        payload: dict[str, Any] = {"role": self.role, **self.extra}
        if self.include_content:
            payload["content"] = self.content
        return payload


type ChatMessageInput = ChatMessage | Mapping[str, Any]
type ChatMessagesInput = Iterable[ChatMessageInput]


@dataclass(frozen=True)
class ChatCompletionResponse:
    """provider 응답을 OpenAI 응답 형태로 정규화해서 담는 객체."""

    raw: dict[str, Any] = field(repr=False)
    provider: str | None = field(default=None, repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 ChatCompletion 객체와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"id={self.id!r}, "
            f"choices={self.choices!r}, "
            f"created={self.created!r}, "
            f"model={self.model!r}, "
            f"object={self.object!r}, "
            f"system_fingerprint={self.system_fingerprint!r}, "
            f"usage={self.usage!r}"
            ")"
        )

    @property
    def id(self) -> str | None:
        """OpenAI 응답의 id 값을 문자열이면 반환한다."""
        value = self.raw.get("id")
        return value if isinstance(value, str) else None

    @property
    def object(self) -> str | None:
        """OpenAI 응답의 object 값을 문자열이면 반환한다."""
        value = self.raw.get("object")
        return value if isinstance(value, str) else None

    @property
    def created(self) -> int | None:
        """OpenAI 응답의 created timestamp를 정수이면 반환한다."""
        value = self.raw.get("created")
        return value if isinstance(value, int) else None

    @property
    def model(self) -> str | None:
        """응답을 생성한 모델명을 문자열이면 반환한다."""
        value = self.raw.get("model")
        return value if isinstance(value, str) else None

    @property
    def system_fingerprint(self) -> str | None:
        """OpenAI 호환 응답의 system_fingerprint를 문자열이면 반환한다."""
        value = self.raw.get("system_fingerprint")
        return value if isinstance(value, str) else None

    @property
    def choices(self) -> list["ChatCompletionChoice"]:
        """OpenAI choices 배열을 안전한 wrapper 목록으로 반환한다."""
        value = self.raw.get("choices")
        if not isinstance(value, list):
            return []
        return [ChatCompletionChoice(choice) for choice in value if isinstance(choice, dict)]

    @property
    def usage(self) -> "ChatCompletionUsage":
        """token 사용량 정보를 wrapper로 반환하고, 없으면 빈 usage로 처리한다."""
        value = self.raw.get("usage")
        return ChatCompletionUsage(value if isinstance(value, dict) else {})

    @property
    def reasoning(self) -> str:
        """첫 번째 choice의 assistant message reasoning을 편의 속성으로 반환한다."""
        try:
            reasoning = self.choices[0]["message"]["reasoning"]
        except (IndexError, KeyError, TypeError):
            return ""
        return reasoning if isinstance(reasoning, str) else ""

    @property
    def finish_reason(self) -> str | None:
        """첫 번째 choice의 finish_reason을 편의 속성으로 반환한다."""
        try:
            return self.choices[0].finish_reason
        except IndexError:
            return None

    @property
    def tool_calls(self) -> list["ChatCompletionToolCall"]:
        """첫 번째 choice의 assistant message tool_calls를 편의 속성으로 반환한다."""
        try:
            return self.choices[0].message.tool_calls
        except IndexError:
            return []


@dataclass(frozen=True)
class ChatCompletionFunctionCall(Mapping[str, Any]):
    """OpenAI function tool call의 function payload wrapper."""

    raw: dict[str, Any] = field(repr=False)

    @property
    def name(self) -> str | None:
        """호출할 function 이름을 문자열이면 반환한다."""
        value = self.raw.get("name")
        return value if isinstance(value, str) else None

    @property
    def arguments(self) -> str:
        """모델이 생성한 function arguments JSON 문자열을 반환한다."""
        value = self.raw.get("arguments")
        return value if isinstance(value, str) else ""

    @property
    def arguments_dict(self) -> dict[str, Any]:
        """function arguments JSON 문자열을 dict로 파싱한다.

        malformed JSON은 `json.JSONDecodeError`로 그대로 올려 호출자가 정책을 정하게 한다.
        """
        value = json.loads(self.arguments or "{}")
        if isinstance(value, dict):
            return value
        raise ValueError("function arguments must decode to a JSON object")

    def parse_arguments(self, *, default: dict[str, Any] | None = None) -> dict[str, Any]:
        """function arguments를 dict로 파싱하고, 실패 시 선택적으로 기본값을 반환한다."""
        try:
            return self.arguments_dict
        except (json.JSONDecodeError, ValueError):
            if default is not None:
                return default
            raise

    def __getitem__(self, key: str) -> Any:
        """`function["arguments"]` 같은 dict 접근을 지원한다."""
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionToolCall(Mapping[str, Any]):
    """OpenAI tool call을 dict/attribute 방식으로 모두 읽게 해주는 wrapper."""

    raw: dict[str, Any] = field(repr=False)

    @property
    def id(self) -> str | None:
        """tool call id를 문자열이면 반환한다."""
        value = self.raw.get("id")
        return value if isinstance(value, str) else None

    @property
    def index(self) -> int | None:
        """streaming delta의 tool call index를 정수이면 반환한다."""
        value = self.raw.get("index")
        return value if isinstance(value, int) else None

    @property
    def type(self) -> str | None:
        """tool call type을 문자열이면 반환한다."""
        value = self.raw.get("type")
        return value if isinstance(value, str) else None

    @property
    def function(self) -> ChatCompletionFunctionCall:
        """function tool call payload를 안전한 wrapper로 반환한다."""
        value = self.raw.get("function")
        return ChatCompletionFunctionCall(value if isinstance(value, dict) else {})

    @property
    def name(self) -> str | None:
        """function tool call 이름을 바로 반환한다."""
        return self.function.name

    @property
    def arguments_dict(self) -> dict[str, Any]:
        """function tool call arguments를 dict로 파싱한다."""
        return self.function.arguments_dict

    def parse_arguments(self, *, default: dict[str, Any] | None = None) -> dict[str, Any]:
        """function tool call arguments를 dict로 파싱하고, 실패 시 기본값을 반환할 수 있다."""
        return self.function.parse_arguments(default=default)

    def __getitem__(self, key: str) -> Any:
        """`tool_call["function"]`는 wrapper를 반환하고 나머지는 원본 값을 반환한다."""
        if key == "function":
            return self.function
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionMessage(Mapping[str, Any]):
    """OpenAI assistant message를 dict/attribute 방식으로 모두 읽게 해주는 wrapper.

    응답 객체가 attribute 접근과 dict 접근을 모두 지원하도록 둔다.
    """

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 ChatCompletionMessage와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"content={self.content!r}, "
            f"role={self.role!r}, "
            f"reasoning={self.reasoning!r}, "
            f"tool_calls={self.tool_calls!r}"
            ")"
        )

    @property
    def role(self) -> str | None:
        """메시지 role을 문자열이면 반환한다."""
        value = self.raw.get("role")
        return value if isinstance(value, str) else None

    @property
    def content(self) -> str:
        """메시지 본문을 문자열로 반환하고, 없으면 빈 문자열을 반환한다."""
        value = self.raw.get("content")
        return value if isinstance(value, str) else ""

    @property
    def reasoning(self) -> str:
        """reasoning 모델이 내려주는 사고/추론 필드를 문자열로 반환한다."""
        value = self.raw.get("reasoning")
        return value if isinstance(value, str) else ""

    @property
    def tool_calls(self) -> list[ChatCompletionToolCall]:
        """assistant message의 tool_calls 배열을 wrapper 목록으로 반환한다."""
        value = self.raw.get("tool_calls")
        if not isinstance(value, list):
            return []
        return [ChatCompletionToolCall(item) for item in value if isinstance(item, dict)]

    def __getitem__(self, key: str) -> Any:
        """`message["content"]` 같은 dict 접근을 지원한다."""
        if key == "tool_calls":
            return self.tool_calls
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionChoice(Mapping[str, Any]):
    """OpenAI completion choice를 dict/attribute 방식으로 모두 읽게 해주는 wrapper.

    기존 사용자가 `choice["message"]`와 `choice.message`를 모두 쓸 수 있게 유지한다.
    """

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 Choice와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"finish_reason={self.finish_reason!r}, "
            f"index={self.index!r}, "
            f"message={self.message!r}"
            ")"
        )

    @property
    def index(self) -> int | None:
        """choice index를 정수이면 반환한다."""
        value = self.raw.get("index")
        return value if isinstance(value, int) else None

    @property
    def message(self) -> ChatCompletionMessage:
        """choice 안의 message를 안전한 wrapper로 반환한다."""
        value = self.raw.get("message")
        return ChatCompletionMessage(value if isinstance(value, dict) else {})

    @property
    def finish_reason(self) -> str | None:
        """OpenAI finish_reason을 문자열이면 반환한다."""
        value = self.raw.get("finish_reason")
        return value if isinstance(value, str) else None

    def __getitem__(self, key: str) -> Any:
        """`choice["message"]`는 wrapper를 반환하고 나머지는 원본 dict 값을 반환한다."""
        if key == "message":
            return self.message
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionDelta(Mapping[str, Any]):
    """stream chunk의 delta를 dict/attribute 방식으로 모두 읽게 해주는 wrapper."""

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 chunk delta와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"content={self.content!r}, "
            f"role={self.role!r}, "
            f"reasoning={self.reasoning!r}, "
            f"tool_calls={self.tool_calls!r}"
            ")"
        )

    @property
    def role(self) -> str | None:
        """delta role을 문자열이면 반환한다."""
        value = self.raw.get("role")
        return value if isinstance(value, str) else None

    @property
    def content(self) -> str:
        """delta content를 문자열로 반환하고, 없으면 빈 문자열을 반환한다."""
        value = self.raw.get("content")
        return value if isinstance(value, str) else ""

    @property
    def reasoning(self) -> str:
        """reasoning stream delta를 문자열로 반환하고, 없으면 빈 문자열을 반환한다."""
        value = self.raw.get("reasoning")
        return value if isinstance(value, str) else ""

    @property
    def tool_calls(self) -> list[ChatCompletionToolCall]:
        """stream delta의 tool_calls 배열을 wrapper 목록으로 반환한다."""
        value = self.raw.get("tool_calls")
        if not isinstance(value, list):
            return []
        return [ChatCompletionToolCall(item) for item in value if isinstance(item, dict)]

    def __getitem__(self, key: str) -> Any:
        """`delta["content"]` 같은 dict 접근을 지원한다."""
        if key == "tool_calls":
            return self.tool_calls
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionChunkChoice(Mapping[str, Any]):
    """stream chunk choice를 dict/attribute 방식으로 모두 읽게 해주는 wrapper."""

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 streaming Choice와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"finish_reason={self.finish_reason!r}, "
            f"index={self.index!r}, "
            f"delta={self.delta!r}"
            ")"
        )

    @property
    def index(self) -> int | None:
        """choice index를 정수이면 반환한다."""
        value = self.raw.get("index")
        return value if isinstance(value, int) else None

    @property
    def delta(self) -> ChatCompletionDelta:
        """choice 안의 delta를 안전한 wrapper로 반환한다."""
        value = self.raw.get("delta")
        return ChatCompletionDelta(value if isinstance(value, dict) else {})

    @property
    def finish_reason(self) -> str | None:
        """OpenAI finish_reason을 문자열이면 반환한다."""
        value = self.raw.get("finish_reason")
        return value if isinstance(value, str) else None

    def __getitem__(self, key: str) -> Any:
        """`choice["delta"]`는 wrapper를 반환하고 나머지는 원본 dict 값을 반환한다."""
        if key == "delta":
            return self.delta
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionChunk:
    """OpenAI 호환 stream chunk를 담는 내부 wrapper."""

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 ChatCompletionChunk와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"id={self.id!r}, "
            f"choices={self.choices!r}, "
            f"created={self.created!r}, "
            f"model={self.model!r}, "
            f"object={self.object!r}"
            ")"
        )

    @property
    def id(self) -> str | None:
        """chunk id 값을 문자열이면 반환한다."""
        value = self.raw.get("id")
        return value if isinstance(value, str) else None

    @property
    def object(self) -> str | None:
        """chunk object 값을 문자열이면 반환한다."""
        value = self.raw.get("object")
        return value if isinstance(value, str) else None

    @property
    def created(self) -> int | None:
        """chunk created timestamp를 정수이면 반환한다."""
        value = self.raw.get("created")
        return value if isinstance(value, int) else None

    @property
    def model(self) -> str | None:
        """chunk model 값을 문자열이면 반환한다."""
        value = self.raw.get("model")
        return value if isinstance(value, str) else None

    @property
    def choices(self) -> list[ChatCompletionChunkChoice]:
        """OpenAI chunk choices 배열을 안전한 wrapper 목록으로 반환한다."""
        value = self.raw.get("choices")
        if not isinstance(value, list):
            return []
        return [ChatCompletionChunkChoice(choice) for choice in value if isinstance(choice, dict)]


@dataclass(frozen=True)
class ChatCompletionUsage(Mapping[str, Any]):
    """OpenAI token usage를 dict/attribute 방식으로 모두 읽게 해주는 wrapper.

    provider별 usage 필드가 없거나 일부만 있어도 안전하게 None으로 노출한다.
    """

    raw: dict[str, Any] = field(repr=False)

    def __repr__(self) -> str:
        """OpenAI SDK의 CompletionUsage와 비슷한 형태로 출력한다."""
        return (
            f"{self.__class__.__name__}("
            f"completion_tokens={self.completion_tokens!r}, "
            f"prompt_tokens={self.prompt_tokens!r}, "
            f"total_tokens={self.total_tokens!r}, "
            f"completion_tokens_details={self.completion_tokens_details!r}, "
            f"prompt_tokens_details={self.prompt_tokens_details!r}"
            ")"
        )

    @property
    def prompt_tokens(self) -> int | None:
        """입력 prompt token 수를 정수이면 반환한다."""
        value = self.raw.get("prompt_tokens")
        return value if isinstance(value, int) else None

    @property
    def completion_tokens(self) -> int | None:
        """생성 completion token 수를 정수이면 반환한다."""
        value = self.raw.get("completion_tokens")
        return value if isinstance(value, int) else None

    @property
    def total_tokens(self) -> int | None:
        """전체 token 수를 정수이면 반환한다."""
        value = self.raw.get("total_tokens")
        return value if isinstance(value, int) else None

    @property
    def prompt_tokens_details(self) -> dict[str, Any] | None:
        """prompt token 상세 정보를 dict이면 반환한다."""
        value = self.raw.get("prompt_tokens_details")
        return value if isinstance(value, dict) else None

    @property
    def completion_tokens_details(self) -> dict[str, Any] | None:
        """completion token 상세 정보를 dict이면 반환한다."""
        value = self.raw.get("completion_tokens_details")
        return value if isinstance(value, dict) else None

    def __getitem__(self, key: str) -> Any:
        """`usage["total_tokens"]` 같은 dict 접근을 지원한다."""
        return self.raw[key]

    def __iter__(self) -> Iterator[str]:
        """Mapping 인터페이스를 위해 원본 dict key 순회를 제공한다."""
        return iter(self.raw)

    def __len__(self) -> int:
        """Mapping 인터페이스를 위해 원본 dict 길이를 반환한다."""
        return len(self.raw)


@dataclass(frozen=True)
class ChatCompletionRequest:
    """provider에 독립적인 내부 chat completion 요청 모델."""

    model: str
    messages: list[ChatMessage]
    temperature: float | None = None
    max_tokens: int | None = None
    timeout: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    stream: bool = False
    extra_body: dict[str, Any] = field(default_factory=dict)
    extra_headers: dict[str, str] = field(default_factory=dict)
    extra_query: dict[str, Any] = field(default_factory=dict)

    def to_openai_payload(self) -> dict[str, Any]:
        """로그와 디버깅에서 볼 수 있는 OpenAI 호환 payload 스냅샷을 만든다."""
        # 관측 로그용 payload 스냅샷이다. 실제 전송 payload는 HTTP 호출 모듈에서 조립한다.
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": [message.to_dict() for message in self.messages],
        }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.max_tokens is not None:
            payload["max_tokens"] = self.max_tokens
        if self.top_p is not None:
            payload["top_p"] = self.top_p
        if self.top_k is not None:
            payload["top_k"] = self.top_k
        if self.stream:
            payload["stream"] = self.stream
        payload.update(self.extra_body)
        return payload
