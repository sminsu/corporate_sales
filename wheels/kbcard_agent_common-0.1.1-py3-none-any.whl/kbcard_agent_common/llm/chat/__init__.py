"""Chat Completions 요청/응답 모델과 메시지 정규화 유틸리티."""

from kbcard_agent_common.llm.chat.messages import normalize_chat_messages
from kbcard_agent_common.llm.chat.models import (
    ChatCompletionChoice,
    ChatCompletionMessage,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionUsage,
    ChatMessage,
    ChatMessageInput,
    ChatMessagesInput,
)

__all__ = [
    "ChatCompletionChoice",
    "ChatCompletionMessage",
    "ChatCompletionRequest",
    "ChatCompletionResponse",
    "ChatCompletionUsage",
    "ChatMessage",
    "ChatMessageInput",
    "ChatMessagesInput",
    "normalize_chat_messages",
]
