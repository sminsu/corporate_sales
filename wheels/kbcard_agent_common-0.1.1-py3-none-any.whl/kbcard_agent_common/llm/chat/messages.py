"""Chat Completions 메시지 입력을 내부 ChatMessage 모델로 정규화한다."""

from collections.abc import Iterable, Mapping
from typing import Any

from kbcard_agent_common.errors import ConfigurationError
from kbcard_agent_common.llm.chat.models import ChatMessage


def normalize_chat_messages(messages: Iterable[Any]) -> list[ChatMessage]:
    """OpenAI JSON dict 또는 ChatMessage 목록을 ChatMessage 목록으로 통일한다."""
    normalized = []
    for message in messages:
        if isinstance(message, ChatMessage):
            normalized.append(message)
            continue
        if isinstance(message, Mapping):
            normalized.append(_normalize_dict_message(message))
            continue
        raise ConfigurationError(
            f"Unsupported message type: {type(message)}. "
            "Messages must be a dict or ChatMessage."
        )
    return normalized


def _normalize_dict_message(message: Mapping[str, Any]) -> ChatMessage:
    """OpenAI JSON dict 메시지를 ChatMessage로 변환한다."""
    raw_message = getattr(message, "raw", message)
    role = raw_message.get("role")
    if not isinstance(role, str):
        raise ConfigurationError("messages must contain a string role")
    return ChatMessage.from_dict(raw_message)
