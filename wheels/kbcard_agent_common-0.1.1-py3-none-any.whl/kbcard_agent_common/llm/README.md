# LLM 모듈 구조

이 폴더는 OpenAI Chat Completions 호환 LLM 호출을 위한 코드다. 외부 사용자는
대부분 `from kbcard_agent_common.llm import KBCardOpenAI`처럼 패키지 루트에서
가져오면 된다.

## 폴더 역할

```text
llm/
  chat/                   Chat Completions 요청/응답과 메시지 정규화
    models.py             ChatMessage, ChatCompletionResponse 등
    messages.py           JSON dict, ChatMessage 정규화

  model_config/           모델 endpoint 설정과 기능 플래그
    model_endpoints.py    ModelCapabilities, ModelConfig, ModelRegistry

  openai/                 OpenAI 호환 HTTP 호출 코드
    chat_completions.py   Chat Completions 호출, 인증, 파라미터 매핑

  __init__.py             public export
  client.py               KBCardOpenAI, KBCardAsyncOpenAI
```

## 수정 기준

- LLM 호출 흐름, sync/async client, lifecycle은 `client.py`에서 수정한다.
- OpenAI 호환 JSON 파라미터, Authorization 처리, provider 전용 body 같은 전송 세부사항은
  `openai/chat_completions.py`에서 수정한다.
- 메시지 입력 정규화는 `chat/messages.py`에서 수정한다.
- 요청/응답 객체는 `chat/models.py`, 모델 endpoint 설정과 기능 플래그는
  `model_config/model_endpoints.py`에서 수정한다.
- `client.chat.completions.create(...)`와 `client.models.get_capabilities(...)`는
  OpenAI Chat Completions 사용감과 타입 추론을 위해 명시 resource class로 구성한다.

## 공개 import

권장 import:

```python
from kbcard_agent_common.llm import KBCardOpenAI, KBCardAsyncOpenAI
from kbcard_agent_common.llm import ChatMessage, ChatMessagesInput, ChatCompletionResponse
from kbcard_agent_common.llm import ChatCompletionChoice, ChatCompletionMessage, ChatCompletionUsage
from kbcard_agent_common.llm import ModelRegistry, ModelConfig, ModelCapabilities
```

## Client 생성 방식

설정 파일을 쓰는 경우:

```python
from kbcard_agent_common.config import KBCardConfig
from kbcard_agent_common.llm import KBCardOpenAI

config = KBCardConfig.from_yaml("agent.local.yaml")
client = KBCardOpenAI.from_config(config)
```

path만 넘기고 싶다면 `from_config_path`를 사용한다:

```python
client = KBCardOpenAI.from_config_path("agent.local.yaml")
```

간단한 호출이나 smoke test에서는 모델 설정 파일 없이 endpoint를 직접 지정할 수 있다:

```python
client = KBCardOpenAI.from_endpoint(
    base_url="http://localhost:30010",
    default_model="qwen3.5:9b",
)
response = client.chat.completions.create(
    messages=[{"role": "user", "content": "hello"}],
)
```

`from_config(config)`로 만든 client는 `llm.default_model`, `temperature`,
`max_tokens`, `timeout`, `extra_body`, `extra_headers`, `api_key` 기본값을 기억한다.
`create(...)`에서 값을 생략하면 config 기본값을 쓰고, 호출 시 명시한 값은 그대로
우선 적용한다. 예를 들어 `temperature=0`은 config 값으로 덮이지 않는다.

`default_model`을 생략하면 호출할 때 `model`을 넘긴다:

```python
client = KBCardOpenAI.from_endpoint(base_url="http://localhost:30010")
response = client.chat.completions.create(
    model="qwen3.5:9b",
    messages=[{"role": "user", "content": "hello"}],
)
```

`messages` 인자는 `ChatMessagesInput`으로 타입이 잡혀 있어 `ChatMessage` 또는
`{"role": "...", "content": "..."}` dict 목록을 IDE가 추론할 수 있다. `stream=True`
호출은 내부 `Iterator[ChatCompletionChunk]`/`AsyncIterator[ChatCompletionChunk]`
타입으로 표시된다.

서브모듈에서 직접 가져와야 한다면 역할이 드러나는 경로를 사용한다:

```python
from kbcard_agent_common.llm.client import KBCardOpenAI
from kbcard_agent_common.llm.chat.models import ChatCompletionResponse
from kbcard_agent_common.llm.model_config import ModelRegistry, ModelCapabilities
```

## Provider 추가 기준

OpenAI-compatible endpoint를 기본 전제로 둔다. `provider`는 문자열로 열어두고,
로깅과 운영 식별자 역할을 한다. provider별로 다른 부분이 일부 request body뿐이면
새 adapter를 만들지 말고 `openai/chat_completions.py`의 분기만 확장한다.

OpenAI Chat Completions 형식과 맞지 않는 provider가 생길 때만 별도 client 폴더를
추가하는 것을 고려한다.

## Stream 응답 기준

`stream=True`는 OpenAI 호환 SSE를 파싱한 chunk iterator를 반환한다. chunk 소비,
중간 delta 조합, 최종 usage 수집은 호출자가 담당한다. provider가 마지막 chunk로
usage를 내려주더라도 공통 응답으로 정규화하지 않는다.

## Reasoning 모델 응답 기준

일부 reasoning 모델은 `choices[0].message.content`와 별도로
`choices[0].message.reasoning`을 내려준다. 공통 응답은 두 값을 섞지 않는다.

- `response.choices[0].message.content`: 첫 번째 choice의 최종 답변 본문
- `response.reasoning`: 첫 번째 choice의 reasoning 필드
- `response.finish_reason`: 첫 번째 choice의 종료 사유

`finish_reason="length"`이고 `response.choices[0].message.content`가 비어 있으면 reasoning을 생성하다가
최종 답변 본문 생성 전에 token 한도에 도달한 상황일 수 있다. 이 경우 `max_tokens`를
늘리거나 provider/model의 reasoning 제어 옵션을 별도로 확인한다.
