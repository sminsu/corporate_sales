"""모델 이름을 실제 OpenAI 호환 endpoint 설정으로 매핑한다."""

from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml

from kbcard_agent_common.config.secrets import (
    SecretManagerSettings,
    SecretResolver,
    resolve_secret_refs,
)
from kbcard_agent_common.errors import ConfigurationError

ProviderName = str


@dataclass(frozen=True)
class ModelCapabilities:
    """모델별 지원 기능을 client와 상위 orchestration에서 공유하기 위한 값 객체.

    현재 client가 직접 차단하는 값은 streaming뿐이다. 나머지는 모델 설정 조회와
    상위 orchestration에서 활용할 수 있는 공개 기능 플래그로 유지한다.
    """

    streaming: bool = False
    tool_call: bool = False
    structured_output: bool = False
    json_object: bool = False


@dataclass(frozen=True)
class ModelConfig:
    """하나의 논리 모델이 어떤 endpoint와 인증 정보를 쓰는지 담는 설정.

    provider 값은 로깅, 기능 지원 여부 구분, 운영 환경 식별에 사용한다.
    """

    name: str
    provider: ProviderName
    base_url: str
    api_key: str | None = None
    endpoint_path: str = "/v1/chat/completions"
    timeout: float | None = None
    capabilities: ModelCapabilities = ModelCapabilities()

    @property
    def endpoint_url(self) -> str:
        """base_url과 endpoint_path를 합쳐 실제 요청 URL을 반환한다."""
        return f"{self.base_url.rstrip('/')}/{self.endpoint_path.lstrip('/')}"

    def get_api_key(self) -> str | None:
        """직접 설정된 API key를 반환한다."""
        return self.api_key


class ModelRegistry:
    """모델명으로 endpoint 설정과 기능 플래그를 찾아주는 조회 객체.

    호출부는 model 이름만 넘기고, 실제 endpoint와 인증 정보는 이 객체에서 찾는다.
    """

    def __init__(self, models: dict[str, ModelConfig]):
        """이미 파싱된 모델 설정 dict로 조회 객체를 초기화한다."""
        self._models = models

    @classmethod
    def from_models(cls, models: Iterable[ModelConfig]) -> "ModelRegistry":
        """ModelConfig 객체 목록으로 조회 객체를 생성한다."""
        return cls({model.name: model for model in models})

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        secret_resolver: SecretResolver | None = None,
        secrets: SecretManagerSettings | None = None,
    ) -> "ModelRegistry":
        """dict 설정을 검증하고 ModelRegistry 객체로 변환한다."""
        data = resolve_secret_refs(data, secret_resolver=secret_resolver, settings=secrets)
        raw_models = data.get("models", data)
        if not isinstance(raw_models, dict):
            raise ConfigurationError("model endpoint config must contain a models mapping")

        models: dict[str, ModelConfig] = {}
        for name, raw_config in raw_models.items():
            if not isinstance(name, str) or not isinstance(raw_config, dict):
                raise ConfigurationError("each model config must be a mapping")

            capabilities = raw_config.get("capabilities", {})
            if not isinstance(capabilities, dict):
                raise ConfigurationError(f"capabilities for {name} must be a mapping")

            try:
                models[name] = ModelConfig(
                    name=name,
                    provider=raw_config["provider"],
                    base_url=raw_config["base_url"],
                    api_key=raw_config.get("api_key"),
                    endpoint_path=raw_config.get("endpoint_path", "/v1/chat/completions"),
                    timeout=raw_config.get("timeout"),
                    capabilities=ModelCapabilities(**capabilities),
                )
            except KeyError as exc:
                raise ConfigurationError(f"missing required model config key: {exc}") from exc

        return cls(models)

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        *,
        secret_resolver: SecretResolver | None = None,
        secrets: SecretManagerSettings | None = None,
    ) -> "ModelRegistry":
        """YAML 파일에서 모델 endpoint 설정을 읽어 생성한다."""
        with Path(path).open(encoding="utf-8") as file:
            data = yaml.safe_load(file) or {}
        if not isinstance(data, dict):
            raise ConfigurationError("model endpoint yaml must contain a mapping")
        settings = secrets or SecretManagerSettings.model_validate(data.get("secrets") or {})
        return cls.from_dict(data, secret_resolver=secret_resolver, secrets=settings)

    def get(self, model: str) -> ModelConfig:
        """모델명에 해당하는 ModelConfig를 반환하고, 없으면 설정 오류를 낸다."""
        try:
            return self._models[model]
        except KeyError as exc:
            raise ConfigurationError(f"unknown model: {model}") from exc

    def get_capabilities(self, model: str) -> ModelCapabilities:
        """모델명에 해당하는 기능 플래그 설정만 반환한다."""
        return self.get(model).capabilities

    def list_models(self) -> list[str]:
        """등록된 모델명을 정렬된 list로 반환한다."""
        return sorted(self._models)

    def items(self) -> Iterator[tuple[str, ModelConfig]]:
        """등록된 모델명과 설정을 순회한다."""
        return iter(self._models.items())

    def __contains__(self, model: str) -> bool:
        """`model in registry` 형태의 존재 확인을 지원한다."""
        return model in self._models
