"""OpenAI 호환 Chat Completions 클라이언트."""

from __future__ import annotations

import asyncio
import warnings
import weakref
from collections.abc import AsyncIterator, Iterator
from dataclasses import replace
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, cast, overload

import httpx

from kbcard_agent_common.errors import CapabilityNotSupportedError, ConfigurationError
from kbcard_agent_common.llm.chat.messages import normalize_chat_messages
from kbcard_agent_common.llm.chat.models import (
    ChatCompletionChunk,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatMessagesInput,
)
from kbcard_agent_common.llm.model_config.model_endpoints import (
    ModelCapabilities,
    ModelConfig,
    ModelRegistry,
)
from kbcard_agent_common.llm.openai.chat_completions import (
    async_create_openai_chat_completion,
    create_openai_chat_completion,
)

if TYPE_CHECKING:
    from kbcard_agent_common.config import KBCardConfig


class KBCardOpenAI:
    """동기 방식으로 OpenAI 호환 LLM endpoint를 호출하는 client."""

    registry: ModelRegistry
    default_model: str | None
    chat: ChatResource
    models: ModelsResource

    def __init__(
        self,
        registry: ModelRegistry | None = None,
        http_client: httpx.Client | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        default_model: str | None = None,
        provider: str = "openai_compatible",
        endpoint_path: str = "/v1/chat/completions",
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        capabilities: ModelCapabilities | None = None,
    ) -> None:
        """registry 또는 직접 endpoint 설정으로 동기 client를 초기화한다."""
        registry, default_model = _resolve_registry_and_default_model(
            registry=registry,
            base_url=base_url,
            api_key=api_key,
            default_model=default_model,
            provider=provider,
            endpoint_path=endpoint_path,
            timeout=timeout,
            capabilities=capabilities,
        )
        self.registry = registry
        self.default_model = default_model
        self.default_api_key = api_key
        self.default_temperature = temperature
        self.default_max_tokens = max_tokens
        self.default_timeout = timeout
        self.default_top_p = top_p
        self.default_top_k = top_k
        self.default_extra_body = dict(extra_body or {})
        self.default_extra_headers = dict(extra_headers or {})
        self._client = http_client or httpx.Client()
        self._owns_client = http_client is None
        self._closed = False
        self._finalizer = weakref.finalize(
            self,
            _close_client_safely,
            self._client,
            self._owns_client,
        )
        self.chat = ChatResource(self)
        self.models = ModelsResource(registry)

    @classmethod
    def from_config(
        cls,
        config: KBCardConfig,
        *,
        default_model: str | None = None,
        api_key: str | None = None,
        http_client: httpx.Client | None = None,
    ) -> KBCardOpenAI:
        """이미 로드된 agent config 객체의 llm 설정으로 동기 client를 생성한다."""
        llm_config = config.get_llm_settings()
        return cls(
            registry=ModelRegistry.from_yaml(
                llm_config.model_registry_path,
                secret_resolver=config.secret_resolver,
                secrets=config.secrets,
            ),
            http_client=http_client,
            api_key=api_key if api_key is not None else llm_config.api_key,
            default_model=default_model if default_model is not None else llm_config.default_model,
            temperature=llm_config.temperature,
            max_tokens=llm_config.max_tokens,
            timeout=llm_config.timeout,
            top_p=llm_config.top_p,
            top_k=llm_config.top_k,
            extra_body=llm_config.extra_body,
            extra_headers=llm_config.extra_headers,
        )

    @classmethod
    def from_config_path(cls, config_path: str | Path) -> KBCardOpenAI:
        """agent 설정 YAML 경로를 읽어 동기 client를 생성한다."""
        from kbcard_agent_common.config import KBCardConfig

        return cls.from_config(KBCardConfig.from_yaml(config_path))

    @classmethod
    def from_agent_config(cls, config_path: str | Path) -> KBCardOpenAI:
        """agent 설정 YAML의 llm.model_registry_path를 따라 동기 client를 생성한다."""
        return cls.from_config_path(config_path)

    @classmethod
    def from_endpoint(
        cls,
        *,
        base_url: str,
        default_model: str | None = None,
        api_key: str | None = None,
        provider: str = "openai_compatible",
        endpoint_path: str = "/v1/chat/completions",
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        capabilities: ModelCapabilities | None = None,
        http_client: httpx.Client | None = None,
    ) -> KBCardOpenAI:
        """registry YAML 없이 OpenAI 호환 endpoint를 직접 지정해 동기 client를 생성한다."""
        return cls(
            http_client=http_client,
            base_url=base_url,
            api_key=api_key,
            default_model=default_model,
            provider=provider,
            endpoint_path=endpoint_path,
            timeout=timeout,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            temperature=temperature,
            extra_body=extra_body,
            extra_headers=extra_headers,
            capabilities=capabilities,
        )

    @overload
    def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[False] = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> ChatCompletionResponse: ...

    @overload
    def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[True],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> Iterator[ChatCompletionChunk]: ...

    def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: bool = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """chat completion을 생성하고, stream=True면 chunk iterator를 반환한다."""
        resolved_api_key = api_key if api_key is not None else self.default_api_key
        model_config, request = _build_chat_completion_request(
            registry=self.registry,
            model=model,
            default_model=self.default_model,
            messages=messages,
            temperature=temperature if temperature is not None else self.default_temperature,
            max_tokens=max_tokens if max_tokens is not None else self.default_max_tokens,
            timeout=timeout if timeout is not None else self.default_timeout,
            top_p=top_p if top_p is not None else self.default_top_p,
            top_k=top_k if top_k is not None else self.default_top_k,
            api_key=resolved_api_key,
            stream=stream,
            extra_body={**self.default_extra_body, **(extra_body or {})},
            extra_headers={**self.default_extra_headers, **(extra_headers or {})},
            extra_kwargs={
                **_collect_openai_create_params(
                    stop=stop,
                    response_format=response_format,
                    tools=tools,
                    tool_choice=tool_choice,
                    parallel_tool_calls=parallel_tool_calls,
                    seed=seed,
                    logprobs=logprobs,
                    top_logprobs=top_logprobs,
                    max_completion_tokens=max_completion_tokens,
                    presence_penalty=presence_penalty,
                    frequency_penalty=frequency_penalty,
                    n=n,
                    user=user,
                    stream_options=stream_options,
                    metadata=metadata,
                    logit_bias=logit_bias,
                    modalities=modalities,
                    audio=audio,
                    moderation=moderation,
                    prediction=prediction,
                    prompt_cache_key=prompt_cache_key,
                    prompt_cache_retention=prompt_cache_retention,
                    reasoning_effort=reasoning_effort,
                    safety_identifier=safety_identifier,
                    service_tier=service_tier,
                    store=store,
                    verbosity=verbosity,
                    web_search_options=web_search_options,
                ),
                **kwargs,
            },
            extra_query=extra_query,
        )
        response = create_openai_chat_completion(
            self._client,
            request,
            model_config,
        )
        if request.stream:
            # stream=True는 SSE chunk iterator를 그대로 돌려준다. chunk 소비는 호출자가 담당한다.
            return response
        response = cast(ChatCompletionResponse, response)
        return response

    def close(self) -> None:
        """client가 소유한 HTTP 연결 자원을 닫는다."""
        if self._closed:
            return
        self._closed = True
        self._finalizer.detach()
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> KBCardOpenAI:
        """with 문에서 동기 client를 사용할 수 있게 한다."""
        return self

    def __exit__(self, *_: object) -> None:
        """with 문 종료 시 HTTP 연결 자원을 정리한다."""
        self.close()


class KBCardAsyncOpenAI:
    """비동기 방식으로 OpenAI 호환 LLM endpoint를 호출하는 client."""

    registry: ModelRegistry
    default_model: str | None
    chat: AsyncChatResource
    models: ModelsResource

    def __init__(
        self,
        registry: ModelRegistry | None = None,
        http_client: httpx.AsyncClient | None = None,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        default_model: str | None = None,
        provider: str = "openai_compatible",
        endpoint_path: str = "/v1/chat/completions",
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        capabilities: ModelCapabilities | None = None,
    ) -> None:
        """registry 또는 직접 endpoint 설정으로 비동기 client를 초기화한다."""
        registry, default_model = _resolve_registry_and_default_model(
            registry=registry,
            base_url=base_url,
            api_key=api_key,
            default_model=default_model,
            provider=provider,
            endpoint_path=endpoint_path,
            timeout=timeout,
            capabilities=capabilities,
        )
        self.registry = registry
        self.default_model = default_model
        self.default_api_key = api_key
        self.default_temperature = temperature
        self.default_max_tokens = max_tokens
        self.default_timeout = timeout
        self.default_top_p = top_p
        self.default_top_k = top_k
        self.default_extra_body = dict(extra_body or {})
        self.default_extra_headers = dict(extra_headers or {})
        self._client = http_client or httpx.AsyncClient()
        self._owns_client = http_client is None
        self._closed = False
        self._finalizer = weakref.finalize(
            self,
            _finalize_async_client,
            self._client,
            self._owns_client,
        )
        self.chat = AsyncChatResource(self)
        self.models = ModelsResource(registry)

    @classmethod
    def from_config(
        cls,
        config: KBCardConfig,
        *,
        default_model: str | None = None,
        api_key: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> KBCardAsyncOpenAI:
        """이미 로드된 agent config 객체의 llm 설정으로 비동기 client를 생성한다."""
        llm_config = config.get_llm_settings()
        return cls(
            registry=ModelRegistry.from_yaml(
                llm_config.model_registry_path,
                secret_resolver=config.secret_resolver,
                secrets=config.secrets,
            ),
            http_client=http_client,
            api_key=api_key if api_key is not None else llm_config.api_key,
            default_model=default_model if default_model is not None else llm_config.default_model,
            temperature=llm_config.temperature,
            max_tokens=llm_config.max_tokens,
            timeout=llm_config.timeout,
            top_p=llm_config.top_p,
            top_k=llm_config.top_k,
            extra_body=llm_config.extra_body,
            extra_headers=llm_config.extra_headers,
        )

    @classmethod
    def from_config_path(cls, config_path: str | Path) -> KBCardAsyncOpenAI:
        """agent 설정 YAML 경로를 읽어 비동기 client를 생성한다."""
        from kbcard_agent_common.config import KBCardConfig

        return cls.from_config(KBCardConfig.from_yaml(config_path))

    @classmethod
    def from_agent_config(cls, config_path: str | Path) -> KBCardAsyncOpenAI:
        """agent 설정 YAML의 llm.model_registry_path를 따라 비동기 client를 생성한다."""
        return cls.from_config_path(config_path)

    @classmethod
    def from_endpoint(
        cls,
        *,
        base_url: str,
        default_model: str | None = None,
        api_key: str | None = None,
        provider: str = "openai_compatible",
        endpoint_path: str = "/v1/chat/completions",
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        capabilities: ModelCapabilities | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> KBCardAsyncOpenAI:
        """registry YAML 없이 OpenAI 호환 endpoint를 직접 지정해 비동기 client를 생성한다."""
        return cls(
            http_client=http_client,
            base_url=base_url,
            api_key=api_key,
            default_model=default_model,
            provider=provider,
            endpoint_path=endpoint_path,
            timeout=timeout,
            top_p=top_p,
            top_k=top_k,
            max_tokens=max_tokens,
            temperature=temperature,
            extra_body=extra_body,
            extra_headers=extra_headers,
            capabilities=capabilities,
        )

    @overload
    async def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[False] = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> ChatCompletionResponse: ...

    @overload
    async def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[True],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatCompletionChunk]: ...

    async def create_chat_completion(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: bool = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> Any:
        """비동기 chat completion을 생성하고, stream=True면 async chunk iterator를 반환한다."""
        resolved_api_key = api_key if api_key is not None else self.default_api_key
        model_config, request = _build_chat_completion_request(
            registry=self.registry,
            model=model,
            default_model=self.default_model,
            messages=messages,
            temperature=temperature if temperature is not None else self.default_temperature,
            max_tokens=max_tokens if max_tokens is not None else self.default_max_tokens,
            timeout=timeout if timeout is not None else self.default_timeout,
            top_p=top_p if top_p is not None else self.default_top_p,
            top_k=top_k if top_k is not None else self.default_top_k,
            api_key=resolved_api_key,
            stream=stream,
            extra_body={**self.default_extra_body, **(extra_body or {})},
            extra_headers={**self.default_extra_headers, **(extra_headers or {})},
            extra_kwargs={
                **_collect_openai_create_params(
                    stop=stop,
                    response_format=response_format,
                    tools=tools,
                    tool_choice=tool_choice,
                    parallel_tool_calls=parallel_tool_calls,
                    seed=seed,
                    logprobs=logprobs,
                    top_logprobs=top_logprobs,
                    max_completion_tokens=max_completion_tokens,
                    presence_penalty=presence_penalty,
                    frequency_penalty=frequency_penalty,
                    n=n,
                    user=user,
                    stream_options=stream_options,
                    metadata=metadata,
                    logit_bias=logit_bias,
                    modalities=modalities,
                    audio=audio,
                    moderation=moderation,
                    prediction=prediction,
                    prompt_cache_key=prompt_cache_key,
                    prompt_cache_retention=prompt_cache_retention,
                    reasoning_effort=reasoning_effort,
                    safety_identifier=safety_identifier,
                    service_tier=service_tier,
                    store=store,
                    verbosity=verbosity,
                    web_search_options=web_search_options,
                ),
                **kwargs,
            },
            extra_query=extra_query,
        )
        response = await async_create_openai_chat_completion(
            self._client,
            request,
            model_config,
        )
        if request.stream:
            # async stream도 SSE async iterator를 그대로 노출해서 호출자가 소비하게 한다.
            return response
        response = cast(ChatCompletionResponse, response)
        return response

    async def aclose(self) -> None:
        """client가 소유한 비동기 HTTP 연결 자원을 닫는다."""
        if self._closed:
            return
        self._closed = True
        self._finalizer.detach()
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> KBCardAsyncOpenAI:
        """async with 문에서 비동기 client를 사용할 수 있게 한다."""
        return self

    async def __aexit__(self, *_: object) -> None:
        """async with 문 종료 시 비동기 HTTP 연결 자원을 정리한다."""
        await self.aclose()


class ChatCompletionsResource:
    """동기 Chat Completions API를 OpenAI 호환 형태로 노출한다."""

    def __init__(self, client: KBCardOpenAI) -> None:
        """client를 약한 참조로 보관해 resource가 client 수명을 늘리지 않게 한다."""
        self._client_ref = weakref.ref(client)

    @overload
    def create(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[False] = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> ChatCompletionResponse: ...

    @overload
    def create(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[True],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> Iterator[ChatCompletionChunk]: ...

    def create(self, **kwargs: Any) -> Any:
        """KBCardOpenAI.create_chat_completion(...)을 OpenAI 호환 스타일로 호출한다."""
        client = self._client_ref()
        if client is None:
            raise RuntimeError("LLM client has already been garbage collected")
        return client.create_chat_completion(**kwargs)


class ChatResource:
    """동기 chat 하위 API 묶음."""

    completions: ChatCompletionsResource

    def __init__(self, client: KBCardOpenAI) -> None:
        """chat.completions 네임스페이스를 초기화한다."""
        self.completions = ChatCompletionsResource(client)


class AsyncChatCompletionsResource:
    """비동기 Chat Completions API를 OpenAI 호환 형태로 노출한다."""

    def __init__(self, client: KBCardAsyncOpenAI) -> None:
        """client를 약한 참조로 보관해 resource가 client 수명을 늘리지 않게 한다."""
        self._client_ref = weakref.ref(client)

    @overload
    async def create(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[False] = False,
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> ChatCompletionResponse: ...

    @overload
    async def create(
        self,
        *,
        messages: ChatMessagesInput,
        model: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        timeout: float | None = None,
        top_p: float | None = None,
        top_k: int | None = None,
        stop: str | list[str] | None = None,
        response_format: dict[str, Any] | None = None,
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        seed: int | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        max_completion_tokens: int | None = None,
        presence_penalty: float | None = None,
        frequency_penalty: float | None = None,
        n: int | None = None,
        user: str | None = None,
        stream_options: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
        logit_bias: dict[str, int] | None = None,
        modalities: list[str] | None = None,
        audio: dict[str, Any] | None = None,
        moderation: dict[str, Any] | None = None,
        prediction: dict[str, Any] | None = None,
        prompt_cache_key: str | None = None,
        prompt_cache_retention: str | None = None,
        reasoning_effort: str | None = None,
        safety_identifier: str | None = None,
        service_tier: str | None = None,
        store: bool | None = None,
        verbosity: str | None = None,
        web_search_options: dict[str, Any] | None = None,
        extra_query: dict[str, Any] | None = None,
        stream: Literal[True],
        extra_body: dict[str, Any] | None = None,
        extra_headers: dict[str, str] | None = None,
        api_key: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatCompletionChunk]: ...

    async def create(self, **kwargs: Any) -> Any:
        """KBCardAsyncOpenAI.create_chat_completion(...)을 OpenAI 호환 스타일로 호출한다."""
        client = self._client_ref()
        if client is None:
            raise RuntimeError("async LLM client has already been garbage collected")
        return await client.create_chat_completion(**kwargs)


class AsyncChatResource:
    """비동기 chat 하위 API 묶음."""

    completions: AsyncChatCompletionsResource

    def __init__(self, client: KBCardAsyncOpenAI) -> None:
        """chat.completions 네임스페이스를 초기화한다."""
        self.completions = AsyncChatCompletionsResource(client)


class ModelsResource:
    """모델 capability 조회 API를 노출한다."""

    def __init__(self, registry: ModelRegistry) -> None:
        """모델 registry를 보관한다."""
        self._registry = registry

    def get_capabilities(self, model: str) -> ModelCapabilities:
        """모델명에 해당하는 capability 설정을 반환한다."""
        return self._registry.get_capabilities(model)


def _collect_openai_create_params(
    *,
    stop: str | list[str] | None,
    response_format: dict[str, Any] | None,
    tools: list[dict[str, Any]] | None,
    tool_choice: str | dict[str, Any] | None,
    parallel_tool_calls: bool | None,
    seed: int | None,
    logprobs: bool | None,
    top_logprobs: int | None,
    max_completion_tokens: int | None,
    presence_penalty: float | None,
    frequency_penalty: float | None,
    n: int | None,
    user: str | None,
    stream_options: dict[str, Any] | None,
    metadata: dict[str, Any] | None,
    logit_bias: dict[str, int] | None,
    modalities: list[str] | None,
    audio: dict[str, Any] | None,
    moderation: dict[str, Any] | None,
    prediction: dict[str, Any] | None,
    prompt_cache_key: str | None,
    prompt_cache_retention: str | None,
    reasoning_effort: str | None,
    safety_identifier: str | None,
    service_tier: str | None,
    store: bool | None,
    verbosity: str | None,
    web_search_options: dict[str, Any] | None,
) -> dict[str, Any]:
    """명시 인자로 받은 OpenAI 생성 옵션 중 값이 있는 항목만 모은다."""
    return {
        key: value
        for key, value in {
            "stop": stop,
            "response_format": response_format,
            "tools": tools,
            "tool_choice": tool_choice,
            "parallel_tool_calls": parallel_tool_calls,
            "seed": seed,
            "logprobs": logprobs,
            "top_logprobs": top_logprobs,
            "max_completion_tokens": max_completion_tokens,
            "presence_penalty": presence_penalty,
            "frequency_penalty": frequency_penalty,
            "n": n,
            "user": user,
            "stream_options": stream_options,
            "metadata": metadata,
            "logit_bias": logit_bias,
            "modalities": modalities,
            "audio": audio,
            "moderation": moderation,
            "prediction": prediction,
            "prompt_cache_key": prompt_cache_key,
            "prompt_cache_retention": prompt_cache_retention,
            "reasoning_effort": reasoning_effort,
            "safety_identifier": safety_identifier,
            "service_tier": service_tier,
            "store": store,
            "verbosity": verbosity,
            "web_search_options": web_search_options,
        }.items()
        if value is not None
    }


def _build_chat_completion_request(
    *,
    registry: ModelRegistry,
    model: str | None,
    default_model: str | None,
    messages: ChatMessagesInput,
    temperature: float | None,
    max_tokens: int | None,
    timeout: float | None,
    top_p: float | None,
    top_k: int | None,
    api_key: str | None,
    stream: bool,
    extra_body: dict[str, Any] | None,
    extra_headers: dict[str, str] | None,
    extra_kwargs: dict[str, Any],
    extra_query: dict[str, Any] | None,
) -> tuple[ModelConfig, ChatCompletionRequest]:
    """사용자 입력을 검증하고 내부 ChatCompletionRequest 객체로 변환한다."""
    resolved_model = model or default_model
    if resolved_model is None:
        raise ConfigurationError("model is required unless default_model is configured")
    model_config = registry.get(resolved_model)
    model_config = _with_request_api_key(model_config, api_key=api_key)
    if stream and not model_config.capabilities.streaming:
        raise CapabilityNotSupportedError("model does not support streaming")
    # dict와 ChatMessage를 여기서 한 번에 정규화한다.
    # OpenAI 표준/비표준 파라미터 분리는 openai.chat_completions에서 처리한다.
    return model_config, ChatCompletionRequest(
        model=resolved_model,
        messages=normalize_chat_messages(messages),
        temperature=temperature,
        max_tokens=max_tokens,
        timeout=timeout,
        top_p=top_p,
        top_k=top_k,
        stream=stream,
        extra_body={**(extra_body or {}), **extra_kwargs},
        extra_headers=extra_headers or {},
        extra_query=extra_query or {},
    )


def _with_request_api_key(
    model_config: ModelConfig,
    *,
    api_key: str | None,
) -> ModelConfig:
    """client 기본값 또는 호출 인자로 받은 API key를 모델 설정에 덮어쓴다."""
    if api_key is None:
        return model_config
    return replace(model_config, api_key=api_key)


def _resolve_registry_and_default_model(
    *,
    registry: ModelRegistry | None,
    base_url: str | None,
    api_key: str | None,
    default_model: str | None,
    provider: str,
    endpoint_path: str,
    timeout: float | None,
    capabilities: ModelCapabilities | None,
) -> tuple[ModelRegistry, str | None]:
    """registry 방식과 직접 endpoint 방식 입력을 하나의 registry로 통일한다."""
    if registry is not None:
        if base_url is not None:
            raise ConfigurationError("registry cannot be combined with base_url")
        return registry, default_model

    if base_url is None:
        raise ConfigurationError("registry or base_url must be provided")

    return (
        _DirectEndpointRegistry(
            provider=provider,
            base_url=base_url,
            api_key=api_key,
            endpoint_path=endpoint_path,
            timeout=timeout,
            capabilities=capabilities or ModelCapabilities(streaming=True),
        ),
        default_model,
    )


class _DirectEndpointRegistry(ModelRegistry):
    """직접 지정한 endpoint를 호출 시점의 model 이름과 연결하는 내부 registry."""

    def __init__(
        self,
        *,
        provider: str,
        base_url: str,
        api_key: str | None,
        endpoint_path: str,
        timeout: float | None,
        capabilities: ModelCapabilities,
    ) -> None:
        """직접 endpoint 설정을 보관한다."""
        super().__init__({})
        self._provider = provider
        self._base_url = base_url
        self._api_key = api_key
        self._endpoint_path = endpoint_path
        self._timeout = timeout
        self._capabilities = capabilities

    def get(self, model: str) -> ModelConfig:
        """호출 시점의 model 이름으로 endpoint 설정을 만든다."""
        return ModelConfig(
            name=model,
            provider=self._provider,
            base_url=self._base_url,
            api_key=self._api_key,
            endpoint_path=self._endpoint_path,
            timeout=self._timeout,
            capabilities=self._capabilities,
        )


def _close_client_safely(client: httpx.Client, owns_client: bool) -> None:
    """finalizer에서 예외를 밖으로 흘리지 않고 동기 HTTP client를 닫는다."""
    if not owns_client:
        return
    try:
        client.close()
    except Exception:
        pass


def _finalize_async_client(client: httpx.AsyncClient, owns_client: bool) -> None:
    """비동기 client가 명시적으로 닫히지 않고 GC될 때 best-effort로 정리한다."""
    if not owns_client:
        return
    warnings.warn(
        "KBCardAsyncOpenAI was garbage collected without await aclose(); "
        "HTTP resources may remain open.",
        ResourceWarning,
        stacklevel=2,
    )
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    if loop.is_closed():
        return
    # GC 시점에는 await할 수 없으므로, 살아 있는 이벤트 루프가 있을 때만 best-effort로 닫는다.
    loop.create_task(_aclose_client_safely(client))


async def _aclose_client_safely(client: httpx.AsyncClient) -> None:
    """finalizer가 만든 task 안에서 예외를 삼키고 AsyncClient를 닫는다."""
    try:
        await client.aclose()
    except Exception:
        pass
