"""Optional MCP SDK adapters."""

from __future__ import annotations

from contextlib import AsyncExitStack
from pathlib import Path
from typing import Any, TextIO

from kbcard_agent_common.errors import ConfigurationError
from kbcard_agent_common.llm.mcp.types import MCPTool, MCPToolResult


class _MCPClientBase:
    """Shared MCP SDK session operations."""

    def __init__(self, *, name: str | None = None) -> None:
        self.name = name
        self._exit_stack: AsyncExitStack | None = None
        self._session: Any | None = None

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        """Close the MCP session and transport."""

        if self._exit_stack is None:
            return
        await self._exit_stack.aclose()
        self._exit_stack = None
        self._session = None

    async def list_tools(self) -> list[MCPTool]:
        """Return all tools exposed by the MCP server, following pagination."""

        session = self._require_session()
        tools: list[MCPTool] = []
        cursor: str | None = None
        while True:
            result = await session.list_tools(cursor=cursor)
            tools.extend(MCPTool.from_raw(tool, server_name=self.name) for tool in result.tools)
            cursor = getattr(result, "nextCursor", None) or getattr(result, "next_cursor", None)
            if not cursor:
                return tools

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> MCPToolResult:
        """Call one MCP tool by name."""

        session = self._require_session()
        result = await session.call_tool(name, arguments)
        return MCPToolResult.from_raw(result)

    def _set_session(self, exit_stack: AsyncExitStack, session: Any) -> None:
        self._exit_stack = exit_stack
        self._session = session

    def _require_session(self) -> Any:
        if self._session is None:
            raise ConfigurationError(
                f"{self.__class__.__name__} must be used as an async context manager"
            )
        return self._session


class MCPStdioClient(_MCPClientBase):
    """MCP stdio client backed by the optional official `mcp` package."""

    def __init__(
        self,
        *,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        cwd: str | Path | None = None,
        name: str | None = None,
        errlog: TextIO | None = None,
    ) -> None:
        super().__init__(name=name)
        self.command = command
        self.args = args or []
        self.env = env
        self.cwd = cwd
        self.errlog = errlog

    async def __aenter__(self) -> MCPStdioClient:
        try:
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ConfigurationError(
                "MCPStdioClient requires the optional 'mcp' extra: "
                "pip install 'kbcard-agent-common[mcp]'"
            ) from exc

        exit_stack = AsyncExitStack()
        server = StdioServerParameters(
            command=self.command,
            args=self.args,
            env=self.env,
            cwd=self.cwd,
        )
        if self.errlog is None:
            read_stream, write_stream = await exit_stack.enter_async_context(stdio_client(server))
        else:
            read_stream, write_stream = await exit_stack.enter_async_context(
                stdio_client(server, errlog=self.errlog)
            )
        session = await exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()

        self._set_session(exit_stack, session)
        return self


class MCPSseClient(_MCPClientBase):
    """MCP SSE client backed by the optional official `mcp` package."""

    def __init__(
        self,
        *,
        url: str,
        headers: dict[str, Any] | None = None,
        timeout: float = 5,
        sse_read_timeout: float = 300,
        auth: Any | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(name=name)
        self.url = url
        self.headers = headers
        self.timeout = timeout
        self.sse_read_timeout = sse_read_timeout
        self.auth = auth

    async def __aenter__(self) -> MCPSseClient:
        try:
            from mcp import ClientSession
            from mcp.client.sse import sse_client
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ConfigurationError(
                "MCPSseClient requires the optional 'mcp' extra: "
                "pip install 'kbcard-agent-common[mcp]'"
            ) from exc

        exit_stack = AsyncExitStack()
        read_stream, write_stream = await exit_stack.enter_async_context(
            sse_client(
                self.url,
                headers=self.headers,
                timeout=self.timeout,
                sse_read_timeout=self.sse_read_timeout,
                auth=self.auth,
            )
        )
        session = await exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()

        self._set_session(exit_stack, session)
        return self


class MCPStreamableHttpClient(_MCPClientBase):
    """MCP Streamable HTTP client backed by the optional official `mcp` package."""

    def __init__(
        self,
        *,
        url: str,
        headers: dict[str, str] | None = None,
        timeout: float = 30,
        sse_read_timeout: float = 300,
        terminate_on_close: bool = True,
        auth: Any | None = None,
        name: str | None = None,
    ) -> None:
        super().__init__(name=name)
        self.url = url
        self.headers = headers
        self.timeout = timeout
        self.sse_read_timeout = sse_read_timeout
        self.terminate_on_close = terminate_on_close
        self.auth = auth

    async def __aenter__(self) -> MCPStreamableHttpClient:
        try:
            import httpx
            from mcp import ClientSession
            from mcp.client.streamable_http import streamable_http_client
        except ImportError as exc:  # pragma: no cover - depends on optional extra
            raise ConfigurationError(
                "MCPStreamableHttpClient requires the optional 'mcp' extra: "
                "pip install 'kbcard-agent-common[mcp]'"
            ) from exc

        exit_stack = AsyncExitStack()
        timeout = httpx.Timeout(self.timeout, read=self.sse_read_timeout)
        http_client = await exit_stack.enter_async_context(
            httpx.AsyncClient(headers=self.headers, timeout=timeout, auth=self.auth)
        )
        read_stream, write_stream, _get_session_id = await exit_stack.enter_async_context(
            streamable_http_client(
                self.url,
                http_client=http_client,
                terminate_on_close=self.terminate_on_close,
            )
        )
        session = await exit_stack.enter_async_context(ClientSession(read_stream, write_stream))
        await session.initialize()

        self._set_session(exit_stack, session)
        return self
