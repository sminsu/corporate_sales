"""MCP helpers for using MCP server tools with Chat Completions."""

from kbcard_agent_common.llm.mcp.adapters import (
    MCPSseClient,
    MCPStdioClient,
    MCPStreamableHttpClient,
)
from kbcard_agent_common.llm.mcp.openai_tools import (
    MCPToolBinding,
    build_mcp_tool_bindings,
    mcp_tool_to_openai_tool,
    mcp_tools_to_openai_tools,
)
from kbcard_agent_common.llm.mcp.runner import run_chat_with_mcp_tools
from kbcard_agent_common.llm.mcp.types import AsyncMCPClientProtocol, MCPTool, MCPToolResult

__all__ = [
    "AsyncMCPClientProtocol",
    "MCPSseClient",
    "MCPStdioClient",
    "MCPStreamableHttpClient",
    "MCPTool",
    "MCPToolBinding",
    "MCPToolResult",
    "build_mcp_tool_bindings",
    "mcp_tool_to_openai_tool",
    "mcp_tools_to_openai_tools",
    "run_chat_with_mcp_tools",
]
