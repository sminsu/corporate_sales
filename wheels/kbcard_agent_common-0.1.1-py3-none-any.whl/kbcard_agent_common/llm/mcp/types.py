"""Dependency-light MCP data contracts used by the LLM tool runner."""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any, Protocol, cast, runtime_checkable


@dataclass(frozen=True)
class MCPTool:
    """MCP tool metadata normalized from SDK objects or JSON dicts."""

    name: str
    description: str | None = None
    input_schema: dict[str, Any] = field(default_factory=lambda: {"type": "object"})
    title: str | None = None
    annotations: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None
    server_name: str | None = None
    raw: Any = field(default=None, repr=False)

    @classmethod
    def from_raw(cls, raw: Any, *, server_name: str | None = None) -> MCPTool:
        """Create a normalized tool from an MCP SDK object or mapping."""

        name = _get_value(raw, "name")
        if not isinstance(name, str) or not name:
            raise ValueError("MCP tool must have a non-empty string name")

        description = _optional_str(_get_value(raw, "description"))
        title = _optional_str(_get_value(raw, "title"))
        input_schema = _mapping_to_dict(
            _get_value(raw, "inputSchema", "input_schema"),
            default={"type": "object"},
        )
        annotations = _optional_mapping(_get_value(raw, "annotations"))
        output_schema = _optional_mapping(_get_value(raw, "outputSchema", "output_schema"))

        return cls(
            name=name,
            description=description,
            input_schema=input_schema,
            title=title,
            annotations=annotations,
            output_schema=output_schema,
            server_name=server_name,
            raw=raw,
        )


@dataclass(frozen=True)
class MCPToolResult:
    """MCP tool result normalized for feeding back into Chat Completions."""

    content: list[Any] = field(default_factory=list)
    structured_content: Any | None = None
    is_error: bool = False
    raw: Any = field(default=None, repr=False)

    @classmethod
    def from_raw(cls, raw: Any) -> MCPToolResult:
        """Create a normalized result from an MCP SDK object or mapping."""

        content = _get_value(raw, "content")
        if content is None:
            normalized_content: list[Any] = []
        elif isinstance(content, list):
            normalized_content = content
        elif isinstance(content, Sequence) and not isinstance(content, (str, bytes, bytearray)):
            normalized_content = list(content)
        else:
            normalized_content = [content]

        is_error = bool(_get_value(raw, "isError", "is_error") or False)
        structured_content = _get_value(raw, "structuredContent", "structured_content")
        return cls(
            content=normalized_content,
            structured_content=structured_content,
            is_error=is_error,
            raw=raw,
        )

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable envelope for the tool result."""

        payload: dict[str, Any] = {
            "content": [_jsonable(item) for item in self.content],
            "isError": self.is_error,
        }
        if self.structured_content is not None:
            payload["structuredContent"] = _jsonable(self.structured_content)
        return payload

    def to_chat_content(self) -> str:
        """Return a string suitable for a Chat Completions role=tool message."""

        if self.is_error or self.structured_content is not None:
            return json.dumps(self.to_dict(), ensure_ascii=False)

        text_parts: list[str] = []
        other_parts: list[Any] = []
        for item in self.content:
            text = _text_content(item)
            if text is None:
                other_parts.append(_jsonable(item))
            else:
                text_parts.append(text)

        if other_parts:
            payload: dict[str, Any] = {}
            if text_parts:
                payload["text"] = "\n".join(text_parts)
            payload["content"] = other_parts
            return json.dumps(payload, ensure_ascii=False)

        return "\n".join(text_parts)


@runtime_checkable
class AsyncMCPClientProtocol(Protocol):
    """Minimal protocol required by the Chat Completions MCP runner."""

    @property
    def name(self) -> str | None: ...

    async def list_tools(self) -> list[MCPTool]: ...

    async def call_tool(self, name: str, arguments: dict[str, Any]) -> MCPToolResult: ...


def _get_value(raw: Any, *names: str) -> Any:
    for name in names:
        if isinstance(raw, Mapping) and name in raw:
            return raw[name]
        if hasattr(raw, name):
            return getattr(raw, name)
    return None


def _optional_str(value: Any) -> str | None:
    return value if isinstance(value, str) else None


def _mapping_to_dict(value: Any, *, default: dict[str, Any]) -> dict[str, Any]:
    if value is None:
        return dict(default)
    if isinstance(value, Mapping):
        return dict(value)
    if hasattr(value, "model_dump"):
        dumped = value.model_dump(mode="json")
        return dumped if isinstance(dumped, dict) else dict(default)
    return dict(default)


def _optional_mapping(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    return _mapping_to_dict(value, default={})


def _text_content(value: Any) -> str | None:
    content_type = _get_value(value, "type")
    if content_type == "text":
        text = _get_value(value, "text")
        return text if isinstance(text, str) else ""
    if isinstance(value, str):
        return value
    return None


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        return [_jsonable(item) for item in value]
    model_dump = getattr(cast(Any, value), "model_dump", None)
    if callable(model_dump):
        return _jsonable(model_dump(mode="json"))
    dict_dump = getattr(cast(Any, value), "dict", None)
    if callable(dict_dump):
        return _jsonable(dict_dump())
    return repr(value)
