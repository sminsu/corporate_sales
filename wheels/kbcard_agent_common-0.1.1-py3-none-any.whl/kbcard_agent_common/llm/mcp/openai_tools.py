"""Convert MCP tools into OpenAI Chat Completions function tools."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from typing import Any

from kbcard_agent_common.llm.mcp.types import AsyncMCPClientProtocol, MCPTool

_OPENAI_TOOL_NAME_RE = re.compile(r"[^a-zA-Z0-9_-]+")


@dataclass(frozen=True)
class MCPToolBinding:
    """Mapping between an OpenAI function name and an MCP tool."""

    openai_name: str
    tool: MCPTool
    client: AsyncMCPClientProtocol | None = None


def mcp_tool_to_openai_tool(tool: MCPTool, *, name: str | None = None) -> dict[str, Any]:
    """Convert one normalized MCP tool to a Chat Completions function tool."""

    function: dict[str, Any] = {
        "name": name or sanitize_openai_tool_name(tool.name),
        "parameters": tool.input_schema or {"type": "object"},
    }
    description_parts = [part for part in [tool.title, tool.description] if part]
    if description_parts:
        function["description"] = "\n".join(description_parts)
    return {"type": "function", "function": function}


def mcp_tools_to_openai_tools(tools: list[MCPTool]) -> list[dict[str, Any]]:
    """Convert normalized MCP tools to Chat Completions function tool definitions."""

    bindings = _build_tool_name_bindings(tools, namespace_duplicates=True)
    return [mcp_tool_to_openai_tool(binding.tool, name=binding.openai_name) for binding in bindings]


async def build_mcp_tool_bindings(
    clients: list[AsyncMCPClientProtocol],
    *,
    namespace_duplicates: bool = True,
) -> list[MCPToolBinding]:
    """Discover tools from MCP clients and build OpenAI-name bindings."""

    client_tools: list[tuple[AsyncMCPClientProtocol, MCPTool]] = []
    for client in clients:
        for tool in await client.list_tools():
            client_tools.append((client, tool))

    bindings = _build_tool_name_bindings(
        [tool for _, tool in client_tools],
        namespace_duplicates=namespace_duplicates,
    )

    result: list[MCPToolBinding] = []
    for binding, (client, _tool) in zip(bindings, client_tools, strict=True):
        result.append(MCPToolBinding(binding.openai_name, binding.tool, client))
    return result


def sanitize_openai_tool_name(name: str) -> str:
    """Return a function name accepted by OpenAI-compatible providers."""

    sanitized = _OPENAI_TOOL_NAME_RE.sub("_", name).strip("_")
    return (sanitized or "tool")[:64]


def _build_tool_name_bindings(
    tools: list[MCPTool],
    *,
    namespace_duplicates: bool,
) -> list[MCPToolBinding]:
    base_names = [sanitize_openai_tool_name(tool.name) for tool in tools]
    counts = Counter(base_names)
    used: set[str] = set()
    bindings: list[MCPToolBinding] = []

    for tool, base_name in zip(tools, base_names, strict=True):
        name = base_name
        if namespace_duplicates and counts[base_name] > 1 and tool.server_name:
            name = sanitize_openai_tool_name(f"{tool.server_name}__{tool.name}")
        name = _dedupe_tool_name(name, used)
        used.add(name)
        bindings.append(MCPToolBinding(openai_name=name, tool=tool))

    return bindings


def _dedupe_tool_name(name: str, used: set[str]) -> str:
    if name not in used:
        return name
    base = name[:58]
    index = 2
    while True:
        candidate = f"{base}_{index}"
        if candidate not in used:
            return candidate
        index += 1
