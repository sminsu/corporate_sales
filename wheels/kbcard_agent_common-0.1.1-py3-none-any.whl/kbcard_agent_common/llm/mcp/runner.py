"""Run Chat Completions conversations against MCP-provided tools."""

from __future__ import annotations

import inspect
from collections.abc import Iterable
from typing import Any

from kbcard_agent_common.errors import ConfigurationError
from kbcard_agent_common.llm.chat.models import (
    ChatCompletionResponse,
    ChatMessage,
    ChatMessageInput,
)
from kbcard_agent_common.llm.mcp.openai_tools import (
    MCPToolBinding,
    build_mcp_tool_bindings,
    mcp_tool_to_openai_tool,
)
from kbcard_agent_common.llm.mcp.types import AsyncMCPClientProtocol, MCPToolResult


async def run_chat_with_mcp_tools(
    *,
    llm: Any,
    messages: Iterable[ChatMessageInput],
    mcp_client: AsyncMCPClientProtocol | None = None,
    mcp_clients: list[AsyncMCPClientProtocol] | None = None,
    model: str | None = None,
    max_tool_rounds: int = 3,
    tool_choice: str | dict[str, Any] | None = "auto",
    parallel_tool_calls: bool | None = False,
    namespace_duplicate_tools: bool = True,
    **chat_kwargs: Any,
) -> ChatCompletionResponse:
    """Run a Chat Completions loop where tool calls are executed through MCP.

    The function accepts both sync and async OpenAI-compatible clients. Sync calls
    are executed directly, so prefer `KBCardAsyncOpenAI` inside high-throughput
    async services.
    """

    clients = _collect_clients(mcp_client=mcp_client, mcp_clients=mcp_clients)
    if max_tool_rounds < 0:
        raise ConfigurationError("max_tool_rounds must be greater than or equal to 0")

    bindings = await build_mcp_tool_bindings(
        clients,
        namespace_duplicates=namespace_duplicate_tools,
    )
    binding_by_name = {binding.openai_name: binding for binding in bindings}
    tools = [
        mcp_tool_to_openai_tool(binding.tool, name=binding.openai_name) for binding in bindings
    ]

    history = [_message_to_dict(message) for message in messages]
    response: ChatCompletionResponse | None = None

    for round_index in range(max_tool_rounds + 1):
        response = await _create_chat_completion(
            llm=llm,
            messages=history,
            model=model,
            tools=tools,
            tool_choice=tool_choice,
            parallel_tool_calls=parallel_tool_calls,
            chat_kwargs=chat_kwargs,
        )
        assistant_message = response.choices[0].message
        tool_calls = assistant_message.tool_calls
        if not tool_calls:
            return response
        if round_index >= max_tool_rounds:
            return response

        history.append(dict(assistant_message.raw))
        for tool_call in tool_calls:
            openai_tool_name = tool_call.name
            if not openai_tool_name:
                raise ConfigurationError("tool call is missing function.name")
            if not tool_call.id:
                raise ConfigurationError("tool call is missing id")

            binding = binding_by_name.get(openai_tool_name)
            if binding is None:
                raise ConfigurationError(f"Unknown MCP tool requested by model: {openai_tool_name}")

            arguments = tool_call.parse_arguments(default={})
            result = await _call_bound_tool(binding, arguments)
            history.append(_tool_result_message(tool_call.id, result))

    if response is None:  # pragma: no cover - defensive guard
        raise ConfigurationError("chat completion did not run")
    return response


def _collect_clients(
    *,
    mcp_client: AsyncMCPClientProtocol | None,
    mcp_clients: list[AsyncMCPClientProtocol] | None,
) -> list[AsyncMCPClientProtocol]:
    clients = []
    if mcp_client is not None:
        clients.append(mcp_client)
    clients.extend(mcp_clients or [])
    if not clients:
        raise ConfigurationError("at least one MCP client is required")
    return clients


async def _create_chat_completion(
    *,
    llm: Any,
    messages: list[dict[str, Any]],
    model: str | None,
    tools: list[dict[str, Any]],
    tool_choice: str | dict[str, Any] | None,
    parallel_tool_calls: bool | None,
    chat_kwargs: dict[str, Any],
) -> ChatCompletionResponse:
    create = llm.chat.completions.create
    kwargs: dict[str, Any] = {
        "messages": messages,
        "tools": tools,
        "tool_choice": tool_choice,
        "parallel_tool_calls": parallel_tool_calls,
        **chat_kwargs,
    }
    if model is not None:
        kwargs["model"] = model
    response = create(**kwargs)
    if inspect.isawaitable(response):
        response = await response
    return response


async def _call_bound_tool(binding: MCPToolBinding, arguments: dict[str, Any]) -> MCPToolResult:
    if binding.client is None:
        raise ConfigurationError("MCP tool binding is missing a client")
    return await binding.client.call_tool(binding.tool.name, arguments)


def _message_to_dict(message: ChatMessageInput) -> dict[str, Any]:
    if isinstance(message, ChatMessage):
        return message.to_dict()
    raw_message = getattr(message, "raw", message)
    return dict(raw_message)


def _tool_result_message(tool_call_id: str, result: MCPToolResult) -> dict[str, Any]:
    return {
        "role": "tool",
        "tool_call_id": tool_call_id,
        "content": result.to_chat_content(),
    }
