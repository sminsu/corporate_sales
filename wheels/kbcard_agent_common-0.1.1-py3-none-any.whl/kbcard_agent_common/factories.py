"""Runtime object factories for common SDK components."""

from __future__ import annotations

import os
from collections.abc import Iterable
from dataclasses import fields
from typing import Any, cast

from kbcard_agent_common.config import (
    ChunkerSettings,
    IngestionSettings,
    KBCardConfig,
    RetrievalSettings,
)
from kbcard_agent_common.embedding import EmbeddingClient, RerankerClient
from kbcard_agent_common.errors import ConfigurationError
from kbcard_agent_common.ingestion import (
    DEFAULT_SEPARATORS,
    LEGAL_SEPARATORS,
    AutoChunker,
    FixedSizeChunker,
    MarkdownFileParser,
    NoChunker,
    RecursiveTokenChunker,
    TextFileParser,
    XmlFileParser,
    default_parser_registry,
)
from kbcard_agent_common.ingestion.pipeline import Chunker, DocumentParser
from kbcard_agent_common.retrieval import (
    CustomChunkQueryConfig,
    CustomQueryConfig,
    LanceDBRetrievalStore,
    PostgresRetrievalStore,
    PostgresRetrievalStoreConfig,
    QueryTableConfig,
    RetrievalStore,
    Retriever,
)

__all__ = [
    "create_ingestion_chunker",
    "create_ingestion_parser",
    "create_retrieval_store",
    "create_retriever",
]


def create_ingestion_parser(config: KBCardConfig | IngestionSettings) -> DocumentParser:
    """Create a document parser from ``KBCardConfig.ingestion`` settings."""

    ingestion = _coerce_ingestion_settings(config)
    if ingestion.parser == "markdown":
        return MarkdownFileParser()
    if ingestion.parser == "text":
        return TextFileParser()
    if ingestion.parser == "xml":
        return XmlFileParser()
    if ingestion.parser == "auto":
        return default_parser_registry()
    raise ConfigurationError(f"unsupported parser: {ingestion.parser}")


def create_ingestion_chunker(config: KBCardConfig | IngestionSettings) -> Chunker:
    """Create a chunker from ``KBCardConfig.ingestion.chunker`` settings.

    The config default remains fixed-length character chunking. Set
    ``ingestion.chunker.strategy`` to ``auto`` or ``recursive_token`` to use
    token-aware chunking.
    """

    settings = _coerce_ingestion_settings(config).chunker
    if settings.strategy == "fixed_size":
        return FixedSizeChunker(
            chunk_size=settings.chunk_size,
            chunk_overlap=settings.chunk_overlap,
        )
    if settings.strategy == "no_chunk":
        return NoChunker()
    if settings.strategy == "auto":
        return AutoChunker(
            max_tokens=settings.max_tokens,
            min_tokens=settings.min_tokens,
            no_chunk_max_tokens=settings.no_chunk_max_tokens,
            preserve_tables=settings.preserve_tables,
        )
    if settings.strategy == "recursive_token":
        return RecursiveTokenChunker(
            max_tokens=settings.max_tokens,
            min_tokens=settings.min_tokens,
            separators=_chunker_separators(settings),
            preserve_tables=settings.preserve_tables,
        )
    raise ConfigurationError(f"unsupported chunker strategy: {settings.strategy}")


def create_retrieval_store(
    retrieval: KBCardConfig | RetrievalSettings,
    *,
    dsn: str | None = None,
    connection: Any | None = None,
    pool: Any | None = None,
) -> RetrievalStore:
    """공통 검색 설정을 기반으로 적절한 RetrievalStore 인스턴스를 생성합니다."""

    retrieval = _coerce_retrieval_settings(retrieval)
    store_settings = retrieval.store
    # Postgres 프로바이더인 경우, DSN 및 커넥션 정보를 바탕으로 PostgresRetrievalStore 생성
    if store_settings.provider == "postgres":
        resolved_dsn = dsn or store_settings.dsn or _env_or_none(store_settings.dsn_env)
        if not resolved_dsn and connection is None and pool is None:
            raise ConfigurationError(f"{store_settings.dsn_env} is required")
        return PostgresRetrievalStore(
            dsn=resolved_dsn,
            connection=connection,
            pool=pool,
            config=_postgres_config_from_retrieval(retrieval),
        )

    # LanceDB 프로바이더인 경우, 임베디드 로컬 저장소 형태로 생성
    if store_settings.provider == "lancedb":
        return LanceDBRetrievalStore(
            store_settings.uri,
            table_name=store_settings.table_name,
            vector_column=store_settings.vector_column,
        )

    raise ConfigurationError(f"unsupported retrieval store: {store_settings.provider}")


def create_retriever(
    config: KBCardConfig,
    *,
    dsn: str | None = None,
    connection: Any | None = None,
    pool: Any | None = None,
) -> Retriever:
    """탑레벨 에이전트 설정을 바탕으로 기본 검색 파이프라인(Retriever)을 조립합니다."""

    # 임베더 및 리랭커 클라이언트 생성 (설정이 존재하는 경우에만 활성화)
    embedder = EmbeddingClient(config.require_embedding()) if config.embedding is not None else None
    reranker = RerankerClient(config.reranker) if config.reranker is not None else None
    store = create_retrieval_store(config.retrieval, dsn=dsn, connection=connection, pool=pool)

    # 팩토리에서 직접 생성하여 반환하므로 owns_dependencies=True로 자원 수명주기를 관리한다.
    return Retriever(
        embedder=embedder,
        store=store,
        reranker=reranker,
        retrieval_config=config.retrieval,
        owns_dependencies=True,
    )


def _postgres_config_from_retrieval(
    retrieval: RetrievalSettings,
) -> PostgresRetrievalStoreConfig:
    store_settings = retrieval.store
    if store_settings.provider != "postgres":
        raise ConfigurationError(f"unsupported retrieval store: {store_settings.provider}")

    config_field_names = {
        config_field.name for config_field in fields(PostgresRetrievalStoreConfig)
    }
    store_values = {
        key: value
        for key, value in store_settings.model_dump().items()
        if key in config_field_names
    }
    advanced_values = {
        key: value
        for key, value in retrieval.advanced.model_dump().items()
        if key in config_field_names
    }
    raw_allowed_filter_keys = cast(
        Iterable[str],
        store_values.pop("allowed_filter_keys", ()) or (),
    )
    raw_custom_chunk_queries = store_values.pop("custom_chunk_queries", {}) or {}
    raw_custom_queries = store_values.pop("custom_queries", {}) or {}
    raw_query_tables = store_values.pop("query_tables", {}) or {}
    custom_chunk_queries = {
        name: CustomChunkQueryConfig(
            sql=value["sql"],
            allowed_params=set(value.get("allowed_params", ()) or ()),
            default_limit=value.get("default_limit", 5),
            max_limit=value.get("max_limit", 50),
        )
        for name, value in raw_custom_chunk_queries.items()
    }
    custom_queries = {
        name: CustomQueryConfig(
            sql=value["sql"],
            allowed_params=set(value.get("allowed_params", ()) or ()),
            default_limit=value.get("default_limit", 50),
            max_limit=value.get("max_limit", 200),
        )
        for name, value in raw_custom_queries.items()
    }
    query_tables = {
        name: QueryTableConfig(
            table_name=value["table_name"],
            schema_name=value.get("schema_name"),
        )
        for name, value in raw_query_tables.items()
    }

    return PostgresRetrievalStoreConfig(
        **store_values,
        **advanced_values,
        allowed_filter_keys=set(raw_allowed_filter_keys),
        custom_chunk_queries=custom_chunk_queries,
        custom_queries=custom_queries,
        query_tables=query_tables,
        score_threshold=retrieval.score_threshold,
    )


def _env_or_none(name: str) -> str | None:
    value = os.getenv(name)
    return value or None


def _coerce_retrieval_settings(
    config_or_retrieval: KBCardConfig | RetrievalSettings,
) -> RetrievalSettings:
    if isinstance(config_or_retrieval, KBCardConfig):
        return config_or_retrieval.retrieval
    return config_or_retrieval


def _coerce_ingestion_settings(
    config_or_ingestion: KBCardConfig | IngestionSettings,
) -> IngestionSettings:
    if isinstance(config_or_ingestion, KBCardConfig):
        return config_or_ingestion.ingestion
    return config_or_ingestion


def _chunker_separators(settings: ChunkerSettings) -> tuple[str, ...] | list[str]:
    if settings.separators is not None:
        return settings.separators
    if settings.separator_profile == "legal":
        return (*LEGAL_SEPARATORS, *DEFAULT_SEPARATORS)
    return DEFAULT_SEPARATORS
