"""Retrieval store protocol."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, Protocol

from kbcard_agent_common.types import ChunkWindowTarget, Document, MetadataFilters

if TYPE_CHECKING:
    from kbcard_agent_common.ingestion.types import EmbeddedChunk

SearchType = Literal["vector", "keyword", "hybrid", "weighted_vector"]


class RetrievalStore(Protocol):
    """LanceDB와 Postgres 어댑터들이 구현해야 하는 공통 검색 실행 엔진 규격."""

    def ensure_collection(self) -> None:
        """저장소의 백킹 테이블 및 필요한 인덱스를 생성합니다."""
        ...

    def upsert(self, chunks: list[EmbeddedChunk]) -> None:
        """임베딩된 청크 목록을 삽입하거나 기존 ID에 대해 업데이트(Upsert)합니다."""
        ...

    def delete_by_source(self, source: str) -> int:
        """출처(Source URI 등)에 부합하는 모든 청크들을 삭제합니다."""
        ...

    def similarity_search(
        self,
        query_embedding: list[float],
        *,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """단순 쿼리 임베딩 기반으로 가장 유사도가 높은 문서군을 탐색합니다."""
        ...

    def search(
        self,
        *,
        query_embedding: list[float] | None = None,
        query_text: str | None = None,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
        search_type: SearchType = "vector",
        fetch_k: int | None = None,
        score_threshold: float | None = None,
        length_weight: float | None = None,
        diversity_penalty_weight: float | None = None,
        diversity_metadata_key: str | None = None,
    ) -> list[Document]:
        """Provider별 최적화 검색 로직을 적용해 문서를 반환합니다."""
        ...

    def get_chunks_by_ids(
        self,
        chunk_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """청크 ID 목록을 기반으로 청크를 batch direct lookup합니다."""
        ...

    def get_chunks_by_document_ids(
        self,
        document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """문서 ID 목록에 속한 모든 청크를 batch direct lookup합니다."""
        ...

    def get_chunks_by_parent_document_ids(
        self,
        parent_document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """부모 문서 ID 목록을 참조하는 자식 청크를 batch direct lookup합니다."""
        ...

    def get_chunk_windows(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """문서 ID와 chunk index 목록을 기준으로 인접 청크 window를 batch direct lookup합니다."""
        ...

    def run_chunk_query(
        self,
        name: str,
        *,
        params: dict[str, object] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        """설정에 등록된 named chunk query를 실행합니다."""
        ...

    def run_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """설정에 등록된 named row query를 실행합니다."""
        ...
