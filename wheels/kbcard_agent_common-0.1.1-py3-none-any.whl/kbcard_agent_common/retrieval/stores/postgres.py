"""PostgreSQL/pgvector retrieval store adapter."""

from __future__ import annotations

import json
import re
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from importlib import import_module
from typing import Any

from kbcard_agent_common.errors import ConfigurationError, RetrievalError
from kbcard_agent_common.ingestion.types import EmbeddedChunk
from kbcard_agent_common.retrieval.stores.base import SearchType
from kbcard_agent_common.types import (
    ChunkWindowTarget,
    Document,
    MetadataFilters,
    MetadataFilterValue,
)

_TABLE_MACRO_RE = re.compile(r"\{table:(?P<name>[A-Za-z_][A-Za-z0-9_]*)\}")
_FILTER_MACRO_RE = re.compile(
    r"\{filters_(?P<connector>where|and)(?::(?P<alias>[A-Za-z_][A-Za-z0-9_]*))?\}"
)


@dataclass(frozen=True)
class CustomChunkQueryConfig:
    """Controlled named SQL template for Postgres chunk queries."""

    sql: str
    allowed_params: set[str] = field(default_factory=set)
    default_limit: int = 5
    max_limit: int = 50


@dataclass(frozen=True)
class CustomQueryConfig:
    """Controlled named SQL template for Postgres row queries."""

    sql: str
    allowed_params: set[str] = field(default_factory=set)
    default_limit: int = 50
    max_limit: int = 200


@dataclass(frozen=True)
class QueryTableConfig:
    """Registered table reference usable from named query templates."""

    table_name: str
    schema_name: str | None = None


@dataclass(frozen=True)
class PostgresRetrievalStoreConfig:
    """Configuration for Postgres/pgvector table contracts."""

    collection_name: str | None = None
    schema_name: str | None = None
    table_name: str = "kbcard_rag_chunks"
    embedding_dimensions: int = 1024
    id_column: str = "id"
    chunk_id_column: str | None = None
    document_id_column: str | None = "document_id"
    document_id_metadata_key: str = "doc_id"
    parent_document_id_metadata_key: str = "parent_doc_id"
    chunk_index_column: str | None = "chunk_index"
    chunk_index_metadata_key: str = "chunk_index"
    content_column: str = "content"
    embedding_column: str = "embedding"
    metadata_column: str = "metadata"
    source_column: str | None = "source"
    source_metadata_key: str = "source_uri"
    collection_column: str | None = "collection_name"
    keyword_tsvector_column: str | None = "search_text"
    allowed_filter_keys: set[str] = field(default_factory=set)
    custom_chunk_queries: dict[str, CustomChunkQueryConfig] = field(default_factory=dict)
    custom_queries: dict[str, CustomQueryConfig] = field(default_factory=dict)
    query_tables: dict[str, QueryTableConfig] = field(default_factory=dict)
    vector_weight: float = 0.7
    keyword_weight: float = 0.3
    score_threshold: float = 0.0
    length_weight: float = 0.0
    diversity_penalty_weight: float = 0.0
    diversity_metadata_key: str = "source"
    language: str = "simple"
    pool_min_size: int = 1
    pool_max_size: int = 10
    pool_timeout: float = 5.0
    pool_max_lifetime: float = 1800.0
    pool_max_idle: float = 300.0
    pool_reconnect_timeout: float = 30.0
    autocommit: bool = True
    keepalives: bool = True
    keepalives_idle: int = 30
    keepalives_interval: int = 10
    keepalives_count: int = 3
    health_check_interval: float | None = 30.0
    retry_on_connection_error: bool = True


class PostgresRetrievalStore:
    """PostgreSQL/pgvector search execution engine.

    SQL 쿼리는 모두 parameter binding을 사용하며, metadata filter key는 allow-list로
    검증한다. DSN으로 생성하면 long-lived service에 맞게 내부 connection pool을 쓴다.
    """

    def __init__(
        self,
        dsn: str | None = None,
        *,
        config: PostgresRetrievalStoreConfig,
        connection: Any | None = None,
        pool: Any | None = None,
    ) -> None:
        """DSN, connection pool, or connection object and table mapping settings."""
        self.dsn = dsn
        self.config = config
        self._connection = connection
        self._pool = pool
        self._owns_connection = connection is None and pool is None
        self._owns_pool = pool is None and connection is None
        self._pool_lock = threading.Lock()
        self._health_check_stop = threading.Event()
        self._health_check_thread: threading.Thread | None = None

    def ensure_collection(self) -> None:
        def execute() -> None:
            with self._cursor() as cursor:
                cursor.execute(self._create_table_sql())
                table = self.config.table_name
                collection_column = _quote_identifier(
                    self.config.collection_column or "collection_name"
                )
                metadata_column = _quote_identifier(self.config.metadata_column)
                cursor.execute(
                    f"CREATE INDEX IF NOT EXISTS "
                    f"{_quote_identifier('idx_' + table + '_collection')} "
                    f"ON {self._table_ref()} ({collection_column})"
                )
                cursor.execute(
                    f"CREATE INDEX IF NOT EXISTS {_quote_identifier('idx_' + table + '_metadata')} "
                    f"ON {self._table_ref()} USING GIN ({metadata_column})"
                )
                if self.config.keyword_tsvector_column:
                    index_name = _quote_identifier("idx_" + table + "_search_text")
                    search_text_column = _quote_identifier(self.config.keyword_tsvector_column)
                    cursor.execute(
                        f"CREATE INDEX IF NOT EXISTS {index_name} "
                        f"ON {self._table_ref()} USING GIN ({search_text_column})"
                    )
            self._commit()

        self._execute_with_optional_retry(execute)

    def upsert(self, chunks: list[EmbeddedChunk]) -> None:
        if not chunks:
            return
        sql = self._upsert_sql()
        rows = [
            (
                chunk.id,
                self.config.collection_name or "",
                chunk.document_id,
                chunk.chunk_index,
                chunk.content,
                json.dumps(chunk.metadata, ensure_ascii=False),
                _vector_literal(chunk.embedding),
                chunk.content,
                chunk.source,
            )
            for chunk in chunks
        ]
        try:
            def execute() -> None:
                with self._cursor() as cursor:
                    cursor.executemany(sql, rows)
                self._commit()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise

    def delete_by_source(self, source: str) -> int:
        if self.config.source_column:
            source_filter = f"{_quote_identifier(self.config.source_column)} = %s"
            params = (source,)
        else:
            source_filter = f"{_quote_identifier(self.config.metadata_column)} ->> %s = %s"
            params = (self.config.source_metadata_key, source)
        sql = f"DELETE FROM {self._table_ref()} WHERE {source_filter}"
        try:
            rowcount = 0

            def execute() -> None:
                nonlocal rowcount
                with self._cursor() as cursor:
                    cursor.execute(sql, params)
                    rowcount = int(getattr(cursor, "rowcount", 0))
                self._commit()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise
        return rowcount

    def similarity_search(
        self,
        query_embedding: list[float],
        *,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        return self.search(query_embedding=query_embedding, top_k=top_k, filters=filters)

    def search(
        self,
        *,
        query_embedding: list[float] | None = None,
        query_text: str | None = None,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
        search_type: SearchType = "vector",
        fetch_k: int | None = None,
        score_threshold: float | None = None,
        length_weight: float | None = None,
        diversity_penalty_weight: float | None = None,
        diversity_metadata_key: str | None = None,
    ) -> list[Document]:
        """Build and execute SQL for the requested search strategy."""
        if search_type in {"vector", "hybrid", "weighted_vector"} and query_embedding is None:
            raise RetrievalError("query_embedding is required for vector or hybrid search")
        if search_type in {"keyword", "hybrid"} and not query_text:
            raise RetrievalError("query_text is required for keyword or hybrid search")

        # 각 검색 유형별 전용 SQL 및 바인딩 파라미터 빌드
        sql, params = self.build_search_query(
            query_embedding=query_embedding,
            query_text=query_text,
            top_k=top_k,
            filters=filters,
            search_type=search_type,
            fetch_k=fetch_k,
            score_threshold=score_threshold,
            length_weight=length_weight,
            diversity_penalty_weight=diversity_penalty_weight,
            diversity_metadata_key=diversity_metadata_key,
        )
        try:
            rows = []

            def execute() -> None:
                nonlocal rows
                with self._cursor() as cursor:
                    cursor.execute(sql, params)
                    rows = cursor.fetchall()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise
        documents = [_row_to_document(row, rank=index + 1) for index, row in enumerate(rows)]
        return documents

    def get_chunks_by_ids(
        self,
        chunk_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Batch direct lookup by chunk ID.

        The chunk ID uses the same logical ID expression as search results. If
        `chunk_id_column` is configured, that column is used before falling back
        to `id_column`.
        """
        values = _unique_non_empty_strings(chunk_ids)
        if not values:
            return []
        predicate_sql, predicate_params = _in_clause(self._id_sql_expr(), values)
        return self._lookup_chunks(
            predicate_sql=predicate_sql,
            predicate_params=predicate_params,
            filters=filters,
            lookup_type="chunk_id",
        )

    def get_chunks_by_document_ids(
        self,
        document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Batch direct lookup for all chunks belonging to document IDs."""
        values = _unique_non_empty_strings(document_ids)
        if not values:
            return []
        predicate_sql, predicate_params = _in_clause(self._document_id_sql_expr(), values)
        return self._lookup_chunks(
            predicate_sql=predicate_sql,
            predicate_params=predicate_params,
            filters=filters,
            lookup_type="document_id",
        )

    def get_chunks_by_parent_document_ids(
        self,
        parent_document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Batch direct lookup for child chunks referencing parent document IDs."""
        values = _unique_non_empty_strings(parent_document_ids)
        if not values:
            return []
        metadata = _quote_identifier(self.config.metadata_column)
        parent_expr = (
            f"{metadata} ->> {_quote_literal(self.config.parent_document_id_metadata_key)}"
        )
        predicate_sql, predicate_params = _in_clause(parent_expr, values)
        return self._lookup_chunks(
            predicate_sql=predicate_sql,
            predicate_params=predicate_params,
            filters=filters,
            lookup_type="parent_document_id",
        )

    def get_chunk_windows(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Batch direct lookup for sibling chunks around target chunk positions."""
        if before < 0 or after < 0:
            raise RetrievalError("before and after must be non-negative")
        unique_targets = _unique_window_targets(targets)
        if not unique_targets:
            return []

        doc_expr = self._document_id_sql_expr()
        chunk_index_expr = self._chunk_index_sql_expr()
        clauses: list[str] = []
        params: list[Any] = []
        for target in unique_targets:
            start = max(0, target.chunk_index - before)
            end = target.chunk_index + after
            clauses.append(f"({doc_expr} = %s AND {chunk_index_expr} BETWEEN %s AND %s)")
            params.extend([target.document_id, start, end])

        predicate_sql = "(" + " OR ".join(clauses) + ")"
        return self._lookup_chunks(
            predicate_sql=predicate_sql,
            predicate_params=tuple(params),
            filters=filters,
            lookup_type="chunk_window",
        )

    def get_chunk_window_batch(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Backward-compatible alias for batch window lookup."""
        return self.get_chunk_windows(targets, before=before, after=after, filters=filters)

    def run_chunk_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        """Run a configured named chunk query with parameter binding."""
        try:
            sql, bound_params = self.build_chunk_query(
                name,
                params=params,
                filters=filters,
                limit=limit,
            )
            rows = []

            def execute() -> None:
                nonlocal rows
                with self._cursor() as cursor:
                    cursor.execute(sql, bound_params)
                    rows = cursor.fetchall()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise

        documents = [_row_to_document(row, rank=index + 1) for index, row in enumerate(rows)]
        return documents

    def build_chunk_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Build a configured custom chunk query for tests and review."""
        query = self.config.custom_chunk_queries.get(name)
        if query is None:
            raise RetrievalError(f"unknown custom chunk query: {name}")
        _validate_custom_query_template(query.sql)

        user_params = dict(params or {})
        _validate_custom_query_params(name, user_params, query.allowed_params)
        resolved_limit = _resolve_custom_query_limit(
            name,
            default_limit=query.default_limit,
            max_limit=query.max_limit,
            limit=limit,
            kind="custom chunk query",
        )
        sql, filter_params = self._render_named_query_template(query.sql, filters=filters)
        return sql, {**user_params, **filter_params, "limit": resolved_limit}

    def run_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Run a configured named row query with parameter binding."""
        try:
            sql, bound_params = self.build_query(
                name,
                params=params,
                filters=filters,
                limit=limit,
            )
            rows = []

            def execute() -> None:
                nonlocal rows
                with self._cursor(row_factory=_dict_row_factory()) as cursor:
                    cursor.execute(sql, bound_params)
                    rows = cursor.fetchall()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise

        return [_row_to_dict(row) for row in rows]

    def build_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> tuple[str, dict[str, Any]]:
        """Build a configured custom row query for tests and review."""
        query = self.config.custom_queries.get(name)
        if query is None:
            raise RetrievalError(f"unknown custom query: {name}")
        _validate_custom_query_template(query.sql)

        user_params = dict(params or {})
        _validate_custom_query_params(name, user_params, query.allowed_params)
        resolved_limit = _resolve_custom_query_limit(
            name,
            default_limit=query.default_limit,
            max_limit=query.max_limit,
            limit=limit,
            kind="custom query",
        )
        sql, filter_params = self._render_named_query_template(query.sql, filters=filters)
        return sql, {**user_params, **filter_params, "limit": resolved_limit}

    def build_search_query(
        self,
        *,
        query_embedding: list[float] | None,
        query_text: str | None,
        top_k: int,
        filters: MetadataFilters | None,
        search_type: SearchType,
        fetch_k: int | None = None,
        score_threshold: float | None = None,
        length_weight: float | None = None,
        diversity_penalty_weight: float | None = None,
        diversity_metadata_key: str | None = None,
    ) -> tuple[str, tuple[Any, ...]]:
        """Build parameterized SQL for each search strategy."""
        limit = fetch_k or top_k
        where_sql, where_params = self._where_clause(filters)
        table = self._table_ref()
        select_columns = self._select_columns()
        embedding_column = _quote_identifier(self.config.embedding_column)

        if search_type == "vector":
            sql = (
                f"SELECT {select_columns}, "
                f"1 - ({embedding_column} <=> %s::vector) AS score, 'vector' AS result_source "
                f"FROM {table} {where_sql} "
                f"ORDER BY {embedding_column} <=> %s::vector LIMIT %s"
            )
            params = (
                _vector_literal(query_embedding or []),
                *where_params,
                _vector_literal(query_embedding or []),
                limit,
            )
            return sql, params

        if search_type == "keyword":
            score_sql = self._keyword_score_sql(query_text)
            match_sql = self._keyword_match_sql(query_text)
            match_connector = "WHERE" if not where_sql else "AND"
            sql = (
                f"SELECT {select_columns}, "
                f"{score_sql} AS score, 'keyword' AS result_source "
                f"FROM {table} {where_sql} "
                f"{match_connector} {match_sql} "
                "ORDER BY score DESC LIMIT %s"
            )
            params = (
                *self._keyword_score_params(query_text),
                *where_params,
                *self._keyword_match_params(query_text),
                limit,
            )
            return sql, params

        if search_type == "weighted_vector":
            return self._build_weighted_vector_query(
                query_embedding=query_embedding or [],
                top_k=top_k,
                candidate_pool_size=limit,
                where_sql=where_sql,
                where_params=where_params,
                score_threshold=self.config.score_threshold
                if score_threshold is None
                else score_threshold,
                length_weight=self.config.length_weight
                if length_weight is None
                else length_weight,
                diversity_penalty_weight=self.config.diversity_penalty_weight
                if diversity_penalty_weight is None
                else diversity_penalty_weight,
                diversity_metadata_key=diversity_metadata_key
                or self.config.diversity_metadata_key,
            )

        vector_sql, vector_params = self.build_search_query(
            query_embedding=query_embedding,
            query_text=None,
            top_k=limit,
            filters=filters,
            search_type="vector",
        )
        keyword_sql, keyword_params = self.build_search_query(
            query_embedding=None,
            query_text=query_text,
            top_k=limit,
            filters=filters,
            search_type="keyword",
        )
        sql = (
            "WITH vector_results AS ("
            f"{_strip_limit_order_projection(vector_sql)}"
            "), keyword_results AS ("
            f"{_strip_limit_order_projection(keyword_sql)}"
            ") "
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "SUM(weighted_score) AS score, 'hybrid' AS result_source "
            "FROM ("
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "score * %s AS weighted_score FROM vector_results "
            "UNION ALL "
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "score * %s AS weighted_score FROM keyword_results"
            ") merged "
            "GROUP BY id, document_id, chunk_index, content, metadata, source "
            "ORDER BY score DESC LIMIT %s"
        )
        params = (
            *vector_params[:-2],
            *keyword_params[:-1],
            self.config.vector_weight,
            self.config.keyword_weight,
            top_k,
        )
        return sql, params

    def _build_weighted_vector_query(
        self,
        *,
        query_embedding: list[float],
        top_k: int,
        candidate_pool_size: int,
        where_sql: str,
        where_params: tuple[Any, ...],
        score_threshold: float,
        length_weight: float,
        diversity_penalty_weight: float,
        diversity_metadata_key: str,
    ) -> tuple[str, tuple[Any, ...]]:
        _validate_non_negative("score_threshold", score_threshold)
        _validate_non_negative("length_weight", length_weight)
        _validate_non_negative("diversity_penalty_weight", diversity_penalty_weight)

        table = self._table_ref()
        select_columns = self._select_columns()
        embedding_column = _quote_identifier(self.config.embedding_column)
        content_column = _quote_identifier(self.config.content_column)
        metadata_column = _quote_identifier(self.config.metadata_column)
        id_expr = self._id_sql_expr()
        vector = _vector_literal(query_embedding)
        where_prefix = f"{where_sql} AND" if where_sql else "WHERE"

        sql = (
            "WITH raw_candidate AS ("
            f"SELECT {select_columns}, "
            f"1 - ({embedding_column} <=> %s::vector) AS base_score, "
            f"LENGTH({content_column}) AS content_length, "
            f"COALESCE({metadata_column} ->> %s, {id_expr}) AS diversity_source "
            f"FROM {table} {where_sql} "
            f"{where_prefix} {embedding_column} IS NOT NULL "
            f"AND 1 - ({embedding_column} <=> %s::vector) >= %s "
            f"ORDER BY {embedding_column} <=> %s::vector "
            "LIMIT %s"
            "), normalized_length AS ("
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "base_score, content_length, diversity_source, "
            "CASE WHEN MAX(content_length) OVER() = MIN(content_length) OVER() "
            "THEN 0.5 ELSE "
            "(content_length - MIN(content_length) OVER())::float / "
            "(MAX(content_length) OVER() - MIN(content_length) OVER()) "
            "END AS normalized_length "
            "FROM raw_candidate"
            "), length_weighted AS ("
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "base_score * (1.0 + %s * normalized_length) AS weighted_score, "
            "base_score, content_length, normalized_length, diversity_source "
            "FROM normalized_length"
            "), diversity_penalty AS ("
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "weighted_score - %s * ("
            "COUNT(*) OVER ("
            "PARTITION BY diversity_source "
            "ORDER BY weighted_score DESC "
            "ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW"
            ") - 1"
            ") AS score, "
            "base_score, weighted_score, content_length, normalized_length, "
            "diversity_source "
            "FROM length_weighted"
            ") "
            "SELECT id, document_id, chunk_index, content, metadata, source, "
            "score, 'weighted_vector' AS result_source, "
            "base_score, weighted_score, content_length, normalized_length, "
            "diversity_source "
            "FROM diversity_penalty "
            "ORDER BY score DESC LIMIT %s"
        )
        params = (
            vector,
            diversity_metadata_key,
            *where_params,
            vector,
            score_threshold,
            vector,
            candidate_pool_size,
            length_weight,
            diversity_penalty_weight,
            top_k,
        )
        return sql, params

    def close(self) -> None:
        self._health_check_stop.set()
        if self._health_check_thread is not None:
            self._health_check_thread.join(timeout=1.0)
            self._health_check_thread = None
        if self._owns_pool and self._pool is not None:
            self._pool.close()
            self._pool = None
        if self._owns_connection and self._connection is not None:
            self._connection.close()
            self._connection = None

    def _render_named_query_template(
        self,
        sql: str,
        *,
        filters: MetadataFilters | None,
    ) -> tuple[str, dict[str, Any]]:
        filter_params: dict[str, Any] = {}
        rendered = _render_custom_query_template(
            sql,
            macros={
                "select_columns": self._select_columns(),
                "table": self._table_ref(),
                "limit_clause": "LIMIT %(limit)s",
            },
        )

        def replace_table(match: re.Match[str]) -> str:
            name = match.group("name")
            table = self.config.query_tables.get(name)
            if table is None:
                raise RetrievalError(f"unknown custom query table: {name}")
            return _table_ref(table.table_name, schema_name=table.schema_name)

        rendered = _TABLE_MACRO_RE.sub(replace_table, rendered)

        def replace_filter(match: re.Match[str]) -> str:
            connector = match.group("connector")
            alias = match.group("alias")
            param_prefix = "filter" if alias is None else f"filter_{alias}"
            filter_where, filter_and, params = self._where_clause_named(
                filters,
                table_alias=alias,
                param_prefix=param_prefix,
            )
            duplicated = {
                key
                for key, value in params.items()
                if key in filter_params and filter_params[key] != value
            }
            if duplicated:
                raise RetrievalError(
                    f"duplicate custom query filter params: {sorted(duplicated)}"
                )
            filter_params.update(params)
            return filter_where if connector == "where" else filter_and

        rendered = _FILTER_MACRO_RE.sub(replace_filter, rendered)
        return rendered, filter_params

    def _where_clause(self, filters: MetadataFilters | None) -> tuple[str, tuple[Any, ...]]:
        clauses = []
        params: list[Any] = []
        if self.config.collection_name and self.config.collection_column:
            clauses.append(f"{_quote_identifier(self.config.collection_column)} = %s")
            params.append(self.config.collection_name)
        for key, value in (filters or {}).items():
            clause, clause_params = self._metadata_filter_clause(key, value)
            clauses.append(clause)
            params.extend(clause_params)
        if not clauses:
            return "", tuple(params)
        return "WHERE " + " AND ".join(clauses), tuple(params)

    def _where_clause_named(
        self,
        filters: MetadataFilters | None,
        *,
        table_alias: str | None = None,
        param_prefix: str = "filter",
    ) -> tuple[str, str, dict[str, Any]]:
        clauses = []
        params: dict[str, Any] = {}
        if self.config.collection_name and self.config.collection_column:
            collection_param = (
                "collection_name"
                if param_prefix == "filter"
                else f"{param_prefix}_collection_name"
            )
            clauses.append(
                f"{self._column_ref(self.config.collection_column, table_alias=table_alias)} "
                f"= %({collection_param})s"
            )
            params[collection_param] = self.config.collection_name
        for index, (key, value) in enumerate((filters or {}).items()):
            clause, clause_params = self._metadata_filter_clause_named(
                key,
                value,
                index,
                table_alias=table_alias,
                param_prefix=param_prefix,
            )
            clauses.append(clause)
            params.update(clause_params)
        if not clauses:
            return "", "", params
        clause = " AND ".join(clauses)
        return "WHERE " + clause, "AND " + clause, params

    def _metadata_filter_clause(
        self,
        key: str,
        value: MetadataFilterValue,
    ) -> tuple[str, tuple[Any, ...]]:
        self._validate_filter_key(key)
        metadata = _quote_identifier(self.config.metadata_column)
        operator, operand = _normalize_filter_condition(value)
        if operator == "eq":
            return f"{metadata} ->> %s = %s", (key, operand)
        if operator == "ne":
            return f"({metadata} ? %s AND {metadata} ->> %s <> %s)", (key, key, operand)
        if operator == "in":
            return f"{metadata} ->> %s = ANY(%s::text[])", (key, operand)
        if operator == "contains":
            return f"({metadata} -> %s) ? %s", (key, operand)
        if operator == "contains_any":
            return f"({metadata} -> %s) ?| %s::text[]", (key, operand)
        if operator == "not_contains":
            return (
                f"({metadata} ? %s AND NOT (({metadata} -> %s) ? %s))",
                (key, key, operand),
            )
        if operator == "not_contains_any":
            return (
                f"({metadata} ? %s AND NOT (({metadata} -> %s) ?| %s::text[]))",
                (key, key, operand),
            )
        raise RetrievalError(f"unsupported metadata filter operator: {operator}")

    def _metadata_filter_clause_named(
        self,
        key: str,
        value: MetadataFilterValue,
        index: int,
        *,
        table_alias: str | None = None,
        param_prefix: str = "filter",
    ) -> tuple[str, dict[str, Any]]:
        self._validate_filter_key(key)
        metadata = self._column_ref(self.config.metadata_column, table_alias=table_alias)
        operator, operand = _normalize_filter_condition(value)
        key_param = f"{param_prefix}_key_{index}"
        value_param = f"{param_prefix}_value_{index}"
        if operator == "eq":
            clause = f"{metadata} ->> %({key_param})s = %({value_param})s"
            params = {key_param: key, value_param: operand}
        elif operator == "ne":
            clause = (
                f"({metadata} ? %({key_param})s "
                f"AND {metadata} ->> %({key_param})s <> %({value_param})s)"
            )
            params = {key_param: key, value_param: operand}
        elif operator == "in":
            clause = f"{metadata} ->> %({key_param})s = ANY(%({value_param})s::text[])"
            params = {key_param: key, value_param: operand}
        elif operator == "contains":
            clause = f"({metadata} -> %({key_param})s) ? %({value_param})s"
            params = {key_param: key, value_param: operand}
        elif operator == "contains_any":
            clause = f"({metadata} -> %({key_param})s) ?| %({value_param})s::text[]"
            params = {key_param: key, value_param: operand}
        elif operator == "not_contains":
            clause = (
                f"({metadata} ? %({key_param})s "
                f"AND NOT (({metadata} -> %({key_param})s) ? %({value_param})s))"
            )
            params = {key_param: key, value_param: operand}
        elif operator == "not_contains_any":
            clause = (
                f"({metadata} ? %({key_param})s "
                f"AND NOT (({metadata} -> %({key_param})s) ?| "
                f"%({value_param})s::text[]))"
            )
            params = {key_param: key, value_param: operand}
        else:
            raise RetrievalError(f"unsupported metadata filter operator: {operator}")
        return clause, params

    def _lookup_chunks(
        self,
        *,
        predicate_sql: str,
        predicate_params: tuple[Any, ...],
        filters: MetadataFilters | None,
        lookup_type: str,
    ) -> list[Document]:
        where_sql, where_params = self._where_clause(filters)
        connector = "WHERE" if not where_sql else "AND"
        sql = (
            f"SELECT {self._select_columns()}, "
            "NULL::float AS score, 'lookup' AS result_source "
            f"FROM {self._table_ref()} {where_sql} "
            f"{connector} {predicate_sql} "
            "ORDER BY document_id, chunk_index, id"
        )
        params = (*where_params, *predicate_params)
        try:
            rows = []

            def execute() -> None:
                nonlocal rows
                with self._cursor() as cursor:
                    cursor.execute(sql, params)
                    rows = cursor.fetchall()

            self._execute_with_optional_retry(execute)
        except Exception:
            raise

        documents = [_row_to_document(row, rank=index + 1) for index, row in enumerate(rows)]
        return documents

    def _validate_filter_key(self, key: str) -> None:
        if key not in self.config.allowed_filter_keys:
            raise RetrievalError(f"unsupported metadata filter key: {key}")

    @contextmanager
    def _cursor(self, *, row_factory: Any | None = None) -> Iterator[Any]:
        with self._connection_context() as connection:
            try:
                cursor_context = (
                    connection.cursor(row_factory=row_factory)
                    if row_factory is not None
                    else connection.cursor()
                )
            except TypeError:
                cursor_context = connection.cursor()
            with cursor_context as cursor:
                yield cursor

    @contextmanager
    def _connection_context(self) -> Iterator[Any]:
        if self._pool is not None:
            with self._pool.connection(timeout=self.config.pool_timeout) as connection:
                yield connection
            return
        yield self._get_connection()

    def _get_connection(self) -> Any:
        if self._connection is not None:
            return self._connection
        if not self.dsn:
            raise ConfigurationError("PostgresRetrievalStore requires dsn or connection")
        try:
            psycopg = import_module("psycopg")
        except ImportError as exc:
            raise ConfigurationError(
                "PostgresRetrievalStore requires psycopg. Install the package with the "
                "'retrieval' extra from the internal package index, e.g. "
                "python -m pip install 'kbcard-agent-common[retrieval]'"
            ) from exc
        self._connection = psycopg.connect(self.dsn, **self._connect_kwargs())
        return self._connection

    def _commit(self) -> None:
        if self._pool is not None:
            return
        if self._connection is None:
            return
        commit = getattr(self._connection, "commit", None)
        if commit is not None and not getattr(self._connection, "autocommit", False):
            commit()

    def _get_pool(self) -> Any:
        if self._pool is not None:
            return self._pool
        with self._pool_lock:
            if self._pool is not None:
                return self._pool
            if not self.dsn:
                raise ConfigurationError("PostgresRetrievalStore requires dsn or connection")
            try:
                psycopg_pool = import_module("psycopg_pool")
            except ImportError as exc:
                raise ConfigurationError(
                    "PostgresRetrievalStore connection pooling requires psycopg_pool. "
                    "Install the package with the 'retrieval' extra, e.g. "
                    "python -m pip install 'kbcard-agent-common[retrieval]'"
                ) from exc
            check_connection = getattr(psycopg_pool.ConnectionPool, "check_connection", None)
            self._pool = psycopg_pool.ConnectionPool(
                conninfo=self.dsn,
                kwargs=self._connect_kwargs(),
                min_size=self.config.pool_min_size,
                max_size=self.config.pool_max_size,
                timeout=self.config.pool_timeout,
                max_lifetime=self.config.pool_max_lifetime,
                max_idle=self.config.pool_max_idle,
                reconnect_timeout=self.config.pool_reconnect_timeout,
                check=check_connection,
                open=True,
            )
            self._start_health_check()
            return self._pool

    def _connect_kwargs(self) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"autocommit": self.config.autocommit}
        if self.config.keepalives:
            kwargs.update(
                {
                    "keepalives": 1,
                    "keepalives_idle": self.config.keepalives_idle,
                    "keepalives_interval": self.config.keepalives_interval,
                    "keepalives_count": self.config.keepalives_count,
                }
            )
        return kwargs

    def _execute_with_optional_retry(self, operation: Any) -> None:
        try:
            if self._connection is None and self._pool is None and self.dsn:
                self._get_pool()
            operation()
        except Exception as exc:
            if not self._should_retry_connection_error(exc):
                raise
            self._discard_broken_connection()
            operation()

    def _should_retry_connection_error(self, exc: Exception) -> bool:
        if not self.config.retry_on_connection_error:
            return False
        try:
            psycopg = import_module("psycopg")
        except ImportError:
            return False
        retry_errors = (
            getattr(psycopg, "OperationalError", ()),
            getattr(psycopg, "InterfaceError", ()),
        )
        return isinstance(exc, retry_errors)

    def _discard_broken_connection(self) -> None:
        if self._pool is not None:
            drain = getattr(self._pool, "drain", None)
            if callable(drain):
                drain()
            return
        if self._connection is not None and self._owns_connection:
            close = getattr(self._connection, "close", None)
            if callable(close):
                close()
            self._connection = None

    def _start_health_check(self) -> None:
        interval = self.config.health_check_interval
        if interval is None or self._health_check_thread is not None:
            return

        def run() -> None:
            while not self._health_check_stop.wait(interval):
                pool = self._pool
                if pool is None:
                    return
                check = getattr(pool, "check", None)
                if callable(check):
                    try:
                        check()
                    except Exception:
                        continue

        self._health_check_thread = threading.Thread(
            target=run,
            name="kbcard-postgres-pool-health-check",
            daemon=True,
        )
        self._health_check_thread.start()

    def _create_table_sql(self) -> str:
        table = self._table_ref()
        id_column = _quote_identifier(self.config.id_column)
        collection_column = _quote_identifier(self.config.collection_column or "collection_name")
        document_id_column = _quote_identifier(self.config.document_id_column or "document_id")
        chunk_index_column = _quote_identifier(self.config.chunk_index_column or "chunk_index")
        content_column = _quote_identifier(self.config.content_column)
        metadata_column = _quote_identifier(self.config.metadata_column)
        embedding_column = _quote_identifier(self.config.embedding_column)
        search_text_column = _quote_identifier(
            self.config.keyword_tsvector_column or "search_text"
        )
        source_column = _quote_identifier(self.config.source_column or "source")
        return f"""
CREATE TABLE IF NOT EXISTS {table} (
    {id_column} TEXT PRIMARY KEY,
    {collection_column} TEXT NOT NULL,
    {document_id_column} TEXT NOT NULL,
    {chunk_index_column} INTEGER NOT NULL,
    {content_column} TEXT NOT NULL,
    {metadata_column} JSONB NOT NULL DEFAULT '{{}}'::jsonb,
    {embedding_column} VECTOR({self.config.embedding_dimensions}) NOT NULL,
    {search_text_column} TSVECTOR,
    {source_column} TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
)
""".strip()

    def _upsert_sql(self) -> str:
        table = self._table_ref()
        id_column = _quote_identifier(self.config.id_column)
        collection_column = _quote_identifier(self.config.collection_column or "collection_name")
        document_id_column = _quote_identifier(self.config.document_id_column or "document_id")
        chunk_index_column = _quote_identifier(self.config.chunk_index_column or "chunk_index")
        content_column = _quote_identifier(self.config.content_column)
        metadata_column = _quote_identifier(self.config.metadata_column)
        embedding_column = _quote_identifier(self.config.embedding_column)
        search_text_column = _quote_identifier(
            self.config.keyword_tsvector_column or "search_text"
        )
        source_column = _quote_identifier(self.config.source_column or "source")
        return f"""
INSERT INTO {table} (
    {id_column},
    {collection_column},
    {document_id_column},
    {chunk_index_column},
    {content_column},
    {metadata_column},
    {embedding_column},
    {search_text_column},
    {source_column},
    updated_at
) VALUES (
    %s, %s, %s, %s, %s, %s::jsonb, %s::vector, to_tsvector(%s), %s, now()
)
ON CONFLICT ({id_column}) DO UPDATE SET
    {collection_column} = EXCLUDED.{collection_column},
    {document_id_column} = EXCLUDED.{document_id_column},
    {chunk_index_column} = EXCLUDED.{chunk_index_column},
    {content_column} = EXCLUDED.{content_column},
    {metadata_column} = EXCLUDED.{metadata_column},
    {embedding_column} = EXCLUDED.{embedding_column},
    {search_text_column} = EXCLUDED.{search_text_column},
    {source_column} = EXCLUDED.{source_column},
    updated_at = now()
""".strip()

    def _table_ref(self) -> str:
        return _table_ref(self.config.table_name, schema_name=self.config.schema_name)

    def _column_ref(self, column_name: str, *, table_alias: str | None = None) -> str:
        column = _quote_identifier(column_name)
        if table_alias is None:
            return column
        return f"{_quote_identifier(table_alias)}.{column}"

    def _select_columns(self) -> str:
        metadata = _quote_identifier(self.config.metadata_column)
        id_expr = self._id_sql_expr()

        if self.config.source_column:
            source_expr = _quote_identifier(self.config.source_column)
        else:
            source_expr = f"{metadata} ->> {_quote_literal(self.config.source_metadata_key)}"

        return (
            f"{id_expr} AS id, "
            f"{self._document_id_sql_expr()} AS document_id, "
            f"{self._chunk_index_sql_expr()} AS chunk_index, "
            f"{_quote_identifier(self.config.content_column)} AS content, "
            f"{metadata} AS metadata, "
            f"{source_expr} AS source"
        )

    def _id_sql_expr(self) -> str:
        id_column = _quote_identifier(self.config.id_column)
        if not self.config.chunk_id_column:
            return f"{id_column}::text"
        return f"COALESCE({_quote_identifier(self.config.chunk_id_column)}, {id_column}::text)"

    def _document_id_sql_expr(self) -> str:
        metadata = _quote_identifier(self.config.metadata_column)
        if self.config.document_id_column:
            return _quote_identifier(self.config.document_id_column)
        return (
            f"COALESCE({metadata} ->> {_quote_literal(self.config.document_id_metadata_key)}, "
            f"{_quote_identifier(self.config.id_column)}::text)"
        )

    def _chunk_index_sql_expr(self) -> str:
        metadata = _quote_identifier(self.config.metadata_column)
        if self.config.chunk_index_column:
            return _quote_identifier(self.config.chunk_index_column)
        return (
            f"NULLIF({metadata} ->> {_quote_literal(self.config.chunk_index_metadata_key)}, '')"
            "::integer"
        )

    def _keyword_score_sql(self, query_text: str | None) -> str:
        if self.config.keyword_tsvector_column:
            vector_expr = _quote_identifier(self.config.keyword_tsvector_column)
        else:
            vector_expr = (
                f"to_tsvector(%s::regconfig, {_quote_identifier(self.config.content_column)})"
            )
        return f"ts_rank_cd({vector_expr}, {self._keyword_query_sql(query_text)})"

    def _keyword_match_sql(self, query_text: str | None) -> str:
        if self.config.keyword_tsvector_column:
            vector_expr = _quote_identifier(self.config.keyword_tsvector_column)
            return f"{vector_expr} @@ {self._keyword_query_sql(query_text)}"
        vector_expr = f"to_tsvector(%s::regconfig, {_quote_identifier(self.config.content_column)})"
        return f"{vector_expr} @@ {self._keyword_query_sql(query_text)}"

    def _keyword_score_params(self, query_text: str | None) -> tuple[Any, ...]:
        query_params = self._keyword_query_params(query_text)
        if self.config.keyword_tsvector_column:
            return query_params
        return (self.config.language, *query_params)

    def _keyword_match_params(self, query_text: str | None) -> tuple[Any, ...]:
        query_params = self._keyword_query_params(query_text)
        if self.config.keyword_tsvector_column:
            return query_params
        return (self.config.language, *query_params)

    def _keyword_query_sql(self, query_text: str | None) -> str:
        terms = _keyword_terms(query_text)
        return "(" + " || ".join(["plainto_tsquery(%s::regconfig, %s)"] * len(terms)) + ")"

    def _keyword_query_params(self, query_text: str | None) -> tuple[Any, ...]:
        params: list[Any] = []
        for term in _keyword_terms(query_text):
            params.extend([self.config.language, term])
        return tuple(params)


def _row_to_document(row: Any, *, rank: int) -> Document:
    if isinstance(row, dict):
        get = row.get
    else:
        get = _tuple_getter(row)
    metadata = get("metadata") or {}
    if isinstance(metadata, str):
        metadata = json.loads(metadata)
    if not isinstance(metadata, dict):
        metadata = {}

    retrieval_metadata = {
        "base_score": _optional_float(get("base_score")),
        "weighted_score": _optional_float(get("weighted_score")),
        "content_length": get("content_length"),
        "normalized_length": _optional_float(get("normalized_length")),
        "diversity_source": get("diversity_source"),
        "strategy": get("result_source"),
    }
    compact_retrieval_metadata = {
        key: value for key, value in retrieval_metadata.items() if value is not None
    }
    if compact_retrieval_metadata:
        metadata = {**metadata, "_retrieval": compact_retrieval_metadata}

    relations = _compact_dict(
        {
            "chunk_id": str(get("id")) if get("id") is not None else None,
            "document_id": str(get("document_id")) if get("document_id") is not None else None,
            "chunk_index": _optional_int(get("chunk_index")),
            "source": get("source"),
        }
    )
    existing_relations = metadata.get("_relations")
    if isinstance(existing_relations, dict):
        relations = {**existing_relations, **relations}
    if relations:
        metadata = {**metadata, "_relations": relations}

    return Document(
        id=str(get("id")),
        content=str(get("content")),
        metadata=metadata,
        score=_optional_float(get("score")),
        rank=rank,
        source=str(get("result_source") or get("source") or ""),
    )


def _row_to_dict(row: Any) -> dict[str, Any]:
    if isinstance(row, dict):
        return dict(row)
    if hasattr(row, "items"):
        return dict(row.items())
    return {str(index): value for index, value in enumerate(row)}


def _tuple_getter(row: tuple[Any, ...]):
    keys = [
        "id",
        "document_id",
        "chunk_index",
        "content",
        "metadata",
        "source",
        "score",
        "result_source",
        "base_score",
        "weighted_score",
        "content_length",
        "normalized_length",
        "diversity_source",
    ]
    values = dict(zip(keys, row, strict=False))
    return values.get


def _optional_float(value: Any) -> float | None:
    return None if value is None else float(value)


def _optional_int(value: Any) -> int | None:
    return None if value is None else int(value)


def _compact_dict(values: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}


def _unique_non_empty_strings(values: list[str]) -> list[str]:
    unique: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = str(value)
        if not normalized or normalized in seen:
            continue
        unique.append(normalized)
        seen.add(normalized)
    return unique


def _unique_window_targets(targets: list[ChunkWindowTarget]) -> list[ChunkWindowTarget]:
    unique: list[ChunkWindowTarget] = []
    seen: set[tuple[str, int]] = set()
    for target in targets:
        key = (str(target.document_id), int(target.chunk_index))
        if not key[0] or key in seen:
            continue
        unique.append(ChunkWindowTarget(document_id=key[0], chunk_index=key[1]))
        seen.add(key)
    return unique


def _normalize_filter_condition(value: MetadataFilterValue) -> tuple[str, str | list[str]]:
    if isinstance(value, str):
        return "eq", value
    if isinstance(value, list):
        return "in", _normalize_filter_values(value)
    if not isinstance(value, dict):
        raise RetrievalError("metadata filter value must be a string, list, or operator object")
    if len(value) != 1:
        raise RetrievalError("metadata filter operator object must contain exactly one operator")
    operator, operand = next(iter(value.items()))
    if operator in {"eq", "ne", "contains", "not_contains"}:
        if isinstance(operand, list):
            raise RetrievalError(f"metadata filter operator {operator!r} requires one value")
        return operator, str(operand)
    if operator in {"in", "contains_any", "not_contains_any"}:
        if not isinstance(operand, list):
            raise RetrievalError(f"metadata filter operator {operator!r} requires a value list")
        return operator, _normalize_filter_values(operand)
    raise RetrievalError(f"unsupported metadata filter operator: {operator}")


def _normalize_filter_values(values: list[str]) -> list[str]:
    normalized = [str(value) for value in values if str(value)]
    if not normalized:
        raise RetrievalError("metadata filter value list must not be empty")
    return normalized


def _keyword_terms(query_text: str | None) -> list[str]:
    terms = [term for term in str(query_text or "").split() if term]
    return terms or [str(query_text or "")]


def _in_clause(expression: str, values: list[str]) -> tuple[str, tuple[Any, ...]]:
    placeholders = ", ".join(["%s"] * len(values))
    return f"{expression} IN ({placeholders})", tuple(values)


def _validate_custom_query_template(sql: str) -> None:
    stripped = sql.strip()
    lowered = stripped.lower()
    if not (lowered.startswith("select") or lowered.startswith("with")):
        raise RetrievalError("custom query must start with SELECT or WITH")
    if ";" in stripped:
        raise RetrievalError("custom query must contain a single statement")
    forbidden = re.compile(
        r"\b(insert|update|delete|drop|alter|truncate|create|copy|grant|revoke)\b",
        re.IGNORECASE,
    )
    if forbidden.search(stripped):
        raise RetrievalError("custom query must be read-only")


def _validate_custom_query_params(
    name: str,
    params: dict[str, Any],
    allowed_params: set[str],
) -> None:
    reserved = {"limit"}
    unsupported = set(params) - allowed_params
    if unsupported:
        raise RetrievalError(
            f"unsupported custom chunk query params for {name}: {sorted(unsupported)}"
        )
    if reserved.intersection(params):
        raise RetrievalError("custom chunk query params cannot include reserved keys")
    for key in params:
        if key.startswith("filter_") or key == "collection_name":
            raise RetrievalError("custom chunk query params use reserved key prefix")


def _resolve_custom_query_limit(
    name: str,
    *,
    default_limit: int,
    max_limit: int,
    limit: int | None,
    kind: str,
) -> int:
    resolved_limit = default_limit if limit is None else limit
    if resolved_limit < 1:
        raise RetrievalError(f"{kind} limit must be positive")
    if resolved_limit > max_limit:
        raise RetrievalError(f"{kind} {name!r} limit exceeds max_limit={max_limit}")
    return resolved_limit


def _render_custom_query_template(sql: str, *, macros: dict[str, str]) -> str:
    rendered = sql
    for key, value in macros.items():
        rendered = rendered.replace("{" + key + "}", value)
    return rendered


def _validate_non_negative(name: str, value: float) -> None:
    if value < 0:
        raise RetrievalError(f"{name} must be non-negative")


def _vector_literal(value: list[float]) -> str:
    return "[" + ",".join(str(float(item)) for item in value) + "]"


def _dict_row_factory() -> Any | None:
    try:
        psycopg_rows = import_module("psycopg.rows")
    except ImportError:
        return None
    return getattr(psycopg_rows, "dict_row", None)


def _table_ref(table_name: str, *, schema_name: str | None = None) -> str:
    table = _quote_identifier(table_name)
    if not schema_name:
        return table
    return f"{_quote_identifier(schema_name)}.{table}"


def _quote_identifier(value: str) -> str:
    if not value or "\x00" in value:
        raise RetrievalError(f"invalid SQL identifier: {value}")
    return '"' + value.replace('"', '""') + '"'


def _quote_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _strip_limit_order_projection(sql: str) -> str:
    return re.sub(r"\s+ORDER BY .+ LIMIT %s$", "", sql, flags=re.IGNORECASE | re.DOTALL)
