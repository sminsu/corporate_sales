"""LanceDB vector store adapter."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from kbcard_agent_common.errors import ConfigurationError, RetrievalError
from kbcard_agent_common.ingestion.types import EmbeddedChunk
from kbcard_agent_common.retrieval.stores.base import SearchType
from kbcard_agent_common.types import (
    ChunkWindowTarget,
    Document,
    MetadataFilters,
    MetadataFilterValue,
)


class LanceDBRetrievalStore:
    """Local embedded vector store for examples and smoke tests."""

    def __init__(
        self,
        uri: str | Path,
        *,
        table_name: str = "kbcard_chunks",
        vector_column: str = "vector",
    ) -> None:
        self.uri = str(uri)
        self.table_name = table_name
        self.vector_column = vector_column
        self._db: Any | None = None
        self._table: Any | None = None

    def ensure_collection(self) -> None:
        if self._table is not None:
            return

        try:
            import lancedb
        except ImportError as exc:
            raise ConfigurationError(
                "LanceDBRetrievalStore requires lancedb. Install the package with the "
                "'lancedb' extra from the internal package index, e.g. "
                "python -m pip install 'kbcard-agent-common[lancedb]'"
            ) from exc

        self._db = lancedb.connect(self.uri)
        table_names = _table_names(self._db.list_tables())
        if self.table_name in table_names:
            self._table = self._db.open_table(self.table_name)

    def upsert(self, chunks: list[EmbeddedChunk]) -> None:
        if not chunks:
            return
        self.ensure_collection()
        records = [_chunk_to_record(chunk, self.vector_column) for chunk in chunks]

        try:
            if self._table is None:
                if self._db is None:
                    raise RetrievalError("LanceDB connection is not initialized")
                self._table = self._db.create_table(self.table_name, data=records)
                return

            (
                self._table.merge_insert("id")
                .when_matched_update_all()
                .when_not_matched_insert_all()
                .execute(records)
            )
        except Exception as exc:
            raise RetrievalError("failed to upsert chunks into LanceDB") from exc

    def delete_by_source(self, source: str) -> int:
        self.ensure_collection()
        if self._table is None:
            return 0

        try:
            result = self._table.delete(f"source = {_quote_sql_string(source)}")
        except Exception as exc:
            raise RetrievalError("failed to delete LanceDB chunks by source") from exc
        deleted_count = int(getattr(result, "num_deleted_rows", 0))
        return deleted_count

    def similarity_search(
        self,
        query_embedding: list[float],
        *,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        self.ensure_collection()
        if self._table is None:
            return []

        try:
            fetch_k = max(top_k * 20, top_k) if filters else top_k
            query = self._table.search(
                query_embedding,
                vector_column_name=self.vector_column,
            ).limit(fetch_k)
            rows = query.to_list()
        except Exception as exc:
            raise RetrievalError("failed to search LanceDB chunks") from exc

        documents = [
            document
            for row in rows
            if _metadata_matches_filters(row, filters)
            for document in [_record_to_document(row, rank=0)]
        ][:top_k]
        results = [
            Document(
                id=document.id,
                content=document.content,
                metadata=document.metadata,
                score=document.score,
                rank=index + 1,
                source=document.source,
            )
            for index, document in enumerate(documents)
        ]
        return results

    def search(
        self,
        *,
        query_embedding: list[float] | None = None,
        query_text: str | None = None,
        top_k: int = 5,
        filters: MetadataFilters | None = None,
        search_type: SearchType = "vector",
        fetch_k: int | None = None,
        score_threshold: float | None = None,
        length_weight: float | None = None,
        diversity_penalty_weight: float | None = None,
        diversity_metadata_key: str | None = None,
    ) -> list[Document]:
        if search_type != "vector":
            raise RetrievalError(
                "LanceDBRetrievalStore supports only vector search. "
                f"Requested search_type={search_type!r}."
            )
        if query_embedding is None:
            raise RetrievalError("query_embedding is required for LanceDB vector search")
        return self.similarity_search(
            query_embedding,
            top_k=fetch_k or top_k,
            filters=filters,
        )[:top_k]

    def get_chunks_by_ids(
        self,
        chunk_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        ids = set(_unique_non_empty_strings(chunk_ids))
        if not ids:
            return []
        return self._lookup_rows(
            lambda row: str(row.get("id")) in ids,
            filters=filters,
        )

    def get_chunks_by_document_ids(
        self,
        document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        ids = set(_unique_non_empty_strings(document_ids))
        if not ids:
            return []
        return self._lookup_rows(
            lambda row: str(row.get("document_id")) in ids,
            filters=filters,
        )

    def get_chunks_by_parent_document_ids(
        self,
        parent_document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        ids = set(_unique_non_empty_strings(parent_document_ids))
        if not ids:
            return []
        return self._lookup_rows(
            lambda row: str(_row_metadata(row).get("parent_doc_id")) in ids,
            filters=filters,
        )

    def get_chunk_windows(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        if before < 0 or after < 0:
            raise RetrievalError("before and after must be non-negative")
        windows = [
            (
                target.document_id,
                max(0, target.chunk_index - before),
                target.chunk_index + after,
            )
            for target in _unique_window_targets(targets)
        ]
        if not windows:
            return []
        return self._lookup_rows(
            lambda row: any(
                str(row.get("document_id")) == document_id
                and start <= int(row.get("chunk_index", -1)) <= end
                for document_id, start, end in windows
            ),
            filters=filters,
        )

    def get_chunk_window_batch(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Backward-compatible alias for batch window lookup."""
        return self.get_chunk_windows(targets, before=before, after=after, filters=filters)

    def run_chunk_query(
        self,
        name: str,
        *,
        params: dict[str, object] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        raise RetrievalError("LanceDBRetrievalStore does not support custom chunk queries")

    def run_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        raise RetrievalError("LanceDBRetrievalStore does not support custom row queries")

    def _lookup_rows(
        self,
        predicate: Any,
        *,
        filters: MetadataFilters | None,
    ) -> list[Document]:
        self.ensure_collection()
        if self._table is None:
            return []
        rows = _table_rows(self._table)
        documents = [
            _record_to_document(row, rank=0, source="lookup")
            for row in rows
            if predicate(row) and _metadata_matches_filters(row, filters)
        ]
        documents.sort(
            key=lambda document: (
                str(document.metadata.get("_relations", {}).get("document_id", "")),
                int(document.metadata.get("_relations", {}).get("chunk_index", 0)),
                document.id,
            )
        )
        return [
            Document(
                id=document.id,
                content=document.content,
                metadata=document.metadata,
                score=document.score,
                rank=index + 1,
                source=document.source,
            )
            for index, document in enumerate(documents)
        ]


def _chunk_to_record(chunk: EmbeddedChunk, vector_column: str) -> dict[str, Any]:
    return {
        "id": chunk.id,
        "document_id": chunk.document_id,
        "chunk_index": chunk.chunk_index,
        "content": chunk.content,
        "metadata_json": json.dumps(chunk.metadata, ensure_ascii=False, sort_keys=True),
        "source": chunk.source or "",
        vector_column: chunk.embedding,
    }


def _table_names(list_tables_result: Any) -> list[str]:
    return list(getattr(list_tables_result, "tables", list_tables_result))


def _record_to_document(row: dict[str, Any], *, rank: int, source: str = "vector") -> Document:
    metadata = _row_metadata(row)
    relations = {
        "chunk_id": str(row.get("id")),
        "document_id": str(row.get("document_id")),
        "chunk_index": int(row.get("chunk_index") or 0),
        "source": row.get("source"),
    }
    existing_relations = metadata.get("_relations")
    if isinstance(existing_relations, dict):
        relations = {**existing_relations, **relations}
    metadata = {**metadata, "_relations": relations}

    score = row.get("_distance")
    normalized_score = None if score is None else float(score)
    return Document(
        id=str(row["id"]),
        content=str(row["content"]),
        metadata=metadata,
        score=normalized_score,
        rank=rank,
        source=source,
    )


def _row_metadata(row: dict[str, Any]) -> dict[str, Any]:
    metadata_json = row.get("metadata_json")
    if isinstance(metadata_json, str) and metadata_json:
        metadata = json.loads(metadata_json)
        if isinstance(metadata, dict):
            return metadata
    return {}


def _table_rows(table: Any) -> list[dict[str, Any]]:
    if hasattr(table, "to_list"):
        return list(table.to_list())
    if hasattr(table, "to_arrow"):
        return list(table.to_arrow().to_pylist())
    if hasattr(table, "to_pandas"):
        return list(table.to_pandas().to_dict("records"))
    raise RetrievalError("failed to read LanceDB table rows")


def _metadata_matches_filters(row: dict[str, Any], filters: MetadataFilters | None) -> bool:
    if not filters:
        return True
    metadata_json = row.get("metadata_json")
    if not isinstance(metadata_json, str):
        return False
    metadata = json.loads(metadata_json) if metadata_json else {}
    return all(
        _metadata_value_matches(metadata, _validate_filter_key(key), value)
        for key, value in filters.items()
    )


def _metadata_value_matches(
    metadata: dict[str, Any],
    key: str,
    value: MetadataFilterValue,
) -> bool:
    actual = metadata.get(key)
    operator, operand = _normalize_filter_condition(value)
    if operator == "eq":
        return str(actual) == operand
    if operator == "ne":
        return key in metadata and str(actual) != operand
    if operator == "in":
        return str(actual) in operand
    if operator == "contains":
        return isinstance(actual, list) and operand in {str(item) for item in actual}
    if operator == "contains_any":
        return isinstance(actual, list) and bool({str(item) for item in actual} & set(operand))
    if operator == "not_contains":
        return key in metadata and not (
            isinstance(actual, list) and operand in {str(item) for item in actual}
        )
    if operator == "not_contains_any":
        return key in metadata and not (
            isinstance(actual, list) and bool({str(item) for item in actual} & set(operand))
        )
    raise RetrievalError(f"unsupported metadata filter operator: {operator}")


def _normalize_filter_condition(value: MetadataFilterValue) -> tuple[str, str | list[str]]:
    if isinstance(value, str):
        return "eq", value
    if isinstance(value, list):
        return "in", _normalize_filter_values(value)
    if not isinstance(value, dict):
        raise RetrievalError("metadata filter value must be a string, list, or operator object")
    if len(value) != 1:
        raise RetrievalError("metadata filter operator object must contain exactly one operator")
    operator, operand = next(iter(value.items()))
    if operator in {"eq", "ne", "contains", "not_contains"}:
        if isinstance(operand, list):
            raise RetrievalError(f"metadata filter operator {operator!r} requires one value")
        return operator, str(operand)
    if operator in {"in", "contains_any", "not_contains_any"}:
        if not isinstance(operand, list):
            raise RetrievalError(f"metadata filter operator {operator!r} requires a value list")
        return operator, _normalize_filter_values(operand)
    raise RetrievalError(f"unsupported metadata filter operator: {operator}")


def _normalize_filter_values(values: list[str]) -> list[str]:
    normalized = [str(value) for value in values if str(value)]
    if not normalized:
        raise RetrievalError("metadata filter value list must not be empty")
    return normalized


def _validate_filter_key(key: str) -> str:
    if not key.replace("_", "").replace("-", "").isalnum():
        raise RetrievalError(f"unsupported metadata filter key: {key}")
    return key


def _unique_non_empty_strings(values: list[str]) -> list[str]:
    unique: list[str] = []
    seen: set[str] = set()
    for value in values:
        normalized = str(value)
        if not normalized or normalized in seen:
            continue
        unique.append(normalized)
        seen.add(normalized)
    return unique


def _unique_window_targets(targets: list[ChunkWindowTarget]) -> list[ChunkWindowTarget]:
    unique: list[ChunkWindowTarget] = []
    seen: set[tuple[str, int]] = set()
    for target in targets:
        key = (str(target.document_id), int(target.chunk_index))
        if not key[0] or key in seen:
            continue
        unique.append(ChunkWindowTarget(document_id=key[0], chunk_index=key[1]))
        seen.add(key)
    return unique


def _quote_sql_string(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"
