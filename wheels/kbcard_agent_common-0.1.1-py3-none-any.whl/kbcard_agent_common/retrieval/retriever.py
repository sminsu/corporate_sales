"""Framework-agnostic retrieval facade."""

from __future__ import annotations

from typing import Any, Self

from kbcard_agent_common.config import RetrievalSettings
from kbcard_agent_common.embedding import EmbeddingService, RerankingService
from kbcard_agent_common.errors import RetrievalError
from kbcard_agent_common.retrieval.stores.base import RetrievalStore, SearchType
from kbcard_agent_common.types import ChunkWindowTarget, Document, MetadataFilters

_EMBEDDING_SEARCH_TYPES = {"vector", "hybrid", "weighted_vector"}


class Retriever:
    """검색, 임베딩, 리랭킹을 결합해 RAG 문서를 반환하는 facade."""

    def __init__(
        self,
        *,
        store: RetrievalStore,
        retrieval_config: RetrievalSettings | None = None,
        embedder: EmbeddingService | None = None,
        reranker: RerankingService | None = None,
        owns_dependencies: bool = False,
    ) -> None:
        """느슨한 결합(DIP)을 보장하기 위해 구체 클래스가 아닌 프로토콜 인터페이스에 의존합니다."""
        self.embedder = embedder
        self.store = store
        self.reranker = reranker
        self.retrieval_config = retrieval_config or RetrievalSettings(search_type="vector")
        # owns_dependencies: True인 경우에만 Retriever 종료 시 자원을 자동으로 해제합니다.
        self._owns_dependencies = owns_dependencies

    def search(
        self,
        query: str,
        *,
        top_k: int | None = None,
        filters: MetadataFilters | None = None,
        search_type: SearchType | None = None,
        fetch_k: int | None = None,
        rerank_top_k: int | None = None,
        score_threshold: float | None = None,
        length_weight: float | None = None,
        diversity_penalty_weight: float | None = None,
        diversity_metadata_key: str | None = None,
    ) -> list[Document]:
        """쿼리 문장으로 검색하고 선택적으로 reranking한 최종 문서를 반환합니다."""
        retrieval = self.retrieval_config
        advanced = retrieval.advanced
        effective_top_k = top_k or retrieval.top_k
        effective_search_type = search_type or retrieval.search_type
        effective_fetch_k = fetch_k or advanced.fetch_k
        effective_rerank_top_k = advanced.rerank_top_k if rerank_top_k is None else rerank_top_k
        effective_score_threshold = (
            retrieval.score_threshold if score_threshold is None else score_threshold
        )
        effective_length_weight = advanced.length_weight if length_weight is None else length_weight
        effective_diversity_penalty_weight = (
            advanced.diversity_penalty_weight
            if diversity_penalty_weight is None
            else diversity_penalty_weight
        )
        effective_diversity_metadata_key = (
            advanced.diversity_metadata_key
            if diversity_metadata_key is None
            else diversity_metadata_key
        )

        # 검색 타입에 따라 필요한 경우에만 쿼리 임베딩을 동적으로 생성한다.
        query_embedding = None
        if effective_search_type in _EMBEDDING_SEARCH_TYPES:
            if self.embedder is None:
                raise RetrievalError(
                    f"embedding client is required for {effective_search_type} search"
                )
            query_embedding = self.embedder.embed_text(query)

        # 리랭킹 수행 조건 확인
        reranker = self.reranker
        should_rerank = reranker is not None and effective_rerank_top_k > 0
        candidate_top_k = effective_fetch_k if should_rerank else effective_top_k

        # 2. 검색 실행 엔진(RetrievalStore)을 통해 일차 후보군 또는 최종 문서 검색 실행
        documents = self.store.search(

            query_embedding=query_embedding,
            query_text=query,
            top_k=candidate_top_k,
            filters=filters,
            search_type=effective_search_type,
            fetch_k=effective_fetch_k,
            score_threshold=effective_score_threshold,
            length_weight=effective_length_weight,
            diversity_penalty_weight=effective_diversity_penalty_weight,
            diversity_metadata_key=effective_diversity_metadata_key,
        )
        if not should_rerank or not documents:
            return documents[:effective_top_k]

        if reranker is None:
            return documents[:effective_top_k]

        reranked = reranker.rerank(
            query,
            [document.content for document in documents],
            top_k=effective_rerank_top_k,
        )
        by_index = {result.index: result for result in reranked}
        ordered = sorted(by_index.items(), key=lambda item: item[1].score, reverse=True)[
            :effective_top_k
        ]
        return [
            Document(
                id=documents[index].id,
                content=documents[index].content,
                metadata=documents[index].metadata,
                score=result.score,
                rank=rank,
                source="rerank",
            )
            for rank, (index, result) in enumerate(ordered, start=1)
        ]

    def get_chunks_by_ids(
        self,
        chunk_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Direct lookup helper for orchestration code that already has chunk IDs."""
        return self.store.get_chunks_by_ids(chunk_ids, filters=filters)

    def get_chunks_by_document_ids(
        self,
        document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Direct lookup helper for all chunks under known document IDs."""
        return self.store.get_chunks_by_document_ids(document_ids, filters=filters)

    def get_chunks_by_parent_document_ids(
        self,
        parent_document_ids: list[str],
        *,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Direct lookup helper for child chunks referencing parent document IDs."""
        return self.store.get_chunks_by_parent_document_ids(parent_document_ids, filters=filters)

    def get_chunk_windows(
        self,
        targets: list[ChunkWindowTarget],
        *,
        before: int = 1,
        after: int = 1,
        filters: MetadataFilters | None = None,
    ) -> list[Document]:
        """Direct lookup helper for batch sibling/context window expansion."""
        return self.store.get_chunk_windows(
            targets,
            before=before,
            after=after,
            filters=filters,
        )

    def run_chunk_query(
        self,
        name: str,
        *,
        params: dict[str, object] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[Document]:
        """Run a configured named chunk query for advanced orchestration cases."""
        return self.store.run_chunk_query(
            name,
            params=params,
            filters=filters,
            limit=limit,
        )

    def run_query(
        self,
        name: str,
        *,
        params: dict[str, Any] | None = None,
        filters: MetadataFilters | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Run a configured named row query for advanced orchestration cases."""
        return self.store.run_query(
            name,
            params=params,
            filters=filters,
            limit=limit,
        )

    def close(self) -> None:
        if not self._owns_dependencies:
            return
        _close_if_present(self.embedder)
        _close_if_present(self.reranker)
        _close_if_present(self.store)

    def __enter__(self) -> Self:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _close_if_present(value: Any) -> None:
    close = getattr(value, "close", None)
    if callable(close):
        close()
