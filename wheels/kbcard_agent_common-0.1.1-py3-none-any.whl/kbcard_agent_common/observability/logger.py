"""KBCard 공통 로거.

예제에서 사용하는 `KBCardLogger.from_config(config).info("...")` 흐름을 기본으로 한다.
화면 출력은 사람이 읽기 쉬운 형태로, 파일 출력은 JSONL로 기록한다.
"""

from __future__ import annotations

import json
import logging
import os
import sys
from datetime import UTC, datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any


class KBCardLogger:
    """설정 기반으로 stdout/file 로그를 남기는 간단한 로거."""

    def __init__(
        self,
        logger: logging.Logger | str | None = None,
        *,
        formatter: str = "jsonl",
        level: str | int | None = None,
        output: str = "stdout",
        file_path: str | Path | None = None,
        max_bytes: int = 10 * 1024 * 1024,
        backup_count: int = 5,
        default_fields: dict[str, Any] | None = None,
    ) -> None:
        self._uses_managed_handlers = not isinstance(logger, logging.Logger)
        self._stdout_formatter = _normalize_formatter(formatter)
        self._logger = _resolve_logger(
            logger,
            level=_levelno(level or "INFO"),
            output=_normalize_output(output),
            stdout_formatter=self._stdout_formatter,
            file_path=file_path,
            max_bytes=max_bytes,
            backup_count=backup_count,
        )
        self._default_fields = dict(default_fields or {})

    @classmethod
    def from_config(
        cls,
        config: Any,
        *,
        logger: logging.Logger | None = None,
        formatter: str | None = None,
        level: str | None = None,
        output: str | None = None,
        file_path: str | Path | None = None,
        max_bytes: int | None = None,
        backup_count: int | None = None,
    ) -> KBCardLogger:
        """KBCardConfig의 agent/logger 설정으로 로거를 만든다."""

        agent = getattr(config, "agent", None)
        logger_settings = getattr(config, "logger", None)
        logger_name = (
            getattr(agent, "service_name", None)
            or getattr(agent, "name", None)
            or "kbcard_agent_common.observability"
        )
        default_fields = {
            "agent_name": getattr(agent, "name", None),
            "environment": getattr(agent, "environment", None),
            "service_name": getattr(agent, "service_name", None),
        }
        return cls(
            logger=logger or logger_name,
            formatter=formatter
            or os.getenv("KBCARD_LOG_FORMAT")
            or getattr(logger_settings, "formatter", "pretty"),
            level=level
            or os.getenv("KBCARD_LOG_LEVEL")
            or getattr(logger_settings, "level", "INFO"),
            output=output
            or os.getenv("KBCARD_LOG_OUTPUT")
            or getattr(logger_settings, "output", "stdout"),
            file_path=file_path
            or os.getenv("KBCARD_LOG_FILE_PATH")
            or getattr(logger_settings, "file_path", None),
            max_bytes=max_bytes
            or _env_int(
                "KBCARD_LOG_FILE_MAX_BYTES",
                getattr(logger_settings, "max_bytes", 10 * 1024 * 1024),
            ),
            backup_count=backup_count
            if backup_count is not None
            else _env_int(
                "KBCARD_LOG_FILE_BACKUP_COUNT",
                getattr(logger_settings, "backup_count", 5),
            ),
            default_fields={
                key: value for key, value in default_fields.items() if value is not None
            },
        )

    def info(self, message: str, **metadata: Any) -> dict[str, Any]:
        """INFO 레벨 로그를 남긴다."""

        return self._log("INFO", message, **metadata)

    def debug(self, message: str, **metadata: Any) -> dict[str, Any]:
        """DEBUG 레벨 로그를 남긴다."""

        return self._log("DEBUG", message, **metadata)

    def warning(self, message: str, **metadata: Any) -> dict[str, Any]:
        """WARNING 레벨 로그를 남긴다."""

        return self._log("WARNING", message, **metadata)

    def error(self, message: str, **metadata: Any) -> dict[str, Any]:
        """ERROR 레벨 로그를 남긴다."""

        return self._log("ERROR", message, **metadata)

    def critical(self, message: str, **metadata: Any) -> dict[str, Any]:
        """CRITICAL 레벨 로그를 남긴다."""

        return self._log("CRITICAL", message, **metadata)

    def _log(self, level: str, message: str, **metadata: Any) -> dict[str, Any]:
        """로그를 남기고 실제 payload를 반환한다."""

        payload: dict[str, Any] = {
            "log_type": "LOG",
            "timestamp": _format_timestamp(),
            "log_level": level.upper(),
            "logger_name": self._logger.name,
            "message": message,
            **self._default_fields,
        }
        if metadata:
            payload["metadata"] = metadata
        self._emit_payload(_levelno(level), payload)
        return payload

    def _emit_payload(self, level: int, payload: dict[str, Any]) -> None:
        if self._uses_managed_handlers:
            self._logger.log(level, "", extra={"kbcard_payload": payload})
            return
        self._logger.log(level, _to_json(payload))


class _KBCardLogFormatter(logging.Formatter):
    """stdout은 pretty, file은 JSONL로 출력하기 위한 formatter."""

    def __init__(self, formatter: str) -> None:
        super().__init__("%(message)s")
        self._formatter = _normalize_formatter(formatter)

    def format(self, record: logging.LogRecord) -> str:
        payload = getattr(record, "kbcard_payload", None)
        if not isinstance(payload, dict):
            return super().format(record)
        if self._formatter == "jsonl":
            return _to_json(payload)
        return _to_pretty(payload)


def _resolve_logger(
    logger: logging.Logger | str | None,
    *,
    level: int,
    output: str,
    stdout_formatter: str,
    file_path: str | Path | None,
    max_bytes: int,
    backup_count: int,
) -> logging.Logger:
    if isinstance(logger, logging.Logger):
        logger.setLevel(level)
        return logger

    resolved_logger = logging.getLogger(str(logger or "kbcard_agent_common.observability"))
    resolved_logger.setLevel(level)
    _configure_handlers(
        resolved_logger,
        level=level,
        output=output,
        stdout_formatter=stdout_formatter,
        file_path=file_path,
        max_bytes=max_bytes,
        backup_count=backup_count,
    )
    return resolved_logger


def _configure_handlers(
    logger: logging.Logger,
    *,
    level: int,
    output: str,
    stdout_formatter: str,
    file_path: str | Path | None,
    max_bytes: int,
    backup_count: int,
) -> None:
    for handler in list(logger.handlers):
        if getattr(handler, "_kbcard_handler", False):
            logger.removeHandler(handler)
            handler.close()

    if output in {"stdout", "both"}:
        logger.addHandler(_stdout_handler(level, stdout_formatter))
    if output in {"file", "both"}:
        logger.addHandler(_file_handler(level, file_path, max_bytes, backup_count))

    logger.propagate = False


def _stdout_handler(level: int, formatter: str) -> logging.Handler:
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.setFormatter(_KBCardLogFormatter(formatter))
    handler.__dict__["_kbcard_handler"] = True
    return handler


def _file_handler(
    level: int,
    file_path: str | Path | None,
    max_bytes: int,
    backup_count: int,
) -> logging.Handler:
    if file_path is None:
        raise ValueError("file_path is required when output is 'file' or 'both'")

    path = Path(file_path).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        path,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    handler.setLevel(level)
    handler.setFormatter(_KBCardLogFormatter("jsonl"))
    handler.__dict__["_kbcard_handler"] = True
    return handler


def _to_pretty(payload: dict[str, Any]) -> str:
    timestamp = _format_pretty_timestamp(payload["timestamp"])
    return f"{timestamp} [{payload['log_level']}] {payload['message']}"


def _format_timestamp() -> str:
    return datetime.now(UTC).isoformat()


def _format_pretty_timestamp(value: Any) -> str:
    try:
        timestamp = datetime.fromisoformat(str(value))
    except ValueError:
        return str(value)
    return timestamp.strftime("%Y-%m-%dT%H:%M:%S") + f".{timestamp.microsecond // 100000}"


def _to_json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


def _normalize_formatter(formatter: str) -> str:
    if formatter in {"jsonl", "pretty"}:
        return formatter
    raise ValueError("formatter must be 'jsonl' or 'pretty'")


def _normalize_output(output: str) -> str:
    if output in {"stdout", "file", "both"}:
        return output
    raise ValueError("output must be 'stdout', 'file', or 'both'")


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _levelno(level: str | int) -> int:
    if isinstance(level, int):
        return level
    levelno = logging.getLevelName(level.upper())
    return levelno if isinstance(levelno, int) else logging.INFO
