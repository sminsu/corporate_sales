"""OpenTelemetry 기반 tracing helper.

이 모듈은 KBCardLogger와 독립적으로 동작한다. 로그 출력은 logger가 담당하고,
요청/에이전트/LLM 호출 구간 추적은 KBCardTracer가 담당한다.
"""

from __future__ import annotations

import inspect
import json
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from typing import Any, Literal, TypeVar, overload

F = TypeVar("F", bound=Callable[..., Any])
TraceExporter = Literal["console", "otlp", "none"]


class KBCardSpan:
    """OpenTelemetry Span을 개발자가 쓰기 쉬운 메서드로 감싼 wrapper."""

    def __init__(self, span: Any | None):
        self._span = span

    @property
    def trace_id(self) -> str | None:
        """현재 span이 속한 trace_id를 32자리 hex 문자열로 반환한다."""
        return _span_trace_id(self._span)

    @property
    def span_id(self) -> str | None:
        """현재 span_id를 16자리 hex 문자열로 반환한다."""
        return _span_id(self._span)

    def set_attribute(self, key: str, value: Any) -> KBCardSpan:
        """span에 검색/필터링 가능한 attribute를 추가한다."""
        if self._span is not None:
            self._span.set_attribute(key, _attribute_value(value))
        return self

    def set_attributes(self, attributes: dict[str, Any]) -> KBCardSpan:
        """여러 attribute를 한 번에 추가한다."""
        for key, value in attributes.items():
            self.set_attribute(key, value)
        return self

    def set_span_kind(self, kind: str) -> KBCardSpan:
        """Phoenix/OpenInference가 span 역할을 인식할 수 있게 kind를 기록한다."""
        normalized = _normalize_openinference_span_kind(kind)
        self.set_attribute("openinference.span.kind", normalized)
        return self

    def set_input(self, value: Any, *, mime_type: str | None = None) -> KBCardSpan:
        """Phoenix/OpenInference가 표시할 span 입력값을 기록한다."""
        resolved_mime_type = mime_type or _infer_mime_type(value)
        self.set_attribute("input.value", _serialize_observability_value(value, resolved_mime_type))
        self.set_attribute("input.mime_type", resolved_mime_type)
        return self

    def set_output(self, value: Any, *, mime_type: str | None = None) -> KBCardSpan:
        """Phoenix/OpenInference가 표시할 span 출력값을 기록한다."""
        resolved_mime_type = mime_type or _infer_mime_type(value)
        self.set_attribute(
            "output.value",
            _serialize_observability_value(value, resolved_mime_type),
        )
        self.set_attribute("output.mime_type", resolved_mime_type)
        return self

    def set_io(
        self,
        *,
        input_value: Any | None = None,
        output_value: Any | None = None,
        input_mime_type: str | None = None,
        output_mime_type: str | None = None,
    ) -> KBCardSpan:
        """입력과 출력을 한 번에 기록한다."""
        if input_value is not None:
            self.set_input(input_value, mime_type=input_mime_type)
        if output_value is not None:
            self.set_output(output_value, mime_type=output_mime_type)
        return self

    def set_llm_usage(
        self,
        *,
        model_name: str | None = None,
        provider: str | None = None,
        prompt_tokens: int | None = None,
        completion_tokens: int | None = None,
        total_tokens: int | None = None,
        invocation_parameters: dict[str, Any] | None = None,
    ) -> KBCardSpan:
        """LLM 모델명과 token 사용량을 OpenInference/OTel GenAI key로 기록한다."""
        self.set_span_kind("LLM")
        attributes: dict[str, Any] = {}
        if model_name is not None:
            attributes["llm.model_name"] = model_name
            attributes["gen_ai.request.model"] = model_name
            attributes["gen_ai.response.model"] = model_name
        if provider is not None:
            attributes["llm.provider"] = provider
            attributes["gen_ai.system"] = provider
        if prompt_tokens is not None:
            attributes["llm.token_count.prompt"] = prompt_tokens
            attributes["gen_ai.usage.input_tokens"] = prompt_tokens
        if completion_tokens is not None:
            attributes["llm.token_count.completion"] = completion_tokens
            attributes["gen_ai.usage.output_tokens"] = completion_tokens
        if total_tokens is not None:
            attributes["llm.token_count.total"] = total_tokens
            attributes["gen_ai.usage.total_tokens"] = total_tokens
        if invocation_parameters:
            attributes["llm.invocation_parameters"] = _to_json_string(invocation_parameters)
            attributes["gen_ai.request.parameters"] = _to_json_string(invocation_parameters)
        return self.set_attributes(attributes)

    def set_llm_messages(
        self,
        *,
        input_messages: list[dict[str, Any]] | None = None,
        output_messages: list[dict[str, Any]] | None = None,
    ) -> KBCardSpan:
        """LLM 입출력 메시지를 OpenInference flattened key로 기록한다."""
        attributes: dict[str, Any] = {}
        if input_messages:
            attributes.update(_flatten_llm_messages("llm.input_messages", input_messages))
        if output_messages:
            attributes.update(_flatten_llm_messages("llm.output_messages", output_messages))
        return self.set_attributes(attributes)

    def record_llm_call(
        self,
        *,
        input_value: Any | None = None,
        output_value: Any | None = None,
        input_messages: list[dict[str, Any]] | None = None,
        output_messages: list[dict[str, Any]] | None = None,
        model_name: str | None = None,
        provider: str | None = None,
        prompt_tokens: int | None = None,
        completion_tokens: int | None = None,
        total_tokens: int | None = None,
        invocation_parameters: dict[str, Any] | None = None,
    ) -> KBCardSpan:
        """LLM span에 Phoenix/OpenInference와 OTel GenAI 호환 정보를 한 번에 기록한다."""
        return (
            self.set_span_kind("LLM")
            .set_io(input_value=input_value, output_value=output_value)
            .set_llm_usage(
                model_name=model_name,
                provider=provider,
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                total_tokens=total_tokens,
                invocation_parameters=invocation_parameters,
            )
            .set_llm_messages(input_messages=input_messages, output_messages=output_messages)
        )

    def add_event(self, name: str, **attributes: Any) -> KBCardSpan:
        """span 중간에 의미 있는 이벤트를 추가한다."""
        if self._span is not None:
            self._span.add_event(name, attributes=_span_attributes(attributes))
        return self

    def record_exception(self, exc: BaseException) -> KBCardSpan:
        """예외 정보를 현재 span에 기록한다."""
        if self._span is not None:
            self._span.record_exception(exc)
        return self

    def set_error(self, description: str | None = None) -> KBCardSpan:
        """현재 span 상태를 ERROR로 표시한다."""
        if self._span is not None:
            _, status, status_code = _load_otel_trace_api()
            self._span.set_status(status(status_code.ERROR, description))
        return self

    def set_ok(self, description: str | None = None) -> KBCardSpan:
        """현재 span 상태를 OK로 표시한다."""
        if self._span is not None:
            _, status, status_code = _load_otel_trace_api()
            self._span.set_status(status(status_code.OK, description))
        return self


class KBCardTracer:
    """FastAPI/에이전트/LLM 호출 구간을 OpenTelemetry span으로 기록한다."""

    def __init__(
        self,
        service_name: str,
        *,
        exporter: TraceExporter | str = "console",
        endpoint: str | None = None,
        sample_rate: float = 1.0,
        enabled: bool = True,
        batch: bool = True,
        span_exporter: Any | None = None,
    ) -> None:
        """tracer를 생성한다.

        exporter="console"은 로컬 확인용, exporter="otlp"는 Collector 전송용,
        exporter="none"은 span 생성만 하고 외부 전송은 하지 않는 설정이다.
        """
        self.service_name = service_name
        self.enabled = enabled
        self._provider: Any | None = None
        self._tracer: Any | None = None
        if enabled:
            provider = _create_tracer_provider(
                service_name=service_name,
                exporter=exporter,
                endpoint=endpoint,
                sample_rate=sample_rate,
                batch=batch,
                span_exporter=span_exporter,
            )
            self._provider = provider
            self._tracer = provider.get_tracer(service_name)

    @classmethod
    def from_config(
        cls,
        config: Any,
        *,
        service_name: str | None = None,
        exporter: TraceExporter | str | None = None,
        endpoint: str | None = None,
        sample_rate: float | None = None,
        enabled: bool | None = None,
        batch: bool | None = None,
        span_exporter: Any | None = None,
    ) -> KBCardTracer:
        """KBCardConfig 객체의 observability.tracing 설정으로 tracer를 만든다."""
        tracing = _get_config_tracing_settings(config)
        agent = getattr(config, "agent", None)
        resolved_service_name = (
            service_name
            or getattr(agent, "service_name", None)
            or getattr(agent, "name", None)
            or "kbcard-agent"
        )
        return cls(
            resolved_service_name,
            exporter=exporter if exporter is not None else getattr(tracing, "exporter", "console"),
            endpoint=endpoint if endpoint is not None else getattr(tracing, "endpoint", None),
            sample_rate=sample_rate
            if sample_rate is not None
            else getattr(tracing, "sample_rate", 1.0),
            enabled=enabled if enabled is not None else getattr(tracing, "enabled", True),
            batch=batch if batch is not None else getattr(tracing, "batch", True),
            span_exporter=span_exporter,
        )

    @classmethod
    def from_config_path(
        cls,
        config_path: str | Path,
        **kwargs: Any,
    ) -> KBCardTracer:
        """YAML 경로를 읽어 observability.tracing 설정으로 tracer를 만든다."""
        from kbcard_agent_common.config import KBCardConfig

        return cls.from_config(KBCardConfig.from_yaml(config_path), **kwargs)

    def set_enabled(self, enabled: bool) -> KBCardTracer:
        """tracing 활성화 여부를 변경한다."""
        self.enabled = enabled
        return self

    def get_current_trace_id(self) -> str | None:
        """현재 실행 흐름의 trace_id를 반환한다."""
        return get_current_trace_id()

    def get_current_span_id(self) -> str | None:
        """현재 실행 흐름의 span_id를 반환한다."""
        return get_current_span_id()

    def current_span(self) -> KBCardSpan:
        """현재 실행 중인 OpenTelemetry span을 KBCardSpan wrapper로 반환한다."""
        return KBCardSpan(_get_current_span())

    @contextmanager
    def start_trace(self, name: str, **attributes: Any) -> Iterator[KBCardSpan]:
        """요청 또는 에이전트 실행 같은 최상위 작업 구간을 기록한다."""
        with self.start_span(name, **attributes) as span:
            yield span

    @contextmanager
    def start_span(self, name: str, **attributes: Any) -> Iterator[KBCardSpan]:
        """함수 내부 일부 구간을 span으로 기록한다."""
        if not self.enabled or self._tracer is None:
            yield KBCardSpan(None)
            return
        span_kind = attributes.pop("span_kind", None) or _infer_openinference_span_kind(name)
        span_attributes = _span_attributes(attributes)
        if span_kind is not None:
            span_attributes["openinference.span.kind"] = _normalize_openinference_span_kind(
                span_kind
            )

        with self._tracer.start_as_current_span(
            name,
            attributes=span_attributes,
        ) as otel_span:
            span = KBCardSpan(otel_span)
            try:
                yield span
                span.set_ok()
            except BaseException as exc:
                span.record_exception(exc)
                span.set_error(str(exc))
                raise

    @overload
    def trace(self, name: F) -> F: ...

    @overload
    def trace(
        self,
        name: str | None = None,
        *,
        capture_args: bool = False,
        span_kind: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> Callable[[F], F]: ...

    def trace(
        self,
        name: str | F | None = None,
        *,
        capture_args: bool = False,
        span_kind: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> F | Callable[[F], F]:
        """함수 실행 전체를 span으로 기록하는 decorator.

        `@tracer.trace`, `@tracer.trace()`, `@tracer.trace("span.name")` 형태를
        모두 지원한다. capture_args는 개인정보 노출 방지를 위해 기본 False다.
        """
        if callable(name):
            return self._decorate(
                name,
                None,
                capture_args=capture_args,
                span_kind=span_kind,
                attributes=attributes,
            )

        def decorator(func: F) -> F:
            return self._decorate(
                func,
                name,
                capture_args=capture_args,
                span_kind=span_kind,
                attributes=attributes,
            )

        return decorator

    def instrument_fastapi(self, app: Any) -> Any:
        """FastAPI app의 request 단위 span을 자동 생성하도록 설정한다."""
        if not self.enabled or self._provider is None:
            return app
        try:
            from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
        except ImportError as exc:
            raise ImportError(
                "FastAPI tracing requires opentelemetry-instrumentation-fastapi. "
                "Install kbcard-agent-common[tracing]."
            ) from exc

        FastAPIInstrumentor.instrument_app(app, tracer_provider=self._provider)
        return app

    def shutdown(self) -> None:
        """프로세스 종료 전 exporter queue에 남은 span을 전송한다."""
        if self._provider is not None:
            self._provider.shutdown()

    def _decorate(
        self,
        func: F,
        name: str | None,
        *,
        capture_args: bool,
        span_kind: str | None,
        attributes: dict[str, Any] | None,
    ) -> F:
        """sync/async 함수를 span decorator로 감싼다."""
        span_name = name or func.__qualname__
        base_attributes = dict(attributes or {})

        if inspect.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                span_attributes = _decorator_attributes(
                    func,
                    args,
                    kwargs,
                    base_attributes=base_attributes,
                    capture_args=capture_args,
                )
                with self.start_span(span_name, span_kind=span_kind, **span_attributes):
                    return await func(*args, **kwargs)

            return async_wrapper  # type: ignore[return-value]

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            span_attributes = _decorator_attributes(
                func,
                args,
                kwargs,
                base_attributes=base_attributes,
                capture_args=capture_args,
            )
            with self.start_span(span_name, span_kind=span_kind, **span_attributes):
                return func(*args, **kwargs)

        return sync_wrapper  # type: ignore[return-value]


def get_current_trace_id() -> str | None:
    """현재 OpenTelemetry context의 trace_id를 반환한다."""
    span = _get_current_span()
    return _span_trace_id(span)


def get_current_span_id() -> str | None:
    """현재 OpenTelemetry context의 span_id를 반환한다."""
    span = _get_current_span()
    return _span_id(span)


def _create_tracer_provider(
    *,
    service_name: str,
    exporter: TraceExporter | str,
    endpoint: str | None,
    sample_rate: float,
    batch: bool,
    span_exporter: Any | None,
) -> Any:
    """OpenTelemetry TracerProvider와 exporter/processor를 구성한다."""
    (
        tracer_provider,
        resource,
        trace_id_ratio_based,
        batch_span_processor,
        simple_span_processor,
        console_span_exporter,
    ) = _load_otel_sdk()

    provider = tracer_provider(
        resource=resource.create({"service.name": service_name}),
        sampler=trace_id_ratio_based(sample_rate),
    )
    resolved_exporter = span_exporter or _create_span_exporter(
        exporter=exporter,
        endpoint=endpoint,
        console_span_exporter=console_span_exporter,
    )
    if resolved_exporter is not None:
        processor = (
            batch_span_processor(resolved_exporter)
            if batch
            else simple_span_processor(resolved_exporter)
        )
        provider.add_span_processor(processor)
    return provider


def _get_config_tracing_settings(config: Any) -> Any:
    """config.observability.tracing이 없으면 기본값 객체처럼 동작하는 값을 반환한다."""
    observability = getattr(config, "observability", None)
    tracing = getattr(observability, "tracing", None)
    if tracing is not None:
        return tracing
    return _DefaultTracingSettings()


class _DefaultTracingSettings:
    """YAML에 observability.tracing이 없을 때 사용하는 기본 tracing 설정."""

    enabled = True
    exporter = "console"
    endpoint = None
    sample_rate = 1.0
    batch = True


def _create_span_exporter(
    *,
    exporter: TraceExporter | str,
    endpoint: str | None,
    console_span_exporter: Any,
) -> Any | None:
    """설정값에 맞는 OpenTelemetry span exporter를 만든다."""
    if exporter == "none":
        return None
    if exporter == "console":
        return console_span_exporter()
    if exporter == "otlp":
        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        except ImportError as exc:
            raise ImportError(
                "OTLP tracing requires opentelemetry-exporter-otlp. "
                "Install kbcard-agent-common[tracing]."
            ) from exc
        return OTLPSpanExporter(endpoint=endpoint)
    raise ValueError("exporter must be 'console', 'otlp', or 'none'")


def _load_otel_sdk() -> tuple[Any, Any, Any, Any, Any, Any]:
    """OpenTelemetry SDK 의존성을 lazy import한다."""
    try:
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import (
            BatchSpanProcessor,
            ConsoleSpanExporter,
            SimpleSpanProcessor,
        )
        from opentelemetry.sdk.trace.sampling import TraceIdRatioBased
    except ImportError as exc:
        raise ImportError(
            "KBCardTracer requires OpenTelemetry. Install kbcard-agent-common[tracing]."
        ) from exc
    return (
        TracerProvider,
        Resource,
        TraceIdRatioBased,
        BatchSpanProcessor,
        SimpleSpanProcessor,
        ConsoleSpanExporter,
    )


def _load_otel_trace_api() -> tuple[Any, Any, Any]:
    """OpenTelemetry trace API 의존성을 lazy import한다."""
    try:
        from opentelemetry import trace
        from opentelemetry.trace import Status, StatusCode
    except ImportError as exc:
        raise ImportError(
            "KBCardTracer requires OpenTelemetry. Install kbcard-agent-common[tracing]."
        ) from exc
    return trace, Status, StatusCode


def _get_current_span() -> Any | None:
    """현재 OpenTelemetry span을 가져온다. 미설치 환경에서는 None을 반환한다."""
    try:
        trace, _, _ = _load_otel_trace_api()
    except ImportError:
        return None
    return trace.get_current_span()


def _span_trace_id(span: Any | None) -> str | None:
    """span context에서 trace_id를 32자리 hex 문자열로 추출한다."""
    if span is None:
        return None
    context = span.get_span_context()
    if not getattr(context, "is_valid", False):
        return None
    return f"{context.trace_id:032x}"


def _span_id(span: Any | None) -> str | None:
    """span context에서 span_id를 16자리 hex 문자열로 추출한다."""
    if span is None:
        return None
    context = span.get_span_context()
    if not getattr(context, "is_valid", False):
        return None
    return f"{context.span_id:016x}"


def _span_attributes(attributes: dict[str, Any]) -> dict[str, Any]:
    """OpenTelemetry attribute로 기록 가능한 값만 정리한다."""
    return {
        key: _attribute_value(value)
        for key, value in attributes.items()
        if value is not None
    }


def _attribute_value(value: Any) -> str | bool | int | float:
    """복잡한 객체는 짧은 문자열로 바꿔 backend 호환성을 높인다."""
    if isinstance(value, str | bool | int | float):
        return value
    return _safe_repr(value)


def _normalize_openinference_span_kind(kind: str) -> str:
    """Phoenix/OpenInference span kind 값을 표준 대문자 값으로 정리한다."""
    normalized = kind.strip().upper()
    aliases = {
        "LLM": "LLM",
        "CHAIN": "CHAIN",
        "AGENT": "AGENT",
        "TOOL": "TOOL",
        "RETRIEVER": "RETRIEVER",
        "EMBEDDING": "EMBEDDING",
        "RERANKER": "RERANKER",
    }
    return aliases.get(normalized, normalized)


def _infer_openinference_span_kind(name: str) -> str:
    """span 이름에서 기본 OpenInference kind를 추정한다."""
    lowered = name.lower()
    if lowered.startswith("llm.") or ".llm." in lowered:
        return "LLM"
    if "retrieve" in lowered or "retrieval" in lowered:
        return "RETRIEVER"
    if lowered.startswith("agent.") or ".agent." in lowered:
        return "AGENT"
    if lowered.startswith("tool.") or ".tool." in lowered:
        return "TOOL"
    return "CHAIN"


def _infer_mime_type(value: Any) -> str:
    """OpenInference input/output mime type을 추정한다."""
    if isinstance(value, dict | list | tuple):
        return "application/json"
    return "text/plain"


def _serialize_observability_value(value: Any, mime_type: str) -> str:
    """input.value/output.value에 넣을 값을 backend 친화적인 문자열로 만든다."""
    if mime_type == "application/json":
        return _to_json_string(value)
    if isinstance(value, str):
        return value
    return _safe_repr(value, max_length=4000)


def _to_json_string(value: Any) -> str:
    """JSON 직렬화가 안 되는 값은 repr 문자열로 대체해 JSON 문자열을 만든다."""
    try:
        return json.dumps(value, ensure_ascii=False, default=_safe_repr)
    except TypeError:
        return _safe_repr(value, max_length=4000)


def _flatten_llm_messages(prefix: str, messages: list[dict[str, Any]]) -> dict[str, Any]:
    """OpenInference LLM message list를 flattened attribute로 변환한다."""
    attributes: dict[str, Any] = {}
    for index, message in enumerate(messages):
        role = message.get("role")
        content = message.get("content")
        if role is not None:
            attributes[f"{prefix}.{index}.message.role"] = role
        if content is not None:
            attributes[f"{prefix}.{index}.message.content"] = content
    return attributes


def _decorator_attributes(
    func: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    *,
    base_attributes: dict[str, Any],
    capture_args: bool,
) -> dict[str, Any]:
    """decorator span에 붙일 기본 attribute를 만든다."""
    attributes = {
        "code.function": func.__qualname__,
        "code.namespace": func.__module__,
        **base_attributes,
    }
    if not capture_args:
        return attributes

    try:
        bound = inspect.signature(func).bind_partial(*args, **kwargs)
    except TypeError:
        return attributes

    for key, value in bound.arguments.items():
        if key in {"self", "cls"}:
            continue
        attributes[f"function.argument.{key}"] = _safe_repr(value)
    return attributes


def _safe_repr(value: Any, *, max_length: int = 120) -> str:
    """attribute에 들어갈 값 표현이 너무 길어지지 않게 제한한다."""
    text = repr(value)
    if len(text) <= max_length:
        return text
    return f"{text[: max_length - 3]}..."
