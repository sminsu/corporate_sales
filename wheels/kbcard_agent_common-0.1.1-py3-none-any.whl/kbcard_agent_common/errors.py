"""Shared exception types for common agent modules."""


class KBCardAgentError(Exception):
    """Base exception for all common module errors."""


class ConfigurationError(KBCardAgentError):
    """Raised when configuration is missing or invalid."""


class ProviderError(KBCardAgentError):
    """Raised when an external provider call fails."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
        request_id: str | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.provider = provider
        self.status_code = status_code
        self.response_body = response_body
        self.request_id = request_id
        self.retryable = retryable


class RetryableProviderError(ProviderError):
    """Raised when provider failure can be retried."""

    def __init__(
        self,
        message: str,
        *,
        provider: str | None = None,
        status_code: int | None = None,
        response_body: str | None = None,
        request_id: str | None = None,
        retryable: bool = True,
    ) -> None:
        super().__init__(
            message,
            provider=provider,
            status_code=status_code,
            response_body=response_body,
            request_id=request_id,
            retryable=retryable,
        )


class CapabilityNotSupportedError(KBCardAgentError):
    """Raised when a model or provider does not support a requested capability."""


class RetrievalError(KBCardAgentError):
    """Raised when retrieval or storage operations fail."""


class IngestionError(KBCardAgentError):
    """Raised when parsing, chunking, or indexing fails."""


class UnsupportedExtensionError(IngestionError):
    """Raised when no parser is registered for a file's extension."""


class EvaluationError(KBCardAgentError):
    """Raised when evaluation setup or execution fails."""
