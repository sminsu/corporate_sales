"""KB Card AI Agent common SDK."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("kbcard-agent-common")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
