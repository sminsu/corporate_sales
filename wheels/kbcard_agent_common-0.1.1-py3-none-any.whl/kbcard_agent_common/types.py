"""Shared lightweight data contracts.

Detailed schemas will evolve with each module implementation. This file keeps
cross-module names stable from the first package version.
"""

from dataclasses import dataclass, field
from typing import Any

type MetadataFilterValue = str | list[str] | dict[str, str | list[str]]
type MetadataFilters = dict[str, MetadataFilterValue]


@dataclass(frozen=True)
class Document:
    """Standard retrieval result passed across retrieval, LLM, and evaluation."""

    id: str
    content: str
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float | None = None
    rank: int | None = None
    source: str | None = None


@dataclass(frozen=True)
class ChunkWindowTarget:
    """Target chunk location used for batch sibling/window lookup."""

    document_id: str
    chunk_index: int


@dataclass(frozen=True)
class EvaluationCase:
    """Standard evaluation input case."""

    id: str
    input: dict[str, Any]
    expected: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class EvaluationResult:
    """Standard evaluation result for one case."""

    case_id: str
    status: str
    metrics: dict[str, float | int | str | bool | None] = field(default_factory=dict)
    trace: dict[str, Any] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
