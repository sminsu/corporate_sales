"""Agent and tool integration contracts."""

__all__: list[str] = []
